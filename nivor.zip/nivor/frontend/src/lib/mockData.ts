import {
  User,
  Task,
  CalendarEvent,
  Note,
  JournalEntry,
  Habit,
  Goal,
  Project,
  FinanceTransaction,
  Budget,
  FinanceSummary,
  DailyHealthSummary,
  FocusSummary,
  StoredFile,
  AiConversation,
  NotificationItem,
  OverallProductivityScore,
} from '../types';

export const mockUser: User = {
  id: 1,
  email: 'demo@nivor.app',
  fullName: 'Alexander Wright',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
  role: 'ROLE_USER',
  settings: {
    theme: 'dark',
    accentColor: 'system_blue',
    soundEffectsEnabled: true,
    hapticFeedback: true,
    aiMemoryEnabled: true,
    aiPersonality: 'Apple Intelligence Executive',
    emailNotifications: true,
    pushNotifications: true,
    weeklySummaryEmail: true,
    timeZone: 'America/New_York',
    dateFormat: 'MM/DD/YYYY',
  },
  createdAt: '2026-01-01T00:00:00Z',
};

export const mockProjects: Project[] = [
  {
    id: 1,
    name: 'Quantum OS 3.0 Launch',
    description: 'Next generation spatial interface and desktop companion suite',
    color: '#0A84FF',
    icon: 'Layers',
    status: 'ACTIVE',
    viewMode: 'KANBAN',
    taskCount: 3,
    completedTaskCount: 1,
    createdAt: '2026-09-01T08:00:00Z',
  },
  {
    id: 2,
    name: 'Personal Health & Fitness',
    description: 'Daily nutrition, marathon conditioning, and sleep architecture',
    color: '#30D158',
    icon: 'Heart',
    status: 'ACTIVE',
    viewMode: 'LIST',
    taskCount: 2,
    completedTaskCount: 1,
    createdAt: '2026-09-02T08:00:00Z',
  },
  {
    id: 3,
    name: 'Angel Portfolio & Wealth',
    description: 'Q3 Angel investments, index DCA, and real estate review',
    color: '#FF9F0A',
    icon: 'TrendingUp',
    status: 'ACTIVE',
    viewMode: 'KANBAN',
    taskCount: 1,
    completedTaskCount: 0,
    createdAt: '2026-09-03T08:00:00Z',
  },
];

export const mockTasks: Task[] = [
  {
    id: 1,
    title: 'Review Apple Human Interface guidelines for VisionOS widgets',
    description: 'Audit frosted glass material curves and optical physics',
    projectId: 1,
    projectName: 'Quantum OS 3.0 Launch',
    status: 'COMPLETED',
    priority: 'HIGH',
    dueDate: new Date().toISOString(),
    estimatedMinutes: 45,
    orderIndex: 1,
    completedAt: new Date().toISOString(),
    tags: 'Design,Spatial',
  },
  {
    id: 2,
    title: 'Finalize Spring Boot 3 & JWT token rotation security layer',
    description: 'Add rate limiting, CSRF tokens, and secure cookie storage headers',
    projectId: 1,
    projectName: 'Quantum OS 3.0 Launch',
    status: 'IN_PROGRESS',
    priority: 'URGENT',
    dueDate: new Date(Date.now() + 2 * 3600 * 1000).toISOString(),
    estimatedMinutes: 90,
    orderIndex: 2,
    tags: 'Security,Backend',
  },
  {
    id: 3,
    title: 'Design Dynamic Island floating audio & timer indicator',
    description: 'Framer motion spring animation with zero layout shift',
    projectId: 1,
    projectName: 'Quantum OS 3.0 Launch',
    status: 'TODO',
    priority: 'HIGH',
    dueDate: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
    estimatedMinutes: 60,
    orderIndex: 3,
    tags: 'Frontend,Animation',
  },
  {
    id: 4,
    title: 'Morning 7km Zone 2 aerobic recovery run',
    description: 'Target HR: 135-142 bpm along coastal trail',
    projectId: 2,
    projectName: 'Personal Health & Fitness',
    status: 'COMPLETED',
    priority: 'MEDIUM',
    dueDate: new Date().toISOString(),
    estimatedMinutes: 40,
    orderIndex: 4,
    completedAt: new Date().toISOString(),
    tags: 'Cardio,Recovery',
  },
  {
    id: 5,
    title: 'Cold plunge + 20 min infrared sauna protocol',
    description: 'Boost mitochondrial density and post-workout recovery',
    projectId: 2,
    projectName: 'Personal Health & Fitness',
    status: 'TODO',
    priority: 'MEDIUM',
    dueDate: new Date(Date.now() + 4 * 3600 * 1000).toISOString(),
    estimatedMinutes: 30,
    orderIndex: 5,
    tags: 'Wellness',
  },
  {
    id: 6,
    title: 'Quarterly dividend re-allocation to Vanguard Total Market',
    description: 'Rebalance portfolio allocations to 75/20/5 equity split',
    projectId: 3,
    projectName: 'Angel Portfolio & Wealth',
    status: 'TODO',
    priority: 'LOW',
    dueDate: new Date(Date.now() + 3 * 24 * 3600 * 1000).toISOString(),
    estimatedMinutes: 25,
    orderIndex: 6,
    tags: 'Wealth,Investing',
  },
];

export const mockEvents: CalendarEvent[] = [
  {
    id: 1,
    title: 'Product Architecture Sync with Executive Team',
    description: 'Review NIVOR Spring Boot + React 19 production readiness',
    location: 'Infinite Loop Room 4B / Zoom',
    startTime: new Date(Date.now() + 3600 * 1000).toISOString(),
    endTime: new Date(Date.now() + 2 * 3600 * 1000).toISOString(),
    isAllDay: false,
    color: '#0A84FF',
    category: 'Work',
    syncSource: 'NIVOR',
  },
  {
    id: 2,
    title: 'AI Productivity Keynote & Live Demo',
    description: 'Showcase deep work AI assistant and live scheduling sync',
    location: 'Auditorium A',
    startTime: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
    endTime: new Date(Date.now() + 25.5 * 3600 * 1000).toISOString(),
    isAllDay: false,
    color: '#BF5AF2',
    category: 'Keynote',
    syncSource: 'GOOGLE',
  },
  {
    id: 3,
    title: 'Family Dinner & Wine Tasting',
    description: 'Celebrate quarterly launch milestones',
    location: 'L’Artisan Bistro',
    startTime: new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
    endTime: new Date(Date.now() + 51 * 3600 * 1000).toISOString(),
    isAllDay: false,
    color: '#FF375F',
    category: 'Personal',
    syncSource: 'APPLE',
  },
];

export const mockHabits: Habit[] = [
  {
    id: 1,
    name: 'Deep Work Focus Block (90m)',
    description: 'Zero notifications, high cognitive output',
    frequency: 'DAILY',
    targetCountPerDay: 2,
    unit: 'sessions',
    color: '#0A84FF',
    icon: 'Zap',
    currentStreak: 14,
    longestStreak: 28,
    completedToday: true,
    todayCount: 2,
    pastWeekStatus: {
      '2026-09-11': true,
      '2026-09-12': true,
      '2026-09-13': true,
      '2026-09-14': true,
      '2026-09-15': true,
      '2026-09-16': true,
      '2026-09-17': true,
    },
  },
  {
    id: 2,
    name: 'Hydrate 3.5 Liters',
    description: 'Structured electrolyte spring water intake',
    frequency: 'DAILY',
    targetCountPerDay: 3500,
    unit: 'ml',
    color: '#64D2FF',
    icon: 'Droplets',
    currentStreak: 21,
    longestStreak: 45,
    completedToday: true,
    todayCount: 3200,
    pastWeekStatus: {
      '2026-09-11': true,
      '2026-09-12': true,
      '2026-09-13': true,
      '2026-09-14': true,
      '2026-09-15': true,
      '2026-09-16': true,
      '2026-09-17': true,
    },
  },
  {
    id: 3,
    name: 'Read 30 Pages Non-Fiction',
    description: 'Philosophy, distributed systems, architecture',
    frequency: 'DAILY',
    targetCountPerDay: 30,
    unit: 'pages',
    color: '#FF9F0A',
    icon: 'BookOpen',
    currentStreak: 9,
    longestStreak: 32,
    completedToday: true,
    todayCount: 30,
    pastWeekStatus: {
      '2026-09-11': true,
      '2026-09-12': false,
      '2026-09-13': true,
      '2026-09-14': true,
      '2026-09-15': true,
      '2026-09-16': true,
      '2026-09-17': true,
    },
  },
  {
    id: 4,
    name: 'Daily Gratitude & Reflection',
    description: 'Record three breakthroughs before sleep',
    frequency: 'DAILY',
    targetCountPerDay: 1,
    unit: 'entry',
    color: '#30D158',
    icon: 'Sparkles',
    currentStreak: 35,
    longestStreak: 35,
    completedToday: true,
    todayCount: 1,
    pastWeekStatus: {
      '2026-09-11': true,
      '2026-09-12': true,
      '2026-09-13': true,
      '2026-09-14': true,
      '2026-09-15': true,
      '2026-09-16': true,
      '2026-09-17': true,
    },
  },
];

export const mockNotes: Note[] = [
  {
    id: 1,
    title: 'NIVOR High-Performance Architecture Blueprint',
    content: `# NIVOR System Architecture

- **Client**: React 19, TypeScript, Tailwind CSS, Framer Motion
- **State**: Zustand + TanStack Query
- **Backend**: Spring Boot 3.3, Java 21, Spring Security 6
- **Database**: MySQL 8.0 with InnoDB connection pooling
- **Theme**: Apple Liquid Retina Glassmorphism

### Core Invariants:
1. Sub-16ms layout rendering (60-120fps physics animations).
2. Zero unauthorized data leakage with HMAC-SHA256 JWT filters.
3. Offline-resilient caching with seamless backend synchronization.`,
    summary: 'Key architectural decisions and runtime benchmarks for NIVOR OS',
    isPinned: true,
    color: '#0A84FF',
    tags: 'Engineering,Architecture',
    createdAt: '2026-09-10T10:00:00Z',
    updatedAt: '2026-09-17T18:30:00Z',
  },
  {
    id: 2,
    title: 'Daily Executive Mental Models',
    content: `### High-Leverage Thinking Frameworks

1. **Inversion Principle**: Instead of asking how to succeed, analyze how to guarantee failure and systematically avoid those traps.
2. **First Principles Thinking**: Strip a problem down to fundamental physical truths and reason upward.
3. **Second-Order Effects**: Always ask "And then what?" when choosing technical tradeoffs.`,
    summary: 'Core decision frameworks for high-leverage execution',
    isPinned: false,
    color: '#FF9F0A',
    tags: 'Mindset,Productivity',
    createdAt: '2026-09-12T14:00:00Z',
    updatedAt: '2026-09-16T11:20:00Z',
  },
  {
    id: 3,
    title: 'VisionOS Spatial Interaction Design Notes',
    content: `Key findings from Apple HIG:
- Eye gaze + subtle pinch gestures require forgiving hit targets (minimum 44x44pt).
- Dynamic lighting highlights elevate layered cards in 3D perspective.
- Avoid pure black in favor of deep translucent frosted midnight.`,
    summary: 'Design notes regarding spatial computing hitboxes and materials',
    isPinned: false,
    color: '#BF5AF2',
    tags: 'Design,VisionOS',
    createdAt: '2026-09-14T09:00:00Z',
    updatedAt: '2026-09-15T16:00:00Z',
  },
];

export const mockJournals: JournalEntry[] = [
  {
    id: 1,
    title: 'Clarity, Focus, and Architectural Symmetry',
    content: 'Today felt like a turning point. We successfully merged the high-performance Spring Boot backend with our bespoke React 19 UI. The fluid animations at 120fps feel indistinguishable from a native macOS app. The cognitive clarity when your entire digital workspace feels unified is unparalleled.',
    mood: 5,
    moodLabel: 'Ecstatic',
    gratitudeList: [
      'Seamless compilation with zero regressions',
      'Sunny morning run along the harbor breeze',
      'Crisp espresso with the product design team',
    ],
    weather: 'Clear 71°F',
    location: 'San Francisco, CA',
    entryDate: '2026-09-17',
    createdAt: '2026-09-17T21:00:00Z',
  },
  {
    id: 2,
    title: 'Iterative Refinement & Flow State',
    content: 'Spent the morning polishing Framer Motion spring physics. Small touches like tactile sound haptics and glassmorphism highlight borders elevate the software into something people love touching.',
    mood: 4,
    moodLabel: 'Inspired',
    gratitudeList: [
      'Deep flow uninterrupted for 3 hours',
      'Clean architectural separation of concerns',
    ],
    weather: 'Partly Cloudy 68°F',
    location: 'Cupertino, CA',
    entryDate: '2026-09-16',
    createdAt: '2026-09-16T20:30:00Z',
  },
];

export const mockGoals: Goal[] = [
  {
    id: 1,
    title: 'Scale NIVOR to 100,000 Active Daily Power Users',
    description: 'Achieve zero-downtime micro-latency performance and 4.9 App Store rating',
    category: 'Career',
    targetDate: '2026-12-31',
    progressPercentage: 68,
    status: 'IN_PROGRESS',
    color: '#0A84FF',
    aiRoadmap: 'Phase 1: Zero-latency backend; Phase 2: Offline sync; Phase 3: Global CDN distribution.',
    milestones: [
      { id: 1, goalId: 1, title: 'Deploy Spring Boot 3 clustered container to Render', isCompleted: true, orderIndex: 1 },
      { id: 2, goalId: 1, title: 'Complete Apple Design HIG audit for dark/light themes', isCompleted: true, orderIndex: 2 },
      { id: 3, goalId: 1, title: 'Integrate multimodal AI contextual memory engine', isCompleted: false, orderIndex: 3 },
    ],
  },
  {
    id: 2,
    title: 'Sub-3:30 Marathon Finish Time',
    description: 'Complete Tokyo Marathon with negative splits',
    category: 'Health',
    targetDate: '2027-03-01',
    progressPercentage: 45,
    status: 'IN_PROGRESS',
    color: '#30D158',
    aiRoadmap: 'Maintain weekly 65km mileage with 1 threshold tempo session and structured taper.',
    milestones: [
      { id: 4, goalId: 2, title: 'Hit 25km long run in under 2h 10m', isCompleted: true, orderIndex: 1 },
      { id: 5, goalId: 2, title: 'Optimize nutrition and 800ml/hr race fueling', isCompleted: false, orderIndex: 2 },
    ],
  },
];

export const mockFinanceSummary: FinanceSummary = {
  totalIncome: 12500,
  totalExpense: 3450,
  netSavings: 9050,
  savingsRate: 72.4,
  budgets: [
    { id: 1, category: 'Tech & Cloud', monthlyLimit: 2000, spentAmount: 720.5, remainingAmount: 1279.5, percentageUsed: 36.0, monthYear: '2026-09' },
    { id: 2, category: 'Organic Food & Nutrition', monthlyLimit: 1200, spentAmount: 480.2, remainingAmount: 719.8, percentageUsed: 40.0, monthYear: '2026-09' },
    { id: 3, category: 'Travel & Mobility', monthlyLimit: 1500, spentAmount: 320.0, remainingAmount: 1180.0, percentageUsed: 21.3, monthYear: '2026-09' },
  ],
  recentTransactions: [
    { id: 1, title: 'Enterprise AI SaaS Retainer', amount: 12500, type: 'INCOME', category: 'Consulting', currency: 'USD', isRecurring: true, transactionDate: '2026-09-17' },
    { id: 2, title: 'AWS High-Performance Cloud Cluster', amount: 420.5, type: 'EXPENSE', category: 'Tech & Cloud', currency: 'USD', isRecurring: true, transactionDate: '2026-09-15' },
    { id: 3, title: 'Apple Developer Enterprise Program', amount: 299, type: 'EXPENSE', category: 'Software', currency: 'USD', isRecurring: false, transactionDate: '2026-09-12' },
    { id: 4, title: 'Whole Foods Organic Groceries', amount: 184.2, type: 'EXPENSE', category: 'Organic Food & Nutrition', currency: 'USD', isRecurring: false, transactionDate: '2026-09-17' },
  ],
  categoryBreakdown: {
    'Tech & Cloud': 720.5,
    'Organic Food & Nutrition': 480.2,
    'Travel & Mobility': 320.0,
    'Software': 299.0,
  },
  activeSubscriptions: [
    { id: 101, title: 'Claude 3.5 Sonnet / OpenAI Pro', amount: 40, type: 'EXPENSE', category: 'Tech', currency: 'USD', isRecurring: true, recurrencePeriod: 'MONTHLY', transactionDate: '2026-09-01' },
    { id: 102, title: 'GitHub Enterprise Suite', amount: 21, type: 'EXPENSE', category: 'Tech', currency: 'USD', isRecurring: true, recurrencePeriod: 'MONTHLY', transactionDate: '2026-09-01' },
    { id: 103, title: 'Equinox All-Access Athletic Membership', amount: 320, type: 'EXPENSE', category: 'Fitness', currency: 'USD', isRecurring: true, recurrencePeriod: 'MONTHLY', transactionDate: '2026-09-01' },
  ],
};

export const mockHealthSummary: DailyHealthSummary = {
  date: '2026-09-17',
  waterMl: 3200,
  waterTargetMl: 3500,
  sleepHours: 8.2,
  sleepTargetHours: 8.0,
  steps: 12450,
  stepsTarget: 10000,
  weightKg: 74.5,
  workoutMinutes: 55,
  rawMetrics: [],
};

export const mockFocusSummary: FocusSummary = {
  todayMinutes: 115,
  weekMinutes: 870,
  todayCompletedSessions: 3,
  averageRating: 4.8,
  recentSessions: [
    { id: 1, sessionType: 'DEEP_WORK', durationMinutes: 90, productivityRating: 5, tag: 'Backend Engineering', soundtrack: 'Rainy Forest', completedAt: '2026-09-17T11:30:00Z' },
    { id: 2, sessionType: 'POMODORO', durationMinutes: 25, productivityRating: 4, tag: 'UI Polish', soundtrack: 'Lo-Fi Chill', completedAt: '2026-09-17T14:15:00Z' },
  ],
  tagDistribution: {
    'Backend Engineering': 480,
    'UI Polish': 210,
    'Design System': 180,
  },
};

export const mockFiles: StoredFile[] = [
  { id: 1, name: 'NIVOR_System_Architecture_v3.pdf', fileType: 'application/pdf', fileSizeBytes: 2450000, storagePath: '/docs/arch.pdf', folder: 'Documents', tags: 'Architecture,PDF', createdAt: '2026-09-15T12:00:00Z' },
  { id: 2, name: 'Apple_HIG_Design_Tokens_2026.fig', fileType: 'application/octet-stream', fileSizeBytes: 18400000, storagePath: '/design/tokens.fig', folder: 'Design', tags: 'Figma,HIG', createdAt: '2026-09-16T09:30:00Z' },
  { id: 3, name: 'Financial_Projections_Q4.xlsx', fileType: 'application/vnd.ms-excel', fileSizeBytes: 890000, storagePath: '/finance/q4.xlsx', folder: 'Finance', tags: 'Finance,Excel', createdAt: '2026-09-14T15:20:00Z' },
];

export const mockAiConversations: AiConversation[] = [
  {
    id: 1,
    title: 'Daily High-Leverage Schedule Optimization',
    contextMode: 'SCHEDULE_OPTIMIZER',
    messages: [
      { id: 1, sender: 'USER', content: 'Good morning. Analyze my tasks today and organize them for peak cognitive output.', createdAt: '2026-09-17T08:30:00Z' },
      { id: 2, sender: 'AI', content: `Good morning Alexander. I have organized your day based on ultradian circadian rhythms:

• **09:00 - 10:30**: ⚡ **Deep Work Block** (Spring Boot 3 JWT Security Layer)
• **11:00 - 12:00**: 📅 **Product Architecture Sync**
• **14:00 - 15:00**: 🎨 **Framer Motion Dynamic Island Polish**
• **17:00 - 17:45**: 🏃 **7km Zone 2 Aerobic Recovery Run**

Your productivity readiness is rated **96% (Optimal Flow)**. Shall I set your focus timers automatically?`, createdAt: '2026-09-17T08:30:05Z' },
    ],
    updatedAt: '2026-09-17T08:30:05Z',
  },
];

export const mockNotifications: NotificationItem[] = [
  { id: 1, title: 'Deep Work Goal Reached', body: 'You have logged 115 minutes of uninterrupted focus today.', type: 'FOCUS_NUDGE', isRead: false, createdAt: '2026-09-17T15:00:00Z' },
  { id: 2, title: 'Habit Streak Milestone', body: '🔥 14-day streak active on Deep Work Focus Block!', type: 'HABIT_STREAK', isRead: false, createdAt: '2026-09-17T12:00:00Z' },
  { id: 3, title: 'Budget Alert', body: 'Tech & Cloud budget is at 36% with 13 days remaining in month.', type: 'BILL_ALERT', isRead: true, createdAt: '2026-09-16T18:00:00Z' },
];

export const mockProductivityScore: OverallProductivityScore = {
  overallScore: 92,
  taskScore: 95,
  habitScore: 92,
  focusScore: 88,
  healthScore: 91,
  grade: 'S',
  aiInsight: 'Your deep work consistency is 22% higher than your 30-day baseline. Morning timeblocking before 11:00 AM continues to be your highest-output window.',
  pastWeekScores: [
    { dayName: 'Fri', date: '2026-09-11', score: 88, tasksCompleted: 5, focusMinutes: 90 },
    { dayName: 'Sat', date: '2026-09-12', score: 85, tasksCompleted: 3, focusMinutes: 60 },
    { dayName: 'Sun', date: '2026-09-13', score: 82, tasksCompleted: 2, focusMinutes: 45 },
    { dayName: 'Mon', date: '2026-09-14', score: 94, tasksCompleted: 6, focusMinutes: 120 },
    { dayName: 'Tue', date: '2026-09-15', score: 91, tasksCompleted: 5, focusMinutes: 105 },
    { dayName: 'Wed', date: '2026-09-16', score: 96, tasksCompleted: 7, focusMinutes: 140 },
    { dayName: 'Thu', date: '2026-09-17', score: 92, tasksCompleted: 4, focusMinutes: 115 },
  ],
};
