export type ThemeMode = 'dark' | 'light' | 'system';
export type AccentColor = 'system_blue' | 'purple' | 'orange' | 'emerald' | 'rose' | 'cyan' | 'gold';

export interface UserSettings {
  id?: number;
  theme: ThemeMode;
  accentColor: AccentColor;
  soundEffectsEnabled: boolean;
  hapticFeedback: boolean;
  aiMemoryEnabled: boolean;
  aiPersonality: string;
  emailNotifications: boolean;
  pushNotifications: boolean;
  weeklySummaryEmail: boolean;
  timeZone: string;
  dateFormat: string;
}

export interface User {
  id: number;
  email: string;
  fullName: string;
  avatarUrl?: string;
  role: string;
  settings?: UserSettings;
  createdAt?: string;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface Task {
  id: number;
  title: string;
  description?: string;
  projectId?: number;
  projectName?: string;
  status: 'TODO' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELED';
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
  dueDate?: string;
  reminderAt?: string;
  recurrenceRule?: string;
  tags?: string;
  estimatedMinutes?: number;
  orderIndex: number;
  completedAt?: string;
  createdAt?: string;
}

export interface CalendarEvent {
  id: number;
  title: string;
  description?: string;
  location?: string;
  startTime: string;
  endTime: string;
  isAllDay: boolean;
  color: string;
  category: string;
  syncSource: 'NIVOR' | 'GOOGLE' | 'OUTLOOK' | 'APPLE';
  createdAt?: string;
}

export interface Note {
  id: number;
  title: string;
  content: string;
  summary?: string;
  isPinned: boolean;
  color: string;
  tags?: string;
  folderId?: number;
  createdAt: string;
  updatedAt: string;
}

export interface JournalEntry {
  id: number;
  title: string;
  content: string;
  mood: number; // 1-5
  moodLabel: string;
  gratitudeList?: string | string[];
  weather: string;
  location?: string;
  voiceMemoUrl?: string;
  entryDate: string;
  createdAt?: string;
}

export interface Habit {
  id: number;
  name: string;
  description?: string;
  frequency: string;
  targetCountPerDay: number;
  unit: string;
  color: string;
  icon: string;
  currentStreak: number;
  longestStreak: number;
  completedToday: boolean;
  todayCount: number;
  pastWeekStatus: Record<string, boolean>;
  createdAt?: string;
}

export interface Milestone {
  id: number;
  goalId: number;
  title: string;
  dueDate?: string;
  isCompleted: boolean;
  orderIndex: number;
}

export interface Goal {
  id: number;
  title: string;
  description?: string;
  category: string;
  targetDate?: string;
  progressPercentage: number;
  status: 'IN_PROGRESS' | 'ACHIEVED' | 'PAUSED';
  color: string;
  aiRoadmap?: string;
  milestones: Milestone[];
  createdAt?: string;
}

export interface Project {
  id: number;
  name: string;
  description?: string;
  color: string;
  icon: string;
  status: 'ACTIVE' | 'COMPLETED' | 'ARCHIVED';
  viewMode: 'KANBAN' | 'LIST' | 'TIMELINE';
  taskCount: number;
  completedTaskCount: number;
  createdAt?: string;
}

export interface FinanceTransaction {
  id: number;
  title: string;
  amount: number;
  type: 'INCOME' | 'EXPENSE';
  category: string;
  currency: string;
  isRecurring: boolean;
  recurrencePeriod?: string;
  transactionDate: string;
  notes?: string;
}

export interface Budget {
  id: number;
  category: string;
  monthlyLimit: number;
  spentAmount: number;
  remainingAmount: number;
  percentageUsed: number;
  monthYear: string;
}

export interface FinanceSummary {
  totalIncome: number;
  totalExpense: number;
  netSavings: number;
  savingsRate: number;
  budgets: Budget[];
  recentTransactions: FinanceTransaction[];
  categoryBreakdown: Record<string, number>;
  activeSubscriptions: FinanceTransaction[];
}

export interface HealthMetric {
  id: number;
  type: 'WATER_ML' | 'SLEEP_HOURS' | 'STEPS' | 'WEIGHT_KG' | 'WORKOUT_MIN';
  value: number;
  unit: string;
  notes?: string;
  loggedAt: string;
}

export interface DailyHealthSummary {
  date: string;
  waterMl: number;
  waterTargetMl: number;
  sleepHours: number;
  sleepTargetHours: number;
  steps: number;
  stepsTarget: number;
  weightKg: number;
  workoutMinutes: number;
  rawMetrics: HealthMetric[];
}

export interface FocusSession {
  id: number;
  sessionType: 'POMODORO' | 'DEEP_WORK' | 'SHORT_BREAK' | 'LONG_BREAK';
  durationMinutes: number;
  productivityRating: number;
  tag: string;
  soundtrack: string;
  completedAt: string;
}

export interface FocusSummary {
  todayMinutes: number;
  weekMinutes: number;
  todayCompletedSessions: number;
  averageRating: number;
  recentSessions: FocusSession[];
  tagDistribution: Record<string, number>;
}

export interface StoredFile {
  id: number;
  name: string;
  fileType: string;
  fileSizeBytes: number;
  storagePath: string;
  folder: string;
  tags?: string;
  ocrExtractedText?: string;
  createdAt: string;
}

export interface AiMessage {
  id: number;
  sender: 'USER' | 'AI' | 'SYSTEM';
  content: string;
  tokensUsed?: number;
  structuredActionJson?: string;
  createdAt: string;
}

export interface AiConversation {
  id: number;
  title: string;
  contextMode: string;
  messages: AiMessage[];
  updatedAt: string;
}

export interface NotificationItem {
  id: number;
  title: string;
  body: string;
  type: 'TASK_REMINDER' | 'HABIT_STREAK' | 'BILL_ALERT' | 'FOCUS_NUDGE' | 'SYSTEM';
  isRead: boolean;
  actionUrl?: string;
  createdAt: string;
}

export interface OverallProductivityScore {
  overallScore: number;
  taskScore: number;
  habitScore: number;
  focusScore: number;
  healthScore: number;
  grade: string;
  aiInsight: string;
  pastWeekScores: {
    dayName: string;
    date: string;
    score: number;
    tasksCompleted: number;
    focusMinutes: number;
  }[];
}
