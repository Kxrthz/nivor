import React from 'react';
import { motion } from 'framer-motion';

interface VoiceOrbProps {
  isListening?: boolean;
  size?: number;
}

export const VoiceOrb: React.FC<VoiceOrbProps> = ({
  isListening = false,
  size = 120,
}) => {
  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      {/* Outer Glow Halo */}
      <motion.div
        animate={{
          scale: isListening ? [1, 1.3, 1.05, 1.25, 1] : [1, 1.1, 1],
          opacity: isListening ? [0.6, 0.9, 0.6] : [0.4, 0.6, 0.4],
        }}
        transition={{
          repeat: Infinity,
          duration: isListening ? 2.5 : 5,
          ease: 'easeInOut',
        }}
        className="absolute inset-0 rounded-full blur-2xl bg-gradient-to-tr from-blue-500 via-purple-500 to-pink-500 opacity-60 pointer-events-none"
      />

      {/* Dynamic Swirling Core */}
      <motion.div
        animate={{
          rotate: 360,
          scale: isListening ? [0.95, 1.1, 0.95] : [1, 1.03, 1],
        }}
        transition={{
          rotate: { repeat: Infinity, duration: 10, ease: 'linear' },
          scale: { repeat: Infinity, duration: 3, ease: 'easeInOut' },
        }}
        className="w-4/5 h-4/5 rounded-full bg-gradient-to-br from-cyan-400 via-indigo-500 to-fuchsia-500 shadow-2xl p-1 relative overflow-hidden backdrop-blur-md"
      >
        <div className="w-full h-full rounded-full bg-gradient-to-tr from-black/40 to-transparent flex items-center justify-center">
          <div className="w-1/3 h-1/3 rounded-full bg-white/40 blur-sm" />
        </div>
      </motion.div>
    </div>
  );
};
