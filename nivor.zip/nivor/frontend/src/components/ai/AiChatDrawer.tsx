import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Sparkles, Mic, MicOff, BookOpen, Calendar, Activity, Bot } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { Button } from '../ui/Button';
import { VoiceOrb } from './VoiceOrb';
import { AiMessage } from '../../types';

export const AiChatDrawer: React.FC = () => {
  const { isAiDrawerOpen, setAiDrawerOpen } = useAppStore();
  const [messages, setMessages] = useState<AiMessage[]>([
    {
      id: 1,
      sender: 'AI',
      content: 'Good day Alexander. I am your NIVOR Executive Intelligence. How can I optimize your schedule, study curriculum, or workout today?',
      createdAt: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isAiDrawerOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isAiDrawerOpen, isTyping]);

  if (!isAiDrawerOpen) return null;

  const handleSend = (textToSend?: string) => {
    const prompt = textToSend || input;
    if (!prompt.trim()) return;

    const userMsg: AiMessage = {
      id: Date.now(),
      sender: 'USER',
      content: prompt,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      let replyText = 'I have updated your schedule and calibrated your priority matrix. Your energy reserves are optimal for high-focus deep work.';
      const p = prompt.toLowerCase();
      if (p.includes('schedule') || p.includes('plan') || p.includes('day')) {
        replyText = `### 📅 High-Leverage Schedule Blueprint\n\n• **09:00 - 10:30**: ⚡ **Deep Work Block** (Spring Boot 3 Security Refactor)\n• **11:00 - 12:00**: 🤝 **Product Architecture Sync**\n• **14:00 - 15:30**: 🎯 **VisionOS UI Micro-Interactions**\n• **17:00 - 17:45**: 🏃 **7km Aerobic Recovery Run**\n\nAll blocks have been mirrored to your NIVOR Calendar.`;
      } else if (p.includes('workout') || p.includes('fitness')) {
        replyText = `### 🏋️ Personalized Hypertrophy & Conditioning Protocol\n\n1. **Incline DB Press**: 4 sets x 8 reps (RPE 8)\n2. **Neutral Grip Weighted Pullups**: 4 sets x 6 reps\n3. **Bulgarian Split Squats**: 3 sets x 12 reps per leg\n4. **Zone 2 Cardio**: 25 min at 135 bpm target HR.\n\nLogged directly to NIVOR Health.`;
      } else if (p.includes('study') || p.includes('learn')) {
        replyText = `### 📘 14-Day Distributed Systems Mastery\n\n- **Day 1–4**: Consensus Algorithms (Raft & Paxos invariants)\n- **Day 5–9**: High-Throughput Write Pipelines & LSM Trees\n- **Day 10–14**: Failure Injections & Micro-benchmark optimization\n\nMilestones added to your Goals tracker!`;
      }

      const aiMsg: AiMessage = {
        id: Date.now() + 1,
        sender: 'AI',
        content: replyText,
        createdAt: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, aiMsg]);
      setIsTyping(false);
    }, 1000);
  };

  const quickPrompts = [
    { title: 'Optimize My Day', icon: Calendar },
    { title: 'Study Plan', icon: BookOpen },
    { title: 'Workout Protocol', icon: Activity },
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex justify-end pointer-events-none">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setAiDrawerOpen(false)}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm pointer-events-auto"
        />

        {/* Slide-out Drawer */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 28, stiffness: 350 }}
          className="relative w-full max-w-md h-full bg-apple-gray-900/95 dark:bg-black/95 backdrop-blur-3xl border-l border-white/15 p-5 shadow-2xl flex flex-col pointer-events-auto z-10"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-apple-blue to-apple-purple flex items-center justify-center shadow-apple-glow">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white leading-tight">Apple Intelligence</h3>
                <p className="text-[10px] text-apple-gray-400 font-medium">NIVOR Neural Engine</p>
              </div>
            </div>

            <button
              onClick={() => setAiDrawerOpen(false)}
              className="p-1.5 rounded-full text-apple-gray-400 hover:text-white hover:bg-white/10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Voice Orb Area (when active) */}
          {isVoiceActive && (
            <div className="py-6 flex flex-col items-center justify-center border-b border-white/10">
              <VoiceOrb isListening={true} size={110} />
              <p className="text-xs text-apple-gray-300 font-medium mt-3 animate-pulse">
                Listening to your prompt...
              </p>
            </div>
          )}

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto py-4 space-y-3.5 pr-1">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex gap-2.5 ${m.sender === 'USER' ? 'justify-end' : 'justify-start'}`}
              >
                {m.sender === 'AI' && (
                  <div className="w-6 h-6 rounded-lg bg-apple-blue/20 text-apple-blue flex items-center justify-center shrink-0 mt-0.5">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                )}
                <div
                  className={`max-w-[82%] px-4 py-2.5 rounded-2xl text-xs leading-relaxed ${
                    m.sender === 'USER'
                      ? 'bg-apple-blue text-white rounded-br-sm shadow-sm'
                      : 'glass-card text-apple-gray-100 rounded-bl-sm border border-white/10 whitespace-pre-line'
                  }`}
                >
                  {m.content}
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center gap-2 text-apple-gray-400 text-xs pl-8">
                <span className="w-1.5 h-1.5 rounded-full bg-apple-blue animate-ping" />
                <span>NIVOR AI is thinking...</span>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Quick Prompts */}
          <div className="flex gap-2 pb-3 overflow-x-auto no-scrollbar">
            {quickPrompts.map((q) => (
              <button
                key={q.title}
                onClick={() => handleSend(q.title)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] text-apple-gray-300 hover:text-white shrink-0 transition-colors"
              >
                <q.icon className="w-3 h-3 text-apple-blue" />
                <span>{q.title}</span>
              </button>
            ))}
          </div>

          {/* Input Box */}
          <div className="pt-2 border-t border-white/10 flex items-center gap-2">
            <button
              onClick={() => setIsVoiceActive(!isVoiceActive)}
              className={`p-2.5 rounded-xl border transition-colors ${
                isVoiceActive
                  ? 'bg-apple-red/20 text-apple-red border-apple-red/40 animate-pulse'
                  : 'text-apple-gray-400 hover:text-white bg-white/5 border-white/10'
              }`}
              title="Voice Mode"
            >
              {isVoiceActive ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask NIVOR AI anything..."
              className="flex-1 glass-input rounded-xl px-4 py-2 text-xs text-white placeholder:text-apple-gray-500 focus:outline-none"
            />

            <Button
              size="sm"
              variant="primary"
              onClick={() => handleSend()}
              icon={<Send className="w-3.5 h-3.5" />}
            >
              <span></span>
            </Button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
