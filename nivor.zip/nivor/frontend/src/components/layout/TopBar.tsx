import React, { useEffect, useState } from 'react';
import { Search, Plus, Sparkles, Moon, Sun, Bell, Command, Volume2 } from 'lucide-react';
import { useThemeStore } from '../../store/useThemeStore';
import { useAppStore } from '../../store/useAppStore';
import { useAudioStore } from '../../store/useAudioStore';
import { Button } from '../ui/Button';
import { AccentColor } from '../../types';

export const TopBar: React.FC = () => {
  const { theme, toggleTheme, accentColor, setAccentColor } = useThemeStore();
  const { setSearchOpen, setAiDrawerOpen, setQuickActionOpen, notifications } = useAppStore();
  const { currentTrack, togglePlay } = useAudioStore();
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleDateString('en-US', {
          weekday: 'short',
          month: 'short',
          day: 'numeric',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const accentOptions: { color: AccentColor; hex: string }[] = [
    { color: 'system_blue', hex: '#0A84FF' },
    { color: 'purple', hex: '#BF5AF2' },
    { color: 'emerald', hex: '#30D158' },
    { color: 'orange', hex: '#FF9F0A' },
    { color: 'rose', hex: '#FF375F' },
    { color: 'cyan', hex: '#64D2FF' },
  ];

  return (
    <header className="h-16 sticky top-0 z-20 px-4 sm:px-8 flex items-center justify-between border-b border-white/10 dark:border-white/5 bg-black/40 backdrop-blur-2xl">
      {/* Left: Date / Greeting */}
      <div className="flex items-center gap-3">
        <span className="text-xs font-semibold text-apple-gray-400 uppercase tracking-wider">
          {timeStr}
        </span>
      </div>

      {/* Center: Global Spotlight Search Trigger */}
      <button
        onClick={() => setSearchOpen(true)}
        className="hidden sm:flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-apple-gray-400 hover:text-white transition-all text-xs font-medium w-64 md:w-80 justify-between group"
      >
        <span className="flex items-center gap-2">
          <Search className="w-3.5 h-3.5 group-hover:text-apple-blue transition-colors" />
          <span>Spotlight Search...</span>
        </span>
        <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-[10px] text-apple-gray-300 font-mono border border-white/10 flex items-center gap-0.5">
          <Command className="w-2.5 h-2.5" /> K
        </kbd>
      </button>

      {/* Right Action Icons */}
      <div className="flex items-center gap-2">
        {/* Ambient Noise Quick Button */}
        <button
          onClick={togglePlay}
          title={`Ambient Sound: ${currentTrack}`}
          className={`p-2 rounded-xl border border-white/10 transition-colors ${
            currentTrack !== 'None'
              ? 'bg-apple-blue/20 text-apple-blue border-apple-blue/30'
              : 'text-apple-gray-400 hover:text-white hover:bg-white/10'
          }`}
        >
          <Volume2 className="w-4 h-4" />
        </button>

        {/* Dynamic Accent Color Quick-Palette */}
        <div className="hidden md:flex items-center gap-1 px-2 py-1 bg-white/5 border border-white/10 rounded-xl">
          {accentOptions.map((a) => (
            <button
              key={a.color}
              onClick={() => setAccentColor(a.color)}
              className={`w-3.5 h-3.5 rounded-full transition-transform ${
                accentColor === a.color ? 'scale-125 ring-2 ring-white/50' : 'hover:scale-110 opacity-70 hover:opacity-100'
              }`}
              style={{ backgroundColor: a.hex }}
              title={a.color}
            />
          ))}
        </div>

        {/* Theme Toggle */}
        <button
          onClick={toggleTheme}
          className="p-2 rounded-xl text-apple-gray-400 hover:text-white hover:bg-white/10 border border-white/10 transition-colors"
          title="Toggle Light/Dark Theme"
        >
          {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* AI Assistant Quick Toggle */}
        <button
          onClick={() => setAiDrawerOpen(true)}
          className="p-2 rounded-xl bg-gradient-to-r from-apple-blue/20 to-apple-purple/20 text-white hover:from-apple-blue/30 hover:to-apple-purple/30 border border-apple-blue/30 transition-all flex items-center gap-1.5"
          title="NIVOR AI Assistant"
        >
          <Sparkles className="w-4 h-4 text-apple-blue animate-pulse" />
          <span className="text-xs font-semibold hidden lg:inline">Assistant</span>
        </button>

        {/* Quick Action Button */}
        <Button
          size="sm"
          variant="primary"
          icon={<Plus className="w-4 h-4" />}
          onClick={() => setQuickActionOpen(true)}
        >
          <span className="hidden sm:inline">Create</span>
        </Button>
      </div>
    </header>
  );
};
