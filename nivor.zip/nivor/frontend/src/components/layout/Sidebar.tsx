import React from 'react';
import { NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  CalendarCheck2,
  Calendar,
  FileText,
  Sparkles,
  Flame,
  Target,
  BookOpen,
  FolderKanban,
  FolderArchive,
  Wallet,
  Activity,
  Timer,
  BarChart3,
  Bell,
  Settings,
  User,
  ShieldCheck,
} from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';

interface NavItem {
  name: string;
  path: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
  section?: string;
}

export const Sidebar: React.FC = () => {
  const { tasks, notifications } = useAppStore();
  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const pendingTasks = tasks.filter((t) => t.status !== 'COMPLETED').length;

  const navItems: NavItem[] = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard, section: 'Main' },
    { name: 'Planner', path: '/planner', icon: CalendarCheck2, badge: pendingTasks },
    { name: 'Calendar', path: '/calendar', icon: Calendar },
    { name: 'Notes', path: '/notes', icon: FileText },
    { name: 'AI Assistant', path: '/ai', icon: Sparkles },

    { name: 'Habits', path: '/habits', icon: Flame, section: 'Growth & Focus' },
    { name: 'Goals', path: '/goals', icon: Target },
    { name: 'Journal', path: '/journal', icon: BookOpen },
    { name: 'Focus Mode', path: '/focus', icon: Timer },
    { name: 'Health', path: '/health', icon: Activity },

    { name: 'Workspace', path: '/workspace', icon: FolderKanban, section: 'Operations' },
    { name: 'File Manager', path: '/files', icon: FolderArchive },
    { name: 'Finance', path: '/finance', icon: Wallet },
    { name: 'Analytics', path: '/analytics', icon: BarChart3 },

    { name: 'Notifications', path: '/notifications', icon: Bell, badge: unreadCount, section: 'System' },
    { name: 'Settings', path: '/settings', icon: Settings },
    { name: 'Profile', path: '/profile', icon: User },
  ];

  let currentSection = '';

  return (
    <aside className="w-64 shrink-0 h-screen sticky top-0 hidden md:flex flex-col border-r border-white/10 dark:border-white/5 bg-black/40 backdrop-blur-2xl p-4 overflow-y-auto z-30">
      {/* Brand Header */}
      <div className="flex items-center gap-3 px-3 py-3 mb-4">
        <div className="h-9 w-9 rounded-xl bg-gradient-to-tr from-apple-blue via-blue-600 to-indigo-500 flex items-center justify-center shadow-apple-glow">
          <span className="font-extrabold text-white text-lg tracking-wider">N</span>
        </div>
        <div>
          <h1 className="text-base font-bold text-white tracking-tight leading-none">NIVOR</h1>
          <p className="text-[11px] text-apple-gray-400 mt-0.5 tracking-wide">Everything. Organized.</p>
        </div>
      </div>

      {/* Nav Link Items */}
      <nav className="flex-1 space-y-0.5">
        {navItems.map((item) => {
          const showSectionHeader = item.section && item.section !== currentSection;
          if (showSectionHeader) {
            currentSection = item.section!;
          }

          return (
            <React.Fragment key={item.path}>
              {showSectionHeader && (
                <div className="pt-4 pb-1.5 px-3">
                  <span className="text-[10px] font-semibold tracking-wider uppercase text-apple-gray-500">
                    {item.section}
                  </span>
                </div>
              )}

              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  `relative flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all group ${
                    isActive
                      ? 'text-white font-semibold bg-white/10 dark:bg-white/[0.08] shadow-sm border border-white/10'
                      : 'text-apple-gray-400 hover:text-white hover:bg-white/5'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    <div className="flex items-center gap-2.5">
                      <item.icon
                        className={`w-4 h-4 transition-colors ${
                          isActive ? 'text-apple-blue' : 'text-apple-gray-400 group-hover:text-white'
                        }`}
                      />
                      <span>{item.name}</span>
                    </div>

                    {item.badge !== undefined && item.badge > 0 && (
                      <span
                        className={`px-1.5 py-0.5 text-[10px] rounded-full font-bold ${
                          isActive
                            ? 'bg-apple-blue text-white'
                            : 'bg-white/10 text-apple-gray-300'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}

                    {isActive && (
                      <motion.div
                        layoutId="active-nav-indicator"
                        className="absolute left-0 w-1 h-5 bg-apple-blue rounded-r-full"
                        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                      />
                    )}
                  </>
                )}
              </NavLink>
            </React.Fragment>
          );
        })}
      </nav>

      {/* Footer System Status */}
      <div className="pt-4 mt-auto border-t border-white/10">
        <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-apple-green animate-pulse" />
            <span className="text-[11px] text-apple-gray-300 font-medium">Engine Online</span>
          </div>
          <span className="text-[10px] text-apple-gray-500 font-mono">v1.0.0</span>
        </div>
      </div>
    </aside>
  );
};
