import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { useAppStore } from '../../store/useAppStore';
import { CheckCircle2, Calendar, BookOpen, Flame, Wallet, Sparkles } from 'lucide-react';

export const QuickActionPalette: React.FC = () => {
  const { isQuickActionOpen, setQuickActionOpen, addTask, addEvent, saveJournal, addHabit, addTransaction } = useAppStore();
  const [selectedType, setSelectedType] = useState<'task' | 'event' | 'journal' | 'habit' | 'finance'>('task');
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('General');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    if (selectedType === 'task') {
      addTask({ title, priority: 'HIGH', status: 'TODO' });
    } else if (selectedType === 'event') {
      addEvent({ title, startTime: new Date().toISOString(), endTime: new Date(Date.now() + 3600000).toISOString() });
    } else if (selectedType === 'journal') {
      saveJournal({ title, content: title, mood: 5 });
    } else if (selectedType === 'habit') {
      addHabit({ name: title, frequency: 'DAILY' });
    } else if (selectedType === 'finance') {
      addTransaction({ title, amount: parseFloat(amount) || 0, type: 'EXPENSE', category });
    }

    setTitle('');
    setAmount('');
    setQuickActionOpen(false);
  };

  const types = [
    { id: 'task', label: 'Task', icon: CheckCircle2, color: 'text-apple-blue' },
    { id: 'event', label: 'Event', icon: Calendar, color: 'text-apple-purple' },
    { id: 'journal', label: 'Journal', icon: BookOpen, color: 'text-apple-orange' },
    { id: 'habit', label: 'Habit', icon: Flame, color: 'text-apple-green' },
    { id: 'finance', label: 'Expense', icon: Wallet, color: 'text-apple-red' },
  ];

  return (
    <Modal
      isOpen={isQuickActionOpen}
      onClose={() => setQuickActionOpen(false)}
      title="Create New Item"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Type Selector Grid */}
        <div className="grid grid-cols-5 gap-2">
          {types.map((t) => {
            const isSelected = selectedType === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setSelectedType(t.id as any)}
                className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border transition-all text-xs font-medium ${
                  isSelected
                    ? 'bg-white/15 border-white/30 text-white shadow-sm'
                    : 'bg-white/5 border-white/5 text-apple-gray-400 hover:text-white hover:bg-white/10'
                }`}
              >
                <t.icon className={`w-5 h-5 mb-1 ${t.color}`} />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        {/* Title Input */}
        <div>
          <label className="block text-xs font-medium text-apple-gray-300 mb-1.5">
            {selectedType === 'journal' ? 'Reflection Summary' : 'Title / Description'}
          </label>
          <input
            type="text"
            required
            autoFocus
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={`Enter ${selectedType} title...`}
            className="w-full glass-input rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
          />
        </div>

        {/* Amount for finance */}
        {selectedType === 'finance' && (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-apple-gray-300 mb-1.5">Amount ($)</label>
              <input
                type="number"
                step="0.01"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="45.00"
                className="w-full glass-input rounded-xl px-4 py-2 text-sm text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-apple-gray-300 mb-1.5">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full glass-input rounded-xl px-4 py-2 text-sm text-white bg-apple-gray-900"
              >
                <option value="Food">Food & Nutrition</option>
                <option value="Tech">Tech & Cloud</option>
                <option value="Travel">Travel & Mobility</option>
                <option value="Leisure">Leisure</option>
                <option value="Health">Health</option>
              </select>
            </div>
          </div>
        )}

        {/* Submit */}
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="ghost" size="sm" onClick={() => setQuickActionOpen(false)}>
            Cancel
          </Button>
          <Button type="submit" variant="primary" size="sm">
            Save {selectedType.charAt(0).toUpperCase() + selectedType.slice(1)}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
