import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, CalendarCheck2, FileText, Flame, Sparkles, FolderKanban } from 'lucide-react';

export const MobileNav: React.FC = () => {
  const links = [
    { name: 'Home', path: '/', icon: LayoutDashboard },
    { name: 'Planner', path: '/planner', icon: CalendarCheck2 },
    { name: 'AI', path: '/ai', icon: Sparkles },
    { name: 'Habits', path: '/habits', icon: Flame },
    { name: 'Notes', path: '/notes', icon: FileText },
    { name: 'Workspace', path: '/workspace', icon: FolderKanban },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 md:hidden bg-black/80 backdrop-blur-2xl border-t border-white/10 px-2 py-1.5 flex items-center justify-around">
      {links.map((link) => (
        <NavLink
          key={link.path}
          to={link.path}
          className={({ isActive }) =>
            `flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl text-[10px] font-medium transition-all ${
              isActive ? 'text-apple-blue font-semibold scale-105' : 'text-apple-gray-400 hover:text-white'
            }`
          }
        >
          <link.icon className="w-5 h-5" />
          <span>{link.name}</span>
        </NavLink>
      ))}
    </div>
  );
};
