import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, FileText, CheckCircle2, Calendar, FolderArchive, ArrowRight, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../../store/useAppStore';

export const GlobalSearchModal: React.FC = () => {
  const { isSearchOpen, setSearchOpen, tasks, notes, files, events } = useAppStore();
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(!isSearchOpen);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchOpen, setSearchOpen]);

  if (!isSearchOpen) return null;

  const q = query.toLowerCase().trim();

  const matchedTasks = tasks.filter(
    (t) => t.title.toLowerCase().includes(q) || t.tags?.toLowerCase().includes(q)
  ).slice(0, 4);

  const matchedNotes = notes.filter(
    (n) => n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q)
  ).slice(0, 4);

  const matchedFiles = files.filter(
    (f) => f.name.toLowerCase().includes(q) || f.tags?.toLowerCase().includes(q)
  ).slice(0, 3);

  const matchedEvents = events.filter(
    (e) => e.title.toLowerCase().includes(q) || e.location?.toLowerCase().includes(q)
  ).slice(0, 3);

  const handleSelect = (path: string) => {
    setSearchOpen(false);
    setQuery('');
    navigate(path);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setSearchOpen(false)}
          className="fixed inset-0 bg-black/60 backdrop-blur-xl"
        />

        {/* Search Palette Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: -10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: -10 }}
          transition={{ type: 'spring', damping: 28, stiffness: 400 }}
          className="relative w-full max-w-2xl bg-apple-gray-900/90 dark:bg-black/85 backdrop-blur-3xl border border-white/20 rounded-3xl shadow-2xl overflow-hidden z-10"
        >
          {/* Input Header */}
          <div className="flex items-center gap-3 px-5 py-4 border-b border-white/10">
            <Search className="w-5 h-5 text-apple-gray-400" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type to search tasks, notes, files, events..."
              className="w-full bg-transparent text-white text-base focus:outline-none placeholder:text-apple-gray-500"
            />
            <button
              onClick={() => setSearchOpen(false)}
              className="p-1 rounded-full text-apple-gray-400 hover:text-white hover:bg-white/10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Results List */}
          <div className="max-h-96 overflow-y-auto p-3 space-y-4">
            {/* Tasks */}
            {matchedTasks.length > 0 && (
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-apple-gray-500 px-3">
                  Tasks
                </span>
                <div className="mt-1 space-y-1">
                  {matchedTasks.map((t) => (
                    <div
                      key={t.id}
                      onClick={() => handleSelect('/planner')}
                      className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-white/10 cursor-pointer group transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <CheckCircle2
                          className={`w-4 h-4 ${
                            t.status === 'COMPLETED' ? 'text-apple-green' : 'text-apple-blue'
                          }`}
                        />
                        <span className="text-xs text-white group-hover:text-apple-blue font-medium">
                          {t.title}
                        </span>
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 text-apple-gray-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Notes */}
            {matchedNotes.length > 0 && (
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-apple-gray-500 px-3">
                  Notes
                </span>
                <div className="mt-1 space-y-1">
                  {matchedNotes.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => handleSelect('/notes')}
                      className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-white/10 cursor-pointer group transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <FileText className="w-4 h-4 text-apple-orange" />
                        <span className="text-xs text-white group-hover:text-apple-orange font-medium">
                          {n.title}
                        </span>
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 text-apple-gray-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Files */}
            {matchedFiles.length > 0 && (
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-apple-gray-500 px-3">
                  Files
                </span>
                <div className="mt-1 space-y-1">
                  {matchedFiles.map((f) => (
                    <div
                      key={f.id}
                      onClick={() => handleSelect('/files')}
                      className="flex items-center justify-between px-3 py-2 rounded-xl hover:bg-white/10 cursor-pointer group transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <FolderArchive className="w-4 h-4 text-apple-cyan" />
                        <span className="text-xs text-white group-hover:text-apple-cyan font-medium">
                          {f.name}
                        </span>
                      </div>
                      <ArrowRight className="w-3.5 h-3.5 text-apple-gray-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Empty state */}
            {matchedTasks.length === 0 && matchedNotes.length === 0 && matchedFiles.length === 0 && (
              <div className="py-8 text-center text-apple-gray-400 text-xs">
                No matching results found for "{query}"
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
