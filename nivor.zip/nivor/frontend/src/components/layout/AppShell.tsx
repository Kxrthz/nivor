import React from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { MobileNav } from './MobileNav';
import { DynamicIsland } from '../ui/DynamicIsland';
import { GlobalSearchModal } from './GlobalSearchModal';
import { QuickActionPalette } from './QuickActionPalette';
import { AiChatDrawer } from '../ai/AiChatDrawer';

export const AppShell: React.FC = () => {
  return (
    <div className="flex min-h-screen bg-black text-white selection:bg-apple-blue selection:text-white font-sans overflow-x-hidden">
      {/* Dynamic Island Floating Notification/Timer Pill */}
      <DynamicIsland />

      {/* Desktop Left Sidebar */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 pb-20 md:pb-8">
        <TopBar />
        <main className="flex-1 px-4 sm:px-8 py-6 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <MobileNav />

      {/* Global Overlays & Modals */}
      <GlobalSearchModal />
      <QuickActionPalette />
      <AiChatDrawer />
    </div>
  );
};
