import React from 'react';
import { motion } from 'framer-motion';

interface Option {
  id: string;
  label: string;
  icon?: React.ReactNode;
}

interface SegmentedControlProps {
  options: Option[];
  value: string;
  onChange: (value: string) => void;
  className?: string;
}

export const SegmentedControl: React.FC<SegmentedControlProps> = ({
  options,
  value,
  onChange,
  className = '',
}) => {
  return (
    <div className={`inline-flex p-1 bg-white/10 dark:bg-white/[0.06] backdrop-blur-md rounded-xl border border-white/10 ${className}`}>
      {options.map((option) => {
        const isSelected = option.id === value;
        return (
          <button
            key={option.id}
            onClick={() => onChange(option.id)}
            className={`relative flex items-center justify-center gap-1.5 px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors select-none ${
              isSelected ? 'text-white' : 'text-apple-gray-400 hover:text-white'
            }`}
          >
            {isSelected && (
              <motion.div
                layoutId="segmented-active-pill"
                className="absolute inset-0 bg-white/20 dark:bg-white/15 backdrop-blur-md rounded-lg shadow-sm border border-white/15"
                transition={{ type: 'spring', stiffness: 450, damping: 30 }}
              />
            )}
            <span className="relative z-10 flex items-center gap-1.5">
              {option.icon}
              {option.label}
            </span>
          </button>
        );
      })}
    </div>
  );
};
