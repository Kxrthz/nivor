import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useFocusStore } from '../../store/useFocusStore';
import { useAudioStore } from '../../store/useAudioStore';
import { Play, Pause, Square, Volume2, Sparkles, Zap } from 'lucide-react';

export const DynamicIsland: React.FC = () => {
  const { isActive, isPaused, secondsRemaining, mode, tick, pauseFocus, resumeFocus, stopFocus } = useFocusStore();
  const { isPlaying, currentTrack, togglePlay } = useAudioStore();
  const [isExpanded, setIsExpanded] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      tick();
    }, 1000);
    return () => clearInterval(timer);
  }, [tick]);

  const hasActivity = isActive || isPlaying;
  if (!hasActivity) return null;

  const mins = Math.floor(secondsRemaining / 60);
  const secs = secondsRemaining % 60;
  const timeFormatted = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 pointer-events-auto">
      <motion.div
        layout
        initial={{ y: -50, opacity: 0, scale: 0.8 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        exit={{ y: -50, opacity: 0, scale: 0.8 }}
        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
        onClick={() => setIsExpanded(!isExpanded)}
        className="bg-black/90 dark:bg-black/95 text-white backdrop-blur-2xl border border-white/20 rounded-full px-4 py-2 shadow-apple-glow cursor-pointer select-none flex items-center gap-3 dynamic-island-glow"
      >
        {/* Left Icon Pill */}
        <div className="flex items-center gap-1.5">
          {isActive ? (
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-apple-orange opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-apple-orange"></span>
            </span>
          ) : (
            <Zap className="w-3.5 h-3.5 text-apple-blue" />
          )}

          <span className="text-xs font-semibold tracking-wide font-mono">
            {isActive ? timeFormatted : currentTrack}
          </span>
        </div>

        {/* Center Indicator */}
        <div className="h-3 w-[1px] bg-white/20" />

        {/* Right Controls */}
        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
          {isActive && (
            <button
              onClick={isPaused ? resumeFocus : pauseFocus}
              className="p-1 rounded-full hover:bg-white/20 text-white/90 transition-colors"
            >
              {isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
            </button>
          )}

          {isPlaying && (
            <button
              onClick={togglePlay}
              className="p-1 rounded-full hover:bg-white/20 text-apple-blue transition-colors"
            >
              <Volume2 className="w-3.5 h-3.5 animate-pulse" />
            </button>
          )}

          {isActive && (
            <button
              onClick={stopFocus}
              className="p-1 rounded-full hover:bg-white/20 text-apple-red transition-colors"
            >
              <Square className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
};
