import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

interface ButtonProps extends HTMLMotionProps<'button'> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'glass';
  size?: 'sm' | 'md' | 'lg' | 'icon';
  children: React.ReactNode;
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  variant = 'primary',
  size = 'md',
  children,
  icon,
  className,
  disabled,
  ...props
}) => {
  const baseStyles = 'inline-flex items-center justify-center font-medium rounded-xl transition-all duration-200 select-none disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]';

  const sizeStyles = {
    sm: 'text-xs px-3 py-1.5 gap-1.5',
    md: 'text-sm px-4 py-2 gap-2',
    lg: 'text-base px-5 py-2.5 gap-2.5',
    icon: 'p-2 rounded-xl',
  };

  const variantStyles = {
    primary: 'bg-apple-blue text-white shadow-apple-sm hover:brightness-110 active:brightness-95',
    secondary: 'bg-white/10 dark:bg-white/10 text-white hover:bg-white/15 active:bg-white/20 border border-white/10',
    glass: 'glass-card text-white hover:bg-white/20 border border-white/15',
    ghost: 'text-apple-gray-300 hover:text-white hover:bg-white/10',
    danger: 'bg-apple-red/90 text-white hover:bg-apple-red active:bg-apple-red/80',
  };

  return (
    <motion.button
      whileTap={!disabled ? { scale: 0.97 } : undefined}
      className={twMerge(clsx(baseStyles, sizeStyles[size], variantStyles[variant], className))}
      disabled={disabled}
      {...props}
    >
      {icon && <span className="shrink-0">{icon}</span>}
      {children}
    </motion.button>
  );
};
