import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

interface GlassCardProps extends HTMLMotionProps<'div'> {
  children: React.ReactNode;
  className?: string;
  hoverEffect?: boolean;
  variant?: 'subtle' | 'default' | 'solid';
  glow?: boolean;
}

export const GlassCard: React.FC<GlassCardProps> = ({
  children,
  className,
  hoverEffect = true,
  variant = 'default',
  glow = false,
  ...props
}) => {
  return (
    <motion.div
      whileHover={hoverEffect ? { y: -2, transition: { duration: 0.2 } } : undefined}
      className={twMerge(
        clsx(
          'rounded-2xl transition-all duration-300 relative overflow-hidden',
          variant === 'default' && 'glass-card p-5 border border-white/10 dark:border-white/5',
          variant === 'subtle' && 'bg-white/5 dark:bg-white/[0.03] backdrop-blur-md border border-white/5 p-4',
          variant === 'solid' && 'bg-apple-gray-900 border border-white/10 p-5',
          glow && 'shadow-apple-glow border-apple-blue/40',
          className
        )
      )}
      {...props}
    >
      {children}
    </motion.div>
  );
};
