import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'blue' | 'purple' | 'green' | 'orange' | 'red' | 'gray';
  size?: 'sm' | 'md';
  icon?: React.ReactNode;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'blue',
  size = 'md',
  icon,
}) => {
  const variantStyles = {
    blue: 'bg-apple-blue/15 text-apple-blue border-apple-blue/30',
    purple: 'bg-apple-purple/15 text-apple-purple border-apple-purple/30',
    green: 'bg-apple-green/15 text-apple-green border-apple-green/30',
    orange: 'bg-apple-orange/15 text-apple-orange border-apple-orange/30',
    red: 'bg-apple-red/15 text-apple-red border-apple-red/30',
    gray: 'bg-white/10 text-apple-gray-300 border-white/10',
  };

  const sizeStyles = {
    sm: 'text-[11px] px-2 py-0.5 font-medium',
    md: 'text-xs px-2.5 py-1 font-semibold',
  };

  return (
    <span className={`inline-flex items-center gap-1 rounded-full border ${variantStyles[variant]} ${sizeStyles[size]}`}>
      {icon && <span className="shrink-0">{icon}</span>}
      {children}
    </span>
  );
};
