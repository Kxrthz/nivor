import { create } from 'zustand';
import { User } from '../types';
import { mockUser } from '../lib/mockData';
import { api } from '../lib/api';

interface AuthStore {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (fullName: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  setUser: (user: User | null) => void;
}

export const useAuthStore = create<AuthStore>((set) => {
  const savedToken = localStorage.getItem('nivor_access_token');
  const savedUser = localStorage.getItem('nivor_user');

  return {
    user: savedUser ? JSON.parse(savedUser) : mockUser,
    token: savedToken || 'demo_mock_jwt_token',
    isAuthenticated: true, // Default active demo session
    isLoading: false,

    login: async (email, password) => {
      try {
        const res = await api.post('/auth/login', { email, password });
        if (res.data?.success && res.data?.data) {
          const { accessToken, refreshToken, user } = res.data.data;
          localStorage.setItem('nivor_access_token', accessToken);
          localStorage.setItem('nivor_refresh_token', refreshToken);
          localStorage.setItem('nivor_user', JSON.stringify(user));
          set({ user, token: accessToken, isAuthenticated: true });
          return true;
        }
      } catch (err) {
        console.warn('Backend unavailable, using local mock auth:', err);
      }
      // Demo fallback login
      const demo = { ...mockUser, email };
      localStorage.setItem('nivor_user', JSON.stringify(demo));
      set({ user: demo, token: 'demo_token', isAuthenticated: true });
      return true;
    },

    register: async (fullName, email, password) => {
      try {
        const res = await api.post('/auth/register', { fullName, email, password });
        if (res.data?.success && res.data?.data) {
          const { accessToken, refreshToken, user } = res.data.data;
          localStorage.setItem('nivor_access_token', accessToken);
          localStorage.setItem('nivor_refresh_token', refreshToken);
          localStorage.setItem('nivor_user', JSON.stringify(user));
          set({ user, token: accessToken, isAuthenticated: true });
          return true;
        }
      } catch (err) {
        console.warn('Backend unavailable, using local mock register:', err);
      }
      const newUser: User = {
        ...mockUser,
        id: Date.now(),
        fullName,
        email,
      };
      localStorage.setItem('nivor_user', JSON.stringify(newUser));
      set({ user: newUser, token: 'demo_token', isAuthenticated: true });
      return true;
    },

    logout: () => {
      localStorage.removeItem('nivor_access_token');
      localStorage.removeItem('nivor_refresh_token');
      localStorage.removeItem('nivor_user');
      set({ user: null, token: null, isAuthenticated: false });
    },

    setUser: (user) => {
      if (user) localStorage.setItem('nivor_user', JSON.stringify(user));
      set({ user });
    },
  };
});
