import { create } from 'zustand';
import {
  Task,
  CalendarEvent,
  Note,
  JournalEntry,
  Habit,
  Goal,
  Project,
  FinanceTransaction,
  Budget,
  DailyHealthSummary,
  StoredFile,
  NotificationItem,
  OverallProductivityScore,
} from '../types';
import {
  mockTasks,
  mockEvents,
  mockNotes,
  mockJournals,
  mockHabits,
  mockGoals,
  mockProjects,
  mockFinanceSummary,
  mockHealthSummary,
  mockFiles,
  mockNotifications,
  mockProductivityScore,
} from '../lib/mockData';
import { api } from '../lib/api';

interface AppStore {
  // Navigation & Modals
  isSearchOpen: boolean;
  isAiDrawerOpen: boolean;
  isQuickActionOpen: boolean;
  activeTab: string;
  setSearchOpen: (open: boolean) => void;
  setAiDrawerOpen: (open: boolean) => void;
  setQuickActionOpen: (open: boolean) => void;
  setActiveTab: (tab: string) => void;

  // Data
  tasks: Task[];
  events: CalendarEvent[];
  notes: Note[];
  journals: JournalEntry[];
  habits: Habit[];
  goals: Goal[];
  projects: Project[];
  financeTransactions: FinanceTransaction[];
  budgets: Budget[];
  health: DailyHealthSummary;
  files: StoredFile[];
  notifications: NotificationItem[];
  productivityScore: OverallProductivityScore;

  // Actions - Tasks
  addTask: (task: Partial<Task>) => void;
  toggleTask: (id: number) => void;
  updateTask: (id: number, updates: Partial<Task>) => void;
  deleteTask: (id: number) => void;
  reorderTasks: (tasks: Task[]) => void;

  // Actions - Events
  addEvent: (event: Partial<CalendarEvent>) => void;
  deleteEvent: (id: number) => void;

  // Actions - Notes
  addNote: (note: Partial<Note>) => void;
  updateNote: (id: number, updates: Partial<Note>) => void;
  deleteNote: (id: number) => void;

  // Actions - Habits
  addHabit: (habit: Partial<Habit>) => void;
  toggleHabitCheckIn: (habitId: number) => void;
  deleteHabit: (id: number) => void;

  // Actions - Goals
  addGoal: (goal: Partial<Goal>) => void;
  toggleMilestone: (goalId: number, milestoneId: number) => void;

  // Actions - Projects
  addProject: (proj: Partial<Project>) => void;

  // Actions - Finance
  addTransaction: (tx: Partial<FinanceTransaction>) => void;
  saveBudget: (b: Partial<Budget>) => void;

  // Actions - Health
  logHealthMetric: (type: 'WATER_ML' | 'SLEEP_HOURS' | 'STEPS' | 'WEIGHT_KG' | 'WORKOUT_MIN', value: number) => void;

  // Actions - Journal
  saveJournal: (entry: Partial<JournalEntry>) => void;

  // Actions - Files
  addFile: (f: Partial<StoredFile>) => void;
  deleteFile: (id: number) => void;

  // Actions - Notifications
  markNotificationRead: (id: number) => void;
  markAllNotificationsRead: () => void;
}

export const useAppStore = create<AppStore>((set, get) => ({
  isSearchOpen: false,
  isAiDrawerOpen: false,
  isQuickActionOpen: false,
  activeTab: 'dashboard',

  setSearchOpen: (isSearchOpen) => set({ isSearchOpen }),
  setAiDrawerOpen: (isAiDrawerOpen) => set({ isAiDrawerOpen }),
  setQuickActionOpen: (isQuickActionOpen) => set({ isQuickActionOpen }),
  setActiveTab: (activeTab) => set({ activeTab }),

  // Initial Data
  tasks: mockTasks,
  events: mockEvents,
  notes: mockNotes,
  journals: mockJournals,
  habits: mockHabits,
  goals: mockGoals,
  projects: mockProjects,
  financeTransactions: mockFinanceSummary.recentTransactions,
  budgets: mockFinanceSummary.budgets,
  health: mockHealthSummary,
  files: mockFiles,
  notifications: mockNotifications,
  productivityScore: mockProductivityScore,

  // Task Handlers
  addTask: async (taskData) => {
    const newTask: Task = {
      id: Date.now(),
      title: taskData.title || 'New Task',
      description: taskData.description || '',
      status: taskData.status || 'TODO',
      priority: taskData.priority || 'MEDIUM',
      projectId: taskData.projectId,
      dueDate: taskData.dueDate || new Date().toISOString(),
      orderIndex: get().tasks.length + 1,
      tags: taskData.tags || 'General',
      estimatedMinutes: taskData.estimatedMinutes || 30,
    };
    set((state) => ({ tasks: [newTask, ...state.tasks] }));
    try {
      await api.post('/tasks', newTask);
    } catch {}
  },

  toggleTask: async (id) => {
    set((state) => ({
      tasks: state.tasks.map((t) => {
        if (t.id === id) {
          const isComp = t.status === 'COMPLETED';
          return {
            ...t,
            status: isComp ? 'TODO' : 'COMPLETED',
            completedAt: isComp ? undefined : new Date().toISOString(),
          };
        }
        return t;
      }),
    }));
    try {
      await api.patch(`/tasks/${id}/toggle`);
    } catch {}
  },

  updateTask: async (id, updates) => {
    set((state) => ({
      tasks: state.tasks.map((t) => (t.id === id ? { ...t, ...updates } : t)),
    }));
    try {
      await api.put(`/tasks/${id}`, updates);
    } catch {}
  },

  deleteTask: async (id) => {
    set((state) => ({ tasks: state.tasks.filter((t) => t.id !== id) }));
    try {
      await api.delete(`/tasks/${id}`);
    } catch {}
  },

  reorderTasks: (tasks) => set({ tasks }),

  // Event Handlers
  addEvent: async (ev) => {
    const newEvent: CalendarEvent = {
      id: Date.now(),
      title: ev.title || 'New Event',
      description: ev.description,
      location: ev.location,
      startTime: ev.startTime || new Date().toISOString(),
      endTime: ev.endTime || new Date(Date.now() + 3600000).toISOString(),
      isAllDay: ev.isAllDay || false,
      color: ev.color || '#0A84FF',
      category: ev.category || 'Work',
      syncSource: 'NIVOR',
    };
    set((state) => ({ events: [...state.events, newEvent] }));
    try {
      await api.post('/events', newEvent);
    } catch {}
  },

  deleteEvent: async (id) => {
    set((state) => ({ events: state.events.filter((e) => e.id !== id) }));
    try {
      await api.delete(`/events/${id}`);
    } catch {}
  },

  // Notes Handlers
  addNote: async (n) => {
    const newNote: Note = {
      id: Date.now(),
      title: n.title || 'Untitled Note',
      content: n.content || '',
      summary: n.summary || 'Summary generated by NIVOR AI',
      isPinned: n.isPinned || false,
      color: n.color || '#0A84FF',
      tags: n.tags || 'Notes',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    set((state) => ({ notes: [newNote, ...state.notes] }));
    try {
      await api.post('/notes', newNote);
    } catch {}
  },

  updateNote: async (id, updates) => {
    set((state) => ({
      notes: state.notes.map((n) =>
        n.id === id ? { ...n, ...updates, updatedAt: new Date().toISOString() } : n
      ),
    }));
    try {
      await api.put(`/notes/${id}`, updates);
    } catch {}
  },

  deleteNote: async (id) => {
    set((state) => ({ notes: state.notes.filter((n) => n.id !== id) }));
    try {
      await api.delete(`/notes/${id}`);
    } catch {}
  },

  // Habits Handlers
  addHabit: async (h) => {
    const newHabit: Habit = {
      id: Date.now(),
      name: h.name || 'New Habit',
      description: h.description,
      frequency: h.frequency || 'DAILY',
      targetCountPerDay: h.targetCountPerDay || 1,
      unit: h.unit || 'times',
      color: h.color || '#30D158',
      icon: h.icon || 'Flame',
      currentStreak: 0,
      longestStreak: 0,
      completedToday: false,
      todayCount: 0,
      pastWeekStatus: {},
    };
    set((state) => ({ habits: [...state.habits, newHabit] }));
    try {
      await api.post('/habits', newHabit);
    } catch {}
  },

  toggleHabitCheckIn: async (habitId) => {
    set((state) => ({
      habits: state.habits.map((h) => {
        if (h.id === habitId) {
          const wasCompleted = h.completedToday;
          const nextStreak = wasCompleted ? Math.max(0, h.currentStreak - 1) : h.currentStreak + 1;
          const todayKey = new Date().toISOString().split('T')[0];
          return {
            ...h,
            completedToday: !wasCompleted,
            currentStreak: nextStreak,
            longestStreak: Math.max(h.longestStreak, nextStreak),
            pastWeekStatus: {
              ...h.pastWeekStatus,
              [todayKey]: !wasCompleted,
            },
          };
        }
        return h;
      }),
    }));
    try {
      await api.post(`/habits/${habitId}/check-in`, { completed: true });
    } catch {}
  },

  deleteHabit: async (id) => {
    set((state) => ({ habits: state.habits.filter((h) => h.id !== id) }));
    try {
      await api.delete(`/habits/${id}`);
    } catch {}
  },

  // Goals Handlers
  addGoal: async (g) => {
    const newGoal: Goal = {
      id: Date.now(),
      title: g.title || 'New Goal',
      description: g.description,
      category: g.category || 'Career',
      targetDate: g.targetDate,
      progressPercentage: 0,
      status: 'IN_PROGRESS',
      color: g.color || '#BF5AF2',
      aiRoadmap: g.aiRoadmap || 'Structured incremental milestones initialized.',
      milestones: g.milestones || [],
    };
    set((state) => ({ goals: [newGoal, ...state.goals] }));
    try {
      await api.post('/goals', newGoal);
    } catch {}
  },

  toggleMilestone: (goalId, milestoneId) => {
    set((state) => ({
      goals: state.goals.map((g) => {
        if (g.id === goalId) {
          const updatedMs = g.milestones.map((m) =>
            m.id === milestoneId ? { ...m, isCompleted: !m.isCompleted } : m
          );
          const completedCount = updatedMs.filter((m) => m.isCompleted).length;
          const pct = Math.round((completedCount / updatedMs.length) * 100);
          return {
            ...g,
            milestones: updatedMs,
            progressPercentage: pct,
            status: pct === 100 ? 'ACHIEVED' : 'IN_PROGRESS',
          };
        }
        return g;
      }),
    }));
  },

  // Projects Handlers
  addProject: async (p) => {
    const newProject: Project = {
      id: Date.now(),
      name: p.name || 'New Project',
      description: p.description,
      color: p.color || '#0A84FF',
      icon: p.icon || 'Folder',
      status: 'ACTIVE',
      viewMode: p.viewMode || 'KANBAN',
      taskCount: 0,
      completedTaskCount: 0,
    };
    set((state) => ({ projects: [...state.projects, newProject] }));
    try {
      await api.post('/projects', newProject);
    } catch {}
  },

  // Finance Handlers
  addTransaction: async (tx) => {
    const newTx: FinanceTransaction = {
      id: Date.now(),
      title: tx.title || 'Transaction',
      amount: tx.amount || 0,
      type: tx.type || 'EXPENSE',
      category: tx.category || 'General',
      currency: 'USD',
      isRecurring: tx.isRecurring || false,
      transactionDate: tx.transactionDate || new Date().toISOString().split('T')[0],
      notes: tx.notes,
    };
    set((state) => ({
      financeTransactions: [newTx, ...state.financeTransactions],
    }));
    try {
      await api.post('/finance/transactions', newTx);
    } catch {}
  },

  saveBudget: async (b) => {
    const newBudget: Budget = {
      id: b.id || Date.now(),
      category: b.category || 'General',
      monthlyLimit: b.monthlyLimit || 1000,
      spentAmount: b.spentAmount || 0,
      remainingAmount: (b.monthlyLimit || 1000) - (b.spentAmount || 0),
      percentageUsed: Math.round(((b.spentAmount || 0) / (b.monthlyLimit || 1000)) * 100),
      monthYear: '2026-09',
    };
    set((state) => ({
      budgets: [...state.budgets.filter((x) => x.category !== b.category), newBudget],
    }));
    try {
      await api.post('/finance/budgets', newBudget);
    } catch {}
  },

  // Health Handlers
  logHealthMetric: (type, value) => {
    set((state) => {
      const h = { ...state.health };
      if (type === 'WATER_ML') h.waterMl = (h.waterMl || 0) + value;
      if (type === 'STEPS') h.steps = (h.steps || 0) + value;
      if (type === 'SLEEP_HOURS') h.sleepHours = value;
      if (type === 'WEIGHT_KG') h.weightKg = value;
      if (type === 'WORKOUT_MIN') h.workoutMinutes = (h.workoutMinutes || 0) + value;
      return { health: h };
    });
  },

  // Journal Handlers
  saveJournal: async (entry) => {
    const newEntry: JournalEntry = {
      id: entry.id || Date.now(),
      title: entry.title || 'Daily Reflection',
      content: entry.content || '',
      mood: entry.mood || 5,
      moodLabel: entry.moodLabel || 'Happy',
      gratitudeList: entry.gratitudeList || [],
      weather: entry.weather || 'Sunny 72°F',
      location: entry.location || 'San Francisco, CA',
      entryDate: entry.entryDate || new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString(),
    };
    set((state) => ({
      journals: [newEntry, ...state.journals.filter((j) => j.entryDate !== newEntry.entryDate)],
    }));
    try {
      await api.post('/journals', newEntry);
    } catch {}
  },

  // Files Handlers
  addFile: (f) => {
    const newFile: StoredFile = {
      id: Date.now(),
      name: f.name || 'document.pdf',
      fileType: f.fileType || 'application/pdf',
      fileSizeBytes: f.fileSizeBytes || 1024000,
      storagePath: f.storagePath || '/uploads/file.pdf',
      folder: f.folder || 'Documents',
      tags: f.tags || 'New',
      createdAt: new Date().toISOString(),
    };
    set((state) => ({ files: [newFile, ...state.files] }));
  },

  deleteFile: (id) => {
    set((state) => ({ files: state.files.filter((f) => f.id !== id) }));
  },

  // Notification Handlers
  markNotificationRead: (id) => {
    set((state) => ({
      notifications: state.notifications.map((n) =>
        n.id === id ? { ...n, isRead: true } : n
      ),
    }));
  },

  markAllNotificationsRead: () => {
    set((state) => ({
      notifications: state.notifications.map((n) => ({ ...n, isRead: true })),
    }));
  },
}));
