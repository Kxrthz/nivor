import { create } from 'zustand';
import { AccentColor, ThemeMode } from '../types';

interface ThemeStore {
  theme: ThemeMode;
  accentColor: AccentColor;
  setTheme: (theme: ThemeMode) => void;
  setAccentColor: (color: AccentColor) => void;
  toggleTheme: () => void;
}

export const useThemeStore = create<ThemeStore>((set, get) => {
  const initialTheme = (localStorage.getItem('nivor_theme') as ThemeMode) || 'dark';
  const initialAccent = (localStorage.getItem('nivor_accent') as AccentColor) || 'system_blue';

  const applyTheme = (t: ThemeMode, a: AccentColor) => {
    const root = document.documentElement;
    if (t === 'dark') {
      root.classList.add('dark');
      root.classList.remove('light');
    } else if (t === 'light') {
      root.classList.add('light');
      root.classList.remove('dark');
    }
    root.setAttribute('data-accent', a);
  };

  applyTheme(initialTheme, initialAccent);

  return {
    theme: initialTheme,
    accentColor: initialAccent,

    setTheme: (theme) => {
      localStorage.setItem('nivor_theme', theme);
      applyTheme(theme, get().accentColor);
      set({ theme });
    },

    setAccentColor: (accentColor) => {
      localStorage.setItem('nivor_accent', accentColor);
      applyTheme(get().theme, accentColor);
      set({ accentColor });
    },

    toggleTheme: () => {
      const next = get().theme === 'dark' ? 'light' : 'dark';
      get().setTheme(next);
    },
  };
});
