import { create } from 'zustand';

export type AmbientTrack = 'None' | 'Rainy Cafe' | 'Rainy Forest' | 'Lo-Fi Chill' | 'White Noise' | 'Deep Ocean';

interface AudioStore {
  currentTrack: AmbientTrack;
  isPlaying: boolean;
  volume: number;
  playTrack: (track: AmbientTrack) => void;
  stopAudio: () => void;
  togglePlay: () => void;
  setVolume: (vol: number) => void;
}

// In-memory Web Audio synth for ambient soundscapes
let audioCtx: AudioContext | null = null;
let noiseNode: AudioNode | null = null;
let gainNode: GainNode | null = null;

export const useAudioStore = create<AudioStore>((set, get) => ({
  currentTrack: 'None',
  isPlaying: false,
  volume: 0.5,

  playTrack: (track) => {
    if (track === 'None') {
      get().stopAudio();
      return;
    }

    try {
      if (!audioCtx) {
        audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      }
      if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }

      if (noiseNode) {
        noiseNode.disconnect();
      }

      // Generate soft pink/brown noise for peaceful focus
      const bufferSize = audioCtx.sampleRate * 2;
      const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;

      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.06;
        b6 = white * 0.115926;
      }

      const whiteNoise = audioCtx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      // Filter to simulate cafe / rain / forest
      const filter = audioCtx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(
        track === 'Rainy Forest' ? 600 :
        track === 'Deep Ocean' ? 350 :
        track === 'Rainy Cafe' ? 900 : 1200,
        audioCtx.currentTime
      );

      gainNode = audioCtx.createGain();
      gainNode.gain.setValueAtTime(get().volume * 0.3, audioCtx.currentTime);

      whiteNoise.connect(filter);
      filter.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      whiteNoise.start();
      noiseNode = whiteNoise;

      set({ currentTrack: track, isPlaying: true });
    } catch (err) {
      console.warn('Web Audio Ambient setup:', err);
      set({ currentTrack: track, isPlaying: true });
    }
  },

  stopAudio: () => {
    if (noiseNode) {
      try {
        (noiseNode as AudioBufferSourceNode).stop();
        noiseNode.disconnect();
      } catch {}
      noiseNode = null;
    }
    set({ currentTrack: 'None', isPlaying: false });
  },

  togglePlay: () => {
    const { isPlaying, currentTrack } = get();
    if (isPlaying) {
      get().stopAudio();
    } else {
      get().playTrack(currentTrack === 'None' ? 'Rainy Cafe' : currentTrack);
    }
  },

  setVolume: (volume) => {
    if (gainNode && audioCtx) {
      gainNode.gain.setValueAtTime(volume * 0.3, audioCtx.currentTime);
    }
    set({ volume });
  },
}));
