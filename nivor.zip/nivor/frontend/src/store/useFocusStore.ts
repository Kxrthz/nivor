import { create } from 'zustand';

interface FocusStore {
  isActive: boolean;
  isPaused: boolean;
  mode: 'POMODORO' | 'DEEP_WORK' | 'SHORT_BREAK' | 'LONG_BREAK';
  durationMinutes: number;
  secondsRemaining: number;
  currentTag: string;
  soundtrack: string;
  startFocus: (mode?: 'POMODORO' | 'DEEP_WORK' | 'SHORT_BREAK' | 'LONG_BREAK', minutes?: number) => void;
  pauseFocus: () => void;
  resumeFocus: () => void;
  stopFocus: () => void;
  tick: () => void;
  setSoundtrack: (soundtrack: string) => void;
  setTag: (tag: string) => void;
}

export const useFocusStore = create<FocusStore>((set, get) => ({
  isActive: false,
  isPaused: false,
  mode: 'POMODORO',
  durationMinutes: 25,
  secondsRemaining: 25 * 60,
  currentTag: 'Deep Work',
  soundtrack: 'Rainy Forest',

  startFocus: (mode = 'POMODORO', minutes) => {
    const mins = minutes || (mode === 'POMODORO' ? 25 : mode === 'DEEP_WORK' ? 90 : mode === 'SHORT_BREAK' ? 5 : 15);
    set({
      isActive: true,
      isPaused: false,
      mode,
      durationMinutes: mins,
      secondsRemaining: mins * 60,
    });
  },

  pauseFocus: () => set({ isPaused: true }),
  resumeFocus: () => set({ isPaused: false }),
  stopFocus: () => {
    set({
      isActive: false,
      isPaused: false,
      secondsRemaining: get().durationMinutes * 60,
    });
  },

  tick: () => {
    const { isActive, isPaused, secondsRemaining } = get();
    if (!isActive || isPaused) return;

    if (secondsRemaining <= 1) {
      set({
        isActive: false,
        secondsRemaining: 0,
      });
      // Play completion chime
      try {
        const ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc.frequency.exponentialRampToValueAtTime(1046.5, ctx.currentTime + 0.5); // C6
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.8);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.8);
      } catch (e) {
        console.log('Audio chime error:', e);
      }
    } else {
      set({ secondsRemaining: secondsRemaining - 1 });
    }
  },

  setSoundtrack: (soundtrack) => set({ soundtrack }),
  setTag: (currentTag) => set({ currentTag }),
}));
