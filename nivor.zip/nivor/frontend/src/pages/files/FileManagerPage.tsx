import React, { useState } from 'react';
import { Upload, FolderArchive, FileText, Image, FileSpreadsheet, Trash2, Search, Download } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';

export const FileManagerPage: React.FC = () => {
  const { files, addFile, deleteFile } = useAppStore();
  const [selectedFolder, setSelectedFolder] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const handleUploadSim = () => {
    const name = prompt('File Name (e.g., Annual_Security_Audit.pdf):');
    if (name && name.trim()) {
      addFile({
        name,
        fileType: name.endsWith('.pdf') ? 'application/pdf' : name.endsWith('.xlsx') ? 'application/vnd.ms-excel' : 'image/png',
        fileSizeBytes: 1850000,
        folder: selectedFolder === 'ALL' ? 'Documents' : selectedFolder,
        tags: 'Uploaded',
      });
    }
  };

  const folders = ['ALL', 'Documents', 'Design', 'Finance'];

  const filteredFiles = files.filter((f) => {
    if (selectedFolder !== 'ALL' && f.folder !== selectedFolder) return false;
    if (searchQuery && !f.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const getFileIcon = (type: string) => {
    if (type.includes('pdf')) return <FileText className="w-8 h-8 text-apple-red" />;
    if (type.includes('excel') || type.includes('sheet')) return <FileSpreadsheet className="w-8 h-8 text-apple-green" />;
    if (type.includes('image')) return <Image className="w-8 h-8 text-apple-purple" />;
    return <FolderArchive className="w-8 h-8 text-apple-blue" />;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">File Manager</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Apple Finder material design with OCR text indexing & multi-format support
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="sm"
            onClick={handleUploadSim}
            icon={<Upload className="w-4 h-4" />}
          >
            Upload File
          </Button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          {folders.map((f) => (
            <button
              key={f}
              onClick={() => setSelectedFolder(f)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all select-none ${
                selectedFolder === f
                  ? 'bg-apple-blue text-white shadow-sm'
                  : 'bg-white/5 text-apple-gray-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {f === 'ALL' ? 'All Files' : f}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-apple-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search filenames / tags..."
            className="w-full glass-input rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none placeholder:text-apple-gray-500"
          />
        </div>
      </div>

      {/* Files Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filteredFiles.map((file) => (
          <GlassCard key={file.id} className="p-4 flex flex-col justify-between h-48 group">
            <div className="flex items-start justify-between">
              {getFileIcon(file.fileType)}
              <Badge variant="gray" size="sm">{file.folder}</Badge>
            </div>

            <div>
              <h4 className="text-xs font-bold text-white truncate" title={file.name}>
                {file.name}
              </h4>
              <p className="text-[10px] text-apple-gray-400 mt-0.5">
                {(file.fileSizeBytes / 1024 / 1024).toFixed(2)} MB • {new Date(file.createdAt).toLocaleDateString()}
              </p>
            </div>

            <div className="pt-2 border-t border-white/5 flex items-center justify-between">
              <span className="text-[10px] text-apple-blue font-semibold">OCR Indexed</span>
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => alert(`Downloading ${file.name}`)}
                  className="p-1 rounded-lg hover:bg-white/10 text-apple-gray-300 hover:text-white"
                  title="Download"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => deleteFile(file.id)}
                  className="p-1 rounded-lg hover:bg-apple-red/20 text-apple-gray-400 hover:text-apple-red"
                  title="Delete"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  );
};
