import React, { useState } from 'react';
import { Plus, Wallet, ArrowUpRight, ArrowDownRight, TrendingUp, CreditCard, Sparkles, Trash2 } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';

export const FinancePage: React.FC = () => {
  const { financeTransactions, budgets, addTransaction } = useAppStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<'INCOME' | 'EXPENSE'>('EXPENSE');
  const [category, setCategory] = useState('Tech');

  const totalIncome = financeTransactions
    .filter((t) => t.type === 'INCOME')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalExpense = financeTransactions
    .filter((t) => t.type === 'EXPENSE')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const netSavings = totalIncome - totalExpense;
  const savingsRate = totalIncome > 0 ? ((netSavings / totalIncome) * 100).toFixed(1) : '0';

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !amount) return;

    addTransaction({
      title,
      amount: parseFloat(amount),
      type,
      category,
      transactionDate: new Date().toISOString().split('T')[0],
    });

    setTitle('');
    setAmount('');
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Finance & Wealth</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Cashflow analytics, category budgets & recurring subscription management
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="sm"
            onClick={() => setIsModalOpen(true)}
            icon={<Plus className="w-4 h-4" />}
          >
            Log Transaction
          </Button>
        </div>
      </div>

      {/* Top 4 Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <GlassCard className="p-5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-apple-gray-400">
            Total Income
          </span>
          <h3 className="text-xl sm:text-2xl font-extrabold text-white mt-1">
            ${totalIncome.toLocaleString()}
          </h3>
          <p className="text-[11px] text-apple-green font-semibold mt-1 flex items-center gap-0.5">
            <ArrowUpRight className="w-3.5 h-3.5" /> Direct Retainers
          </p>
        </GlassCard>

        <GlassCard className="p-5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-apple-gray-400">
            Total Outflow
          </span>
          <h3 className="text-xl sm:text-2xl font-extrabold text-white mt-1">
            ${totalExpense.toLocaleString()}
          </h3>
          <p className="text-[11px] text-apple-orange font-semibold mt-1 flex items-center gap-0.5">
            <ArrowDownRight className="w-3.5 h-3.5" /> Controlled OpEx
          </p>
        </GlassCard>

        <GlassCard className="p-5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-apple-gray-400">
            Net Monthly Savings
          </span>
          <h3 className="text-xl sm:text-2xl font-extrabold text-apple-green mt-1">
            +${netSavings.toLocaleString()}
          </h3>
          <p className="text-[11px] text-apple-gray-400 mt-1">Retained Capital</p>
        </GlassCard>

        <GlassCard className="p-5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-apple-gray-400">
            Savings Rate
          </span>
          <h3 className="text-xl sm:text-2xl font-extrabold text-apple-blue mt-1">
            {savingsRate}%
          </h3>
          <p className="text-[11px] text-apple-blue font-semibold mt-1">Target: &gt;65%</p>
        </GlassCard>
      </div>

      {/* Budgets & Subscriptions Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Budgets */}
        <GlassCard className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Category Budgets ({budgets.length})
            </h3>
            <Badge variant="blue" size="sm">September 2026</Badge>
          </div>

          <div className="space-y-4 pt-1">
            {budgets.map((b) => (
              <div key={b.id} className="space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-white">{b.category}</span>
                  <span className="text-apple-gray-400">
                    ${b.spentAmount} / ${b.monthlyLimit} ({b.percentageUsed}%)
                  </span>
                </div>
                <div className="w-full bg-white/10 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${
                      b.percentageUsed > 80
                        ? 'bg-apple-red'
                        : b.percentageUsed > 50
                        ? 'bg-apple-orange'
                        : 'bg-apple-blue'
                    }`}
                    style={{ width: `${Math.min(100, b.percentageUsed)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* Transactions Stream */}
        <GlassCard className="p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Recent Transactions ({financeTransactions.length})
            </h3>
            <Badge variant="gray" size="sm">Live Feed</Badge>
          </div>

          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
            {financeTransactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between p-2.5 rounded-xl bg-white/5 border border-white/5"
              >
                <div>
                  <h4 className="text-xs font-bold text-white">{tx.title}</h4>
                  <p className="text-[10px] text-apple-gray-400">
                    {tx.category} • {tx.transactionDate}
                  </p>
                </div>

                <span
                  className={`text-xs font-extrabold ${
                    tx.type === 'INCOME' ? 'text-apple-green' : 'text-white'
                  }`}
                >
                  {tx.type === 'INCOME' ? '+' : '-'}${tx.amount.toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* Create Transaction Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Log Financial Transaction">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Transaction Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. AWS Production Cluster"
              className="w-full glass-input rounded-xl px-4 py-2 text-sm text-white focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-apple-gray-300 mb-1">Amount ($)</label>
              <input
                type="number"
                step="0.01"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="420.50"
                className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-apple-gray-300 mb-1">Type</label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value as any)}
                className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white bg-apple-gray-900"
              >
                <option value="EXPENSE">Expense</option>
                <option value="INCOME">Income</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white bg-apple-gray-900"
            >
              <option value="Tech">Tech & Cloud</option>
              <option value="Food">Food & Nutrition</option>
              <option value="Travel">Travel & Mobility</option>
              <option value="Consulting">Consulting Retainer</option>
              <option value="Software">Software & SaaS</option>
            </select>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" size="sm" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Transaction
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
