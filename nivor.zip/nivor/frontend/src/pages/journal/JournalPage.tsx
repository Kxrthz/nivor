import React, { useState } from 'react';
import { Plus, BookOpen, Sun, MapPin, Smile, Mic, Sparkles, Heart } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Modal } from '../../components/ui/Modal';
import { Badge } from '../../components/ui/Badge';

export const JournalPage: React.FC = () => {
  const { journals, saveJournal } = useAppStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [mood, setMood] = useState(5);
  const [gratitude1, setGratitude1] = useState('');
  const [gratitude2, setGratitude2] = useState('');
  const [gratitude3, setGratitude3] = useState('');

  const moodEmojis = [
    { score: 1, emoji: '😔', label: 'Down' },
    { score: 2, emoji: '😐', label: 'Neutral' },
    { score: 3, emoji: '🙂', label: 'Calm' },
    { score: 4, emoji: '😊', label: 'Happy' },
    { score: 5, emoji: '🤩', label: 'Ecstatic' },
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    const gratitudeList = [gratitude1, gratitude2, gratitude3].filter(Boolean);
    const selectedMoodObj = moodEmojis.find((m) => m.score === mood);

    saveJournal({
      title,
      content,
      mood,
      moodLabel: selectedMoodObj?.label || 'Happy',
      gratitudeList,
      weather: 'Sunny 72°F',
      location: 'Cupertino, CA',
    });

    setTitle('');
    setContent('');
    setGratitude1('');
    setGratitude2('');
    setGratitude3('');
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Journal</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Apple Journal-style daily reflections, gratitude logs & sentiment trends
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="sm"
            onClick={() => setIsModalOpen(true)}
            icon={<Plus className="w-4 h-4" />}
          >
            New Entry
          </Button>
        </div>
      </div>

      {/* Mood Quick Logger Strip */}
      <GlassCard className="p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-apple-orange/20 text-apple-orange">
            <Heart className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">How are you feeling today?</h3>
            <p className="text-[11px] text-apple-gray-400">Log your emotional state for weekly sentiment analytics.</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {moodEmojis.map((m) => (
            <button
              key={m.score}
              onClick={() => {
                setMood(m.score);
                setIsModalOpen(true);
              }}
              className="p-2.5 rounded-2xl bg-white/5 hover:bg-white/15 text-xl border border-white/10 transition-all hover:scale-110 active:scale-95"
              title={m.label}
            >
              {m.emoji}
            </button>
          ))}
        </div>
      </GlassCard>

      {/* Journal Timeline Stream */}
      <div className="space-y-4">
        {journals.map((entry) => {
          const moodObj = moodEmojis.find((m) => m.score === entry.mood) || moodEmojis[4];
          return (
            <GlassCard key={entry.id} className="p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{moodObj.emoji}</span>
                  <div>
                    <h3 className="text-base font-bold text-white">{entry.title}</h3>
                    <div className="flex items-center gap-3 text-[11px] text-apple-gray-400 mt-0.5">
                      <span>{entry.entryDate}</span>
                      {entry.weather && <span className="flex items-center gap-1"><Sun className="w-3 h-3 text-apple-orange" /> {entry.weather}</span>}
                      {entry.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-apple-blue" /> {entry.location}</span>}
                    </div>
                  </div>
                </div>

                <Badge variant="orange" size="sm">Mood: {entry.moodLabel || moodObj.label}</Badge>
              </div>

              <p className="text-xs sm:text-sm text-apple-gray-200 leading-relaxed whitespace-pre-line">
                {entry.content}
              </p>

              {entry.gratitudeList && Array.isArray(entry.gratitudeList) && entry.gratitudeList.length > 0 && (
                <div className="p-3 rounded-2xl bg-white/5 border border-white/5 space-y-1.5">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-apple-gray-400 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-apple-orange" /> Gratitude & Breakthroughs
                  </span>
                  <ul className="text-xs text-apple-gray-300 space-y-1 pl-4 list-disc">
                    {entry.gratitudeList.map((g, idx) => (
                      <li key={idx}>{g}</li>
                    ))}
                  </ul>
                </div>
              )}
            </GlassCard>
          );
        })}
      </div>

      {/* Create Journal Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="New Journal Entry">
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Entry Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Clarity, Focus, and Architectural Symmetry"
              className="w-full glass-input rounded-xl px-4 py-2 text-sm text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-2">Mood</label>
            <div className="flex gap-2">
              {moodEmojis.map((m) => (
                <button
                  key={m.score}
                  type="button"
                  onClick={() => setMood(m.score)}
                  className={`flex-1 py-2 rounded-xl text-xl border transition-all ${
                    mood === m.score
                      ? 'bg-apple-blue/20 border-apple-blue shadow-apple-glow scale-105'
                      : 'bg-white/5 border-white/5 opacity-60 hover:opacity-100'
                  }`}
                >
                  {m.emoji}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Reflection / Notes</label>
            <textarea
              rows={4}
              required
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="What went exceptionally well today? What did you learn?"
              className="w-full glass-input rounded-xl px-4 py-2 text-xs text-white focus:outline-none resize-none leading-relaxed"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-medium text-apple-gray-300">Three Gratitudes (Optional)</label>
            <input
              type="text"
              value={gratitude1}
              onChange={(e) => setGratitude1(e.target.value)}
              placeholder="1. Something you are grateful for..."
              className="w-full glass-input rounded-xl px-3 py-1.5 text-xs text-white"
            />
            <input
              type="text"
              value={gratitude2}
              onChange={(e) => setGratitude2(e.target.value)}
              placeholder="2. A breakthrough or pleasant moment..."
              className="w-full glass-input rounded-xl px-3 py-1.5 text-xs text-white"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" size="sm" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Entry
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
