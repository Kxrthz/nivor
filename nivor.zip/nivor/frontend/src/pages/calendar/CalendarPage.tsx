import React, { useState } from 'react';
import { Plus, Calendar as CalendarIcon, Clock, MapPin, RefreshCw, Sparkles, CheckCircle2 } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Modal } from '../../components/ui/Modal';
import { Badge } from '../../components/ui/Badge';

export const CalendarPage: React.FC = () => {
  const { events, addEvent, deleteEvent } = useAppStore();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [location, setLocation] = useState('');
  const [category, setCategory] = useState('Work');
  const [startTime, setStartTime] = useState(new Date().toISOString().slice(0, 16));
  const [endTime, setEndTime] = useState(new Date(Date.now() + 3600000).toISOString().slice(0, 16));

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    addEvent({
      title,
      location,
      category,
      startTime: new Date(startTime).toISOString(),
      endTime: new Date(endTime).toISOString(),
      color: category === 'Work' ? '#0A84FF' : category === 'Personal' ? '#FF375F' : '#BF5AF2',
    });

    setTitle('');
    setLocation('');
    setIsCreateOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Calendar</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Apple Calendar & Google Sync Unified Timeline
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="sm"
            onClick={() => setIsCreateOpen(true)}
            icon={<Plus className="w-4 h-4" />}
          >
            New Event
          </Button>
        </div>
      </div>

      {/* Sync Status Banner */}
      <GlassCard className="p-4 bg-gradient-to-r from-apple-blue/10 via-apple-purple/10 to-transparent flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-apple-blue/20 text-apple-blue">
            <RefreshCw className="w-4 h-4 animate-spin-slow" />
          </div>
          <div>
            <span className="text-xs font-bold text-white">Live Multi-Calendar Sync</span>
            <p className="text-[11px] text-apple-gray-400">
              Synced with Apple iCloud, Google Calendar, and Outlook Exchange.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="blue" size="sm">Google: Connected</Badge>
          <Badge variant="purple" size="sm">Apple: Connected</Badge>
        </div>
      </GlassCard>

      {/* Events Timeline Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Timeline Stream */}
        <div className="lg:col-span-2 space-y-3">
          <h3 className="text-xs font-bold text-apple-gray-400 uppercase tracking-wider px-1">
            Upcoming Events ({events.length})
          </h3>

          <div className="space-y-3">
            {events.map((ev) => (
              <GlassCard key={ev.id} className="p-4 border-l-4" style={{ borderLeftColor: ev.color }}>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-bold text-white">{ev.title}</h4>
                      <Badge variant="gray" size="sm">{ev.syncSource}</Badge>
                    </div>

                    {ev.description && (
                      <p className="text-xs text-apple-gray-300 mt-1">{ev.description}</p>
                    )}

                    <div className="flex flex-wrap items-center gap-4 text-[11px] text-apple-gray-400 mt-2">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-apple-blue" />
                        {new Date(ev.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} –{' '}
                        {new Date(ev.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      {ev.location && (
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-apple-orange" />
                          {ev.location}
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => deleteEvent(ev.id)}
                    className="text-xs text-apple-gray-500 hover:text-apple-red transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>

        {/* Countdowns & Birthdays Widget */}
        <div className="space-y-4">
          <h3 className="text-xs font-bold text-apple-gray-400 uppercase tracking-wider px-1">
            Countdowns & Milestones
          </h3>

          <GlassCard className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">Quantum OS 3.0 Launch</span>
              <Badge variant="blue" size="sm">T-Minus 14 Days</Badge>
            </div>
            <div className="w-full bg-white/10 rounded-full h-1.5">
              <div className="bg-apple-blue h-1.5 rounded-full w-3/4" />
            </div>
            <p className="text-[11px] text-apple-gray-400">
              Target Keynote: Oct 1, 2026 • Infinite Loop
            </p>
          </GlassCard>

          <GlassCard className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">Tokyo Marathon 2027</span>
              <Badge variant="green" size="sm">164 Days</Badge>
            </div>
            <div className="w-full bg-white/10 rounded-full h-1.5">
              <div className="bg-apple-green h-1.5 rounded-full w-2/5" />
            </div>
            <p className="text-[11px] text-apple-gray-400">
              Sub-3:30 target pacing plan active
            </p>
          </GlassCard>
        </div>
      </div>

      {/* Create Event Modal */}
      <Modal isOpen={isCreateOpen} onClose={() => setIsCreateOpen(false)} title="Schedule New Event">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Event Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Design Architecture Review"
              className="w-full glass-input rounded-xl px-4 py-2 text-sm text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Location / Link</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Room 4B / Zoom URL"
              className="w-full glass-input rounded-xl px-4 py-2 text-sm text-white focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-apple-gray-300 mb-1">Start Time</label>
              <input
                type="datetime-local"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-apple-gray-300 mb-1">End Time</label>
              <input
                type="datetime-local"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white bg-apple-gray-900"
            >
              <option value="Work">Work</option>
              <option value="Keynote">Keynote / Demo</option>
              <option value="Personal">Personal</option>
            </select>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" size="sm" onClick={() => setIsCreateOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Event
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
