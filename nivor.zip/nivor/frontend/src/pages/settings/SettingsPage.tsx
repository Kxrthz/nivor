import React, { useState } from 'react';
import { Settings, Moon, Sun, Palette, Bell, Shield, Download, Sparkles, Volume2 } from 'lucide-react';
import { useThemeStore } from '../../store/useThemeStore';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Toggle } from '../../components/ui/Toggle';
import { AccentColor } from '../../types';

export const SettingsPage: React.FC = () => {
  const { theme, setTheme, accentColor, setAccentColor } = useThemeStore();
  const { tasks, notes, habits, goals, journals } = useAppStore();

  const [soundEffects, setSoundEffects] = useState(true);
  const [haptics, setHaptics] = useState(true);
  const [aiMemory, setAiMemory] = useState(true);
  const [emailDigest, setEmailDigest] = useState(true);
  const [aiPersonality, setAiPersonality] = useState('Apple Intelligence Executive');

  const accentColors: { id: AccentColor; label: string; hex: string }[] = [
    { id: 'system_blue', label: 'System Blue', hex: '#0A84FF' },
    { id: 'purple', label: 'Vibrant Purple', hex: '#BF5AF2' },
    { id: 'emerald', label: 'Emerald Green', hex: '#30D158' },
    { id: 'orange', label: 'Warm Orange', hex: '#FF9F0A' },
    { id: 'rose', label: 'Coral Rose', hex: '#FF375F' },
    { id: 'cyan', label: 'Pacific Cyan', hex: '#64D2FF' },
    { id: 'gold', label: 'Solar Gold', hex: '#FFD60A' },
  ];

  const handleExportData = () => {
    const fullBackup = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      tasks,
      notes,
      habits,
      goals,
      journals,
    };
    const blob = new Blob([JSON.stringify(fullBackup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NIVOR_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Settings</h1>
        <p className="text-xs text-apple-gray-400 mt-1">
          Customize design materials, dynamic accent colors, AI personality, and local backup
        </p>
      </div>

      {/* Appearance & Dynamic Theme */}
      <GlassCard className="p-6 space-y-5">
        <div className="flex items-center gap-2.5 pb-2 border-b border-white/10">
          <Palette className="w-5 h-5 text-apple-blue" />
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Appearance & Materials</h3>
        </div>

        {/* Theme Mode Toggle */}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-white">Interface Theme</span>
            <p className="text-[11px] text-apple-gray-400">Switch between frosted Dark and Light glassmorphism.</p>
          </div>

          <div className="flex items-center gap-2 p-1 rounded-xl bg-white/5 border border-white/10">
            <button
              onClick={() => setTheme('dark')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                theme === 'dark' ? 'bg-apple-blue text-white shadow-sm' : 'text-apple-gray-400 hover:text-white'
              }`}
            >
              <Moon className="w-3.5 h-3.5" /> Dark
            </button>
            <button
              onClick={() => setTheme('light')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                theme === 'light' ? 'bg-apple-blue text-white shadow-sm' : 'text-apple-gray-400 hover:text-white'
              }`}
            >
              <Sun className="w-3.5 h-3.5" /> Light
            </button>
          </div>
        </div>

        {/* Dynamic Accent Color */}
        <div className="space-y-2 pt-2">
          <span className="text-xs font-semibold text-white">Dynamic Accent Color</span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
            {accentColors.map((c) => (
              <button
                key={c.id}
                onClick={() => setAccentColor(c.id)}
                className={`flex items-center gap-2.5 p-2.5 rounded-xl border transition-all ${
                  accentColor === c.id
                    ? 'bg-white/15 border-white/40 shadow-sm'
                    : 'bg-white/5 border-white/5 hover:bg-white/10'
                }`}
              >
                <span className="w-4 h-4 rounded-full shrink-0 shadow-sm" style={{ backgroundColor: c.hex }} />
                <span className="text-xs font-medium text-white">{c.label}</span>
              </button>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* AI Intelligence Preferences */}
      <GlassCard className="p-6 space-y-4">
        <div className="flex items-center gap-2.5 pb-2 border-b border-white/10">
          <Sparkles className="w-5 h-5 text-apple-purple" />
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Apple Intelligence & Memory</h3>
        </div>

        <Toggle
          checked={aiMemory}
          onChange={setAiMemory}
          label="Long-Term Context Memory"
          description="Allows NIVOR AI to remember ongoing goals, habits, and schedule preferences."
        />

        <div className="pt-2">
          <label className="block text-xs font-semibold text-white mb-1.5">Executive Tone</label>
          <select
            value={aiPersonality}
            onChange={(e) => setAiPersonality(e.target.value)}
            className="w-full glass-input rounded-xl px-4 py-2 text-xs text-white bg-apple-gray-900 border border-white/10"
          >
            <option value="Apple Intelligence Executive">Apple Intelligence Executive (Direct, concise, actionable)</option>
            <option value="Socratic Mentor">Socratic Mentor (Thought-provoking, strategic questions)</option>
            <option value="High-Performance Athletic Coach">High-Performance Athletic Coach (Energy, conditioning, focus)</option>
          </select>
        </div>
      </GlassCard>

      {/* Haptics & Feedback */}
      <GlassCard className="p-6 space-y-4">
        <div className="flex items-center gap-2.5 pb-2 border-b border-white/10">
          <Volume2 className="w-5 h-5 text-apple-green" />
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Haptics & Audio</h3>
        </div>

        <Toggle
          checked={soundEffects}
          onChange={setSoundEffects}
          label="Synthesizer Sound Effects"
          description="Plays subtle completion chimes on tasks and Pomodoro timer intervals."
        />

        <Toggle
          checked={haptics}
          onChange={setHaptics}
          label="Micro-Animation Physics"
          description="Spring physics transitions calibrated to Apple HIG standards."
        />
      </GlassCard>

      {/* Privacy, Export & Backup */}
      <GlassCard className="p-6 space-y-4">
        <div className="flex items-center gap-2.5 pb-2 border-b border-white/10">
          <Shield className="w-5 h-5 text-apple-cyan" />
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">Data Privacy & Local Backup</h3>
        </div>

        <p className="text-xs text-apple-gray-300 leading-relaxed">
          NIVOR uses client-side encryption and stateless JWT token authentication. You own 100% of your data at all times.
        </p>

        <Button
          variant="secondary"
          size="sm"
          onClick={handleExportData}
          icon={<Download className="w-4 h-4 text-apple-blue" />}
        >
          Export Full JSON Backup
        </Button>
      </GlassCard>
    </div>
  );
};
