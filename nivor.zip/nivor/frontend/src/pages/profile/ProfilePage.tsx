import React from 'react';
import { User, Award, Flame, Zap, ShieldCheck, LogOut, CheckCircle2 } from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { useNavigate } from 'react-router-dom';

export const ProfilePage: React.FC = () => {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/auth/login');
  };

  const badges = [
    { title: 'Deep Work Master', desc: 'Logged 100+ uninterrupted flow hours', icon: Zap, color: 'text-apple-purple' },
    { title: 'Habit Champion', desc: 'Maintained 30-day streak across 4 habits', icon: Flame, color: 'text-apple-orange' },
    { title: 'Zero Latency Architect', desc: 'Spring Boot 3 + React 19 compilation', icon: ShieldCheck, color: 'text-apple-blue' },
    { title: 'Mastery Mindset', desc: 'Achieved 5 major milestone roadmaps', icon: Award, color: 'text-apple-green' },
  ];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Profile Hero Card */}
      <GlassCard className="p-6 md:p-8 flex flex-col md:flex-row items-center gap-6 justify-between bg-gradient-to-r from-apple-blue/15 via-black/40 to-transparent">
        <div className="flex items-center gap-5">
          <img
            src={user?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80'}
            alt="Avatar"
            className="w-20 h-20 rounded-3xl object-cover border-2 border-white/20 shadow-xl"
          />
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                {user?.fullName || 'Alexander Wright'}
              </h2>
              <Badge variant="blue" size="sm">NIVOR Enterprise</Badge>
            </div>
            <p className="text-xs text-apple-gray-400 mt-1">{user?.email || 'demo@nivor.app'}</p>
            <span className="text-[11px] text-apple-green font-semibold mt-1 inline-block">
              ● Active Cloud Sync Engine
            </span>
          </div>
        </div>

        <Button
          variant="danger"
          size="sm"
          onClick={handleLogout}
          icon={<LogOut className="w-4 h-4" />}
        >
          Sign Out
        </Button>
      </GlassCard>

      {/* Achievements & Badges */}
      <GlassCard className="p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            Ecosystem Badges & Milestones ({badges.length})
          </h3>
          <Badge variant="purple" size="sm">All Unlocked</Badge>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
          {badges.map((b) => (
            <div
              key={b.title}
              className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-start gap-3.5 hover:bg-white/10 transition-colors"
            >
              <div className="p-2.5 rounded-xl bg-white/10 shrink-0 mt-0.5">
                <b.icon className={`w-5 h-5 ${b.color}`} />
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">{b.title}</h4>
                <p className="text-[11px] text-apple-gray-400 mt-0.5">{b.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
};
