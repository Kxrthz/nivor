import React from 'react';
import { Activity, Droplets, Moon, Footprints, Flame, Plus, Heart } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { ProgressRing } from '../../components/ui/ProgressRing';
import { Badge } from '../../components/ui/Badge';

export const HealthPage: React.FC = () => {
  const { health, logHealthMetric } = useAppStore();

  const waterPct = Math.min(100, Math.round((health.waterMl / health.waterTargetMl) * 100));
  const sleepPct = Math.min(100, Math.round((health.sleepHours / health.sleepTargetHours) * 100));
  const stepsPct = Math.min(100, Math.round((health.steps / health.stepsTarget) * 100));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Health & Vitality</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Apple Health bio-metric tracking & performance recovery architecture
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="green" size="md" icon={<Heart className="w-3.5 h-3.5" />}>
            Recovery: Optimal (96%)
          </Badge>
        </div>
      </div>

      {/* 3 Core Metric Rings */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Hydration */}
        <GlassCard className="p-6 flex flex-col items-center text-center space-y-3">
          <div className="flex items-center justify-between w-full">
            <span className="text-xs font-bold text-apple-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <Droplets className="w-4 h-4 text-apple-cyan" /> Hydration
            </span>
            <Badge variant="blue" size="sm">{waterPct}%</Badge>
          </div>

          <ProgressRing progress={waterPct} size={110} strokeWidth={9} color="#64D2FF">
            <div className="text-center">
              <span className="text-xl font-extrabold text-white">{health.waterMl}</span>
              <span className="text-[10px] text-apple-gray-400 block font-semibold">/ {health.waterTargetMl} ml</span>
            </div>
          </ProgressRing>

          <div className="flex gap-2 pt-2 w-full">
            <Button
              variant="secondary"
              size="sm"
              className="flex-1"
              onClick={() => logHealthMetric('WATER_ML', 250)}
            >
              +250ml
            </Button>
            <Button
              variant="secondary"
              size="sm"
              className="flex-1"
              onClick={() => logHealthMetric('WATER_ML', 500)}
            >
              +500ml
            </Button>
          </div>
        </GlassCard>

        {/* Steps */}
        <GlassCard className="p-6 flex flex-col items-center text-center space-y-3">
          <div className="flex items-center justify-between w-full">
            <span className="text-xs font-bold text-apple-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <Footprints className="w-4 h-4 text-apple-green" /> Daily Steps
            </span>
            <Badge variant="green" size="sm">{stepsPct}%</Badge>
          </div>

          <ProgressRing progress={stepsPct} size={110} strokeWidth={9} color="#30D158">
            <div className="text-center">
              <span className="text-xl font-extrabold text-white">{health.steps.toLocaleString()}</span>
              <span className="text-[10px] text-apple-gray-400 block font-semibold">/ {health.stepsTarget.toLocaleString()}</span>
            </div>
          </ProgressRing>

          <Button
            variant="secondary"
            size="sm"
            className="w-full mt-2"
            onClick={() => logHealthMetric('STEPS', 1000)}
          >
            +1,000 Steps
          </Button>
        </GlassCard>

        {/* Sleep */}
        <GlassCard className="p-6 flex flex-col items-center text-center space-y-3">
          <div className="flex items-center justify-between w-full">
            <span className="text-xs font-bold text-apple-gray-400 uppercase tracking-wider flex items-center gap-1.5">
              <Moon className="w-4 h-4 text-apple-purple" /> Sleep Duration
            </span>
            <Badge variant="purple" size="sm">{sleepPct}%</Badge>
          </div>

          <ProgressRing progress={sleepPct} size={110} strokeWidth={9} color="#BF5AF2">
            <div className="text-center">
              <span className="text-xl font-extrabold text-white">{health.sleepHours}h</span>
              <span className="text-[10px] text-apple-gray-400 block font-semibold">/ {health.sleepTargetHours}h Goal</span>
            </div>
          </ProgressRing>

          <p className="text-xs text-apple-gray-400 pt-2">
            Deep sleep: 2h 15m • REM: 2h 30m
          </p>
        </GlassCard>
      </div>

      {/* Workout & Weight Matrix */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <GlassCard className="p-6 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Workout & Athletic Conditioning
            </span>
            <Badge variant="orange" size="sm">{health.workoutMinutes} Mins Logged</Badge>
          </div>
          <p className="text-xs text-apple-gray-300 leading-relaxed">
            Morning 7km Zone 2 aerobic recovery run completed along coastal trail. Aerobic efficiency index rating: 1.18.
          </p>
          <Button
            variant="glass"
            size="sm"
            onClick={() => logHealthMetric('WORKOUT_MIN', 30)}
            icon={<Flame className="w-4 h-4 text-apple-orange" />}
          >
            +30m Workout Log
          </Button>
        </GlassCard>

        <GlassCard className="p-6 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white uppercase tracking-wider">
              Body Composition
            </span>
            <Badge variant="blue" size="sm">{health.weightKg} kg</Badge>
          </div>
          <p className="text-xs text-apple-gray-300 leading-relaxed">
            Lean body mass steady at 64.2kg. Estimated body fat percentage: 11.4%.
          </p>
          <div className="flex items-center gap-2 pt-1 text-xs text-apple-gray-400">
            <span>DEXA Trend: Optimal athletic conditioning</span>
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
