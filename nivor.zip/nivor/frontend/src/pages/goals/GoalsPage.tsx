import React, { useState } from 'react';
import { Plus, Target, CheckCircle2, Circle, Sparkles, Calendar, ChevronRight } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';

export const GoalsPage: React.FC = () => {
  const { goals, addGoal, toggleMilestone } = useAppStore();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Career');
  const [targetDate, setTargetDate] = useState('2026-12-31');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    addGoal({
      title,
      description,
      category,
      targetDate,
      color: category === 'Career' ? '#0A84FF' : category === 'Health' ? '#30D158' : '#BF5AF2',
      milestones: [
        { id: Date.now() + 1, goalId: Date.now(), title: 'Phase 1: Architecture & Validation', isCompleted: false, orderIndex: 1 },
        { id: Date.now() + 2, goalId: Date.now(), title: 'Phase 2: Alpha Testing & Benchmark', isCompleted: false, orderIndex: 2 },
      ],
    });

    setTitle('');
    setDescription('');
    setIsCreateOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Goals & OKRs</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Hierarchical milestone architecture with AI roadmaps
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="sm"
            onClick={() => setIsCreateOpen(true)}
            icon={<Plus className="w-4 h-4" />}
          >
            New Goal
          </Button>
        </div>
      </div>

      {/* Goals Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {goals.map((goal) => (
          <GlassCard key={goal.id} className="p-6 space-y-4">
            {/* Header */}
            <div className="flex items-start justify-between">
              <div>
                <Badge variant={goal.category === 'Career' ? 'blue' : 'green'} size="sm">
                  {goal.category}
                </Badge>
                <h3 className="text-base font-bold text-white mt-2">{goal.title}</h3>
                {goal.description && (
                  <p className="text-xs text-apple-gray-400 mt-1 leading-relaxed">
                    {goal.description}
                  </p>
                )}
              </div>
              <span className="text-xl font-extrabold text-white">{goal.progressPercentage}%</span>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-white/10 rounded-full h-2">
              <div
                className="h-2 rounded-full transition-all duration-500 shadow-sm"
                style={{
                  width: `${goal.progressPercentage}%`,
                  backgroundColor: goal.color,
                }}
              />
            </div>

            {/* AI Roadmap Note */}
            {goal.aiRoadmap && (
              <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-xs text-apple-gray-300 flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-apple-blue shrink-0 mt-0.5" />
                <span className="leading-relaxed">{goal.aiRoadmap}</span>
              </div>
            )}

            {/* Milestones Checklist */}
            <div className="space-y-2 pt-2 border-t border-white/10">
              <span className="text-[10px] uppercase font-bold tracking-wider text-apple-gray-400">
                Milestones
              </span>

              <div className="space-y-1.5">
                {goal.milestones.map((ms) => (
                  <div
                    key={ms.id}
                    onClick={() => toggleMilestone(goal.id, ms.id)}
                    className="flex items-center gap-2.5 p-2 rounded-xl hover:bg-white/5 cursor-pointer transition-colors"
                  >
                    {ms.isCompleted ? (
                      <CheckCircle2 className="w-4 h-4 text-apple-green shrink-0" />
                    ) : (
                      <Circle className="w-4 h-4 text-apple-gray-500 shrink-0" />
                    )}
                    <span
                      className={`text-xs font-medium ${
                        ms.isCompleted ? 'line-through text-apple-gray-400' : 'text-white'
                      }`}
                    >
                      {ms.title}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </GlassCard>
        ))}
      </div>

      {/* Create Goal Modal */}
      <Modal isOpen={isCreateOpen} onClose={() => setIsCreateOpen(false)} title="Create New Long-Term Goal">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Goal Title</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Scale NIVOR to 100,000 Users"
              className="w-full glass-input rounded-xl px-4 py-2 text-sm text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Description / Target Outcome</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What does success look like?"
              className="w-full glass-input rounded-xl px-4 py-2 text-xs text-white focus:outline-none resize-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-apple-gray-300 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white bg-apple-gray-900"
              >
                <option value="Career">Career & Startup</option>
                <option value="Health">Health & Athletic</option>
                <option value="Wealth">Wealth & Portfolio</option>
                <option value="Learning">Learning & Mastery</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-apple-gray-300 mb-1">Target Date</label>
              <input
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="w-full glass-input rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" size="sm" onClick={() => setIsCreateOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Create Goal
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
