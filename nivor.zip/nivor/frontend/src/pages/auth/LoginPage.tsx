import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';
import { useAuthStore } from '../../store/useAuthStore';
import { Button } from '../../components/ui/Button';
import { GlassCard } from '../../components/ui/GlassCard';

export const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('demo@nivor.app');
  const [password, setPassword] = useState('Password123!');
  const [loading, setLoading] = useState(false);
  const { login } = useAuthStore();
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await login(email, password);
    setLoading(false);
    navigate('/');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-black p-4 relative overflow-hidden">
      {/* Background Lighting Orbs */}
      <div className="absolute top-1/4 left-1/3 w-96 h-96 bg-apple-blue/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/3 w-96 h-96 bg-apple-purple/20 rounded-full blur-3xl pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md z-10"
      >
        <GlassCard className="p-8 backdrop-blur-3xl border border-white/15 shadow-2xl">
          {/* Logo & Header */}
          <div className="flex flex-col items-center text-center mb-8">
            <div className="h-12 w-12 rounded-2xl bg-gradient-to-tr from-apple-blue via-blue-600 to-indigo-500 flex items-center justify-center shadow-apple-glow mb-3">
              <span className="font-extrabold text-white text-2xl tracking-wider">N</span>
            </div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">Welcome to NIVOR</h1>
            <p className="text-xs text-apple-gray-400 mt-1">Everything. Organized. Peak productivity OS.</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-apple-gray-300 mb-1.5">Email Address</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@company.com"
                className="w-full glass-input rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-apple-gray-300 mb-1.5">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full glass-input rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none"
              />
            </div>

            <Button
              type="submit"
              variant="primary"
              size="lg"
              className="w-full mt-2"
              disabled={loading}
              icon={<ArrowRight className="w-4 h-4" />}
            >
              {loading ? 'Authenticating...' : 'Sign In to Workspace'}
            </Button>
          </form>

          {/* Demo Note */}
          <div className="mt-6 pt-4 border-t border-white/10 text-center">
            <p className="text-[11px] text-apple-gray-400">
              Demo account pre-filled: <span className="text-white font-mono font-semibold">demo@nivor.app</span> / <span className="text-white font-mono font-semibold">Password123!</span>
            </p>
            <p className="text-xs text-apple-gray-400 mt-3">
              Don't have an account?{' '}
              <Link to="/auth/register" className="text-apple-blue font-semibold hover:underline">
                Register
              </Link>
            </p>
          </div>
        </GlassCard>
      </motion.div>
    </div>
  );
};
