import React, { useState } from 'react';
import { Plus, FolderKanban, Layers, CheckCircle2, Clock, ArrowRight, MoreHorizontal } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';

export const WorkspacePage: React.FC = () => {
  const { projects, addProject, tasks, updateTask, addTask } = useAppStore();
  const [selectedProjectId, setSelectedProjectId] = useState<number>(projects[0]?.id || 1);
  const [isNewProjectModal, setIsNewProjectModal] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');

  const activeProject = projects.find((p) => p.id === selectedProjectId) || projects[0];
  const projectTasks = tasks.filter((t) => t.projectId === activeProject?.id || !t.projectId);

  const todoTasks = projectTasks.filter((t) => t.status === 'TODO');
  const inProgressTasks = projectTasks.filter((t) => t.status === 'IN_PROGRESS');
  const completedTasks = projectTasks.filter((t) => t.status === 'COMPLETED');

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectName.trim()) return;

    const id = Date.now();
    addProject({
      id,
      name: newProjectName,
      description: newProjectDesc,
      color: '#0A84FF',
      viewMode: 'KANBAN',
    });

    setSelectedProjectId(id);
    setNewProjectName('');
    setNewProjectDesc('');
    setIsNewProjectModal(false);
  };

  const handleMoveTask = (taskId: number, newStatus: 'TODO' | 'IN_PROGRESS' | 'COMPLETED') => {
    updateTask(taskId, { status: newStatus });
  };

  const handleQuickAddTask = (status: 'TODO' | 'IN_PROGRESS' | 'COMPLETED') => {
    const title = prompt('Task Title:');
    if (title && title.trim()) {
      addTask({
        title,
        status,
        projectId: activeProject?.id,
        priority: 'MEDIUM',
      });
    }
  };

  const columns: { id: 'TODO' | 'IN_PROGRESS' | 'COMPLETED'; label: string; tasks: typeof tasks; color: string }[] = [
    { id: 'TODO', label: 'To Do', tasks: todoTasks, color: 'text-apple-blue' },
    { id: 'IN_PROGRESS', label: 'In Progress', tasks: inProgressTasks, color: 'text-apple-orange' },
    { id: 'COMPLETED', label: 'Completed', tasks: completedTasks, color: 'text-apple-green' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Workspace</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Linear-grade project execution & interactive Kanban lanes
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="sm"
            onClick={() => setIsNewProjectModal(true)}
            icon={<Plus className="w-4 h-4" />}
          >
            New Project
          </Button>
        </div>
      </div>

      {/* Project Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {projects.map((p) => {
          const isSelected = p.id === activeProject?.id;
          return (
            <button
              key={p.id}
              onClick={() => setSelectedProjectId(p.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all shrink-0 border select-none ${
                isSelected
                  ? 'bg-apple-blue text-white border-apple-blue shadow-apple-glow'
                  : 'bg-white/5 border-white/5 text-apple-gray-400 hover:text-white hover:bg-white/10'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{p.name}</span>
            </button>
          );
        })}
      </div>

      {/* Kanban Board Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {columns.map((col) => (
          <div key={col.id} className="flex flex-col space-y-3">
            {/* Column Header */}
            <div className="flex items-center justify-between px-2">
              <div className="flex items-center gap-2">
                <span className={`text-xs font-bold uppercase tracking-wider ${col.color}`}>
                  {col.label}
                </span>
                <span className="text-xs font-bold text-apple-gray-500">
                  {col.tasks.length}
                </span>
              </div>

              <button
                onClick={() => handleQuickAddTask(col.id)}
                className="p-1 rounded-lg text-apple-gray-400 hover:text-white hover:bg-white/10 transition-colors"
                title="Add task in this lane"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Lane Drop Container */}
            <div className="space-y-2.5 min-h-[400px] p-2 rounded-2xl bg-white/[0.02] border border-white/5">
              {col.tasks.map((task) => (
                <GlassCard key={task.id} className="p-3.5 space-y-2 group cursor-pointer">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="text-xs font-semibold text-white leading-snug">
                      {task.title}
                    </h4>
                    <Badge
                      variant={task.priority === 'URGENT' ? 'red' : task.priority === 'HIGH' ? 'orange' : 'blue'}
                      size="sm"
                    >
                      {task.priority}
                    </Badge>
                  </div>

                  {task.description && (
                    <p className="text-[11px] text-apple-gray-400 line-clamp-2">
                      {task.description}
                    </p>
                  )}

                  {/* Move Lane Trigger Pills */}
                  <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[10px] text-apple-gray-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {task.estimatedMinutes}m
                    </span>

                    <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                      {col.id !== 'TODO' && (
                        <button
                          onClick={() => handleMoveTask(task.id, 'TODO')}
                          className="px-1.5 py-0.5 rounded bg-white/5 hover:bg-white/10 hover:text-white"
                        >
                          ← To Do
                        </button>
                      )}
                      {col.id !== 'IN_PROGRESS' && (
                        <button
                          onClick={() => handleMoveTask(task.id, 'IN_PROGRESS')}
                          className="px-1.5 py-0.5 rounded bg-white/5 hover:bg-white/10 hover:text-white"
                        >
                          In Progress
                        </button>
                      )}
                      {col.id !== 'COMPLETED' && (
                        <button
                          onClick={() => handleMoveTask(task.id, 'COMPLETED')}
                          className="px-1.5 py-0.5 rounded bg-apple-green/20 text-apple-green hover:bg-apple-green/30"
                        >
                          ✓ Done
                        </button>
                      )}
                    </div>
                  </div>
                </GlassCard>
              ))}

              {col.tasks.length === 0 && (
                <div className="py-12 text-center text-apple-gray-500 text-xs">
                  No tasks in this lane.
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Create Project Modal */}
      <Modal isOpen={isNewProjectModal} onClose={() => setIsNewProjectModal(false)} title="Create New Workspace Project">
        <form onSubmit={handleCreateProject} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Project Name</label>
            <input
              type="text"
              required
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              placeholder="e.g. NextGen VisionOS Client"
              className="w-full glass-input rounded-xl px-4 py-2 text-sm text-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Scope / Objective</label>
            <textarea
              rows={3}
              value={newProjectDesc}
              onChange={(e) => setNewProjectDesc(e.target.value)}
              placeholder="Key mission deliverables and release milestones..."
              className="w-full glass-input rounded-xl px-4 py-2 text-xs text-white focus:outline-none resize-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" size="sm" onClick={() => setIsNewProjectModal(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Create Project
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
