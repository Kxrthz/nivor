import React, { useState } from 'react';
import { Plus, Flame, Sparkles, Check, Trash2, Trophy } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { ProgressRing } from '../../components/ui/ProgressRing';
import { Modal } from '../../components/ui/Modal';
import { Badge } from '../../components/ui/Badge';

export const HabitsPage: React.FC = () => {
  const { habits, addHabit, toggleHabitCheckIn, deleteHabit } = useAppStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [targetCount, setTargetCount] = useState(1);
  const [unit, setUnit] = useState('times');
  const [color, setColor] = useState('#30D158');

  const completedTodayCount = habits.filter((h) => h.completedToday).length;
  const overallHabitPct = habits.length > 0 ? Math.round((completedTodayCount / habits.length) * 100) : 0;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    addHabit({
      name,
      targetCountPerDay: targetCount,
      unit,
      color,
      frequency: 'DAILY',
    });

    setName('');
    setIsModalOpen(false);
  };

  const daysOfWeek = ['Fri', 'Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Today'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Habits & Streaks</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Apple Fitness-inspired streak rings & atomic habit consistency
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="sm"
            onClick={() => setIsModalOpen(true)}
            icon={<Plus className="w-4 h-4" />}
          >
            New Habit
          </Button>
        </div>
      </div>

      {/* Top Habit Analytics Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <GlassCard className="flex items-center gap-5 p-5">
          <ProgressRing progress={overallHabitPct} size={90} strokeWidth={8} color="#30D158">
            <span className="text-lg font-extrabold text-white">{overallHabitPct}%</span>
          </ProgressRing>
          <div>
            <span className="text-[10px] font-bold text-apple-gray-400 uppercase tracking-wider">
              Today's Completion
            </span>
            <h3 className="text-lg font-bold text-white mt-0.5">
              {completedTodayCount} of {habits.length} Done
            </h3>
            <p className="text-xs text-apple-green font-medium mt-0.5">Keep momentum active</p>
          </div>
        </GlassCard>

        <GlassCard className="p-5 flex flex-col justify-center">
          <div className="flex items-center gap-2 text-apple-orange mb-1">
            <Trophy className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-wider text-apple-gray-400">
              Longest Streak
            </span>
          </div>
          <h3 className="text-2xl font-extrabold text-white">45 Days</h3>
          <p className="text-xs text-apple-gray-400 mt-0.5">Hydrate 3.5 Liters Daily</p>
        </GlassCard>

        <GlassCard className="p-5 flex flex-col justify-center">
          <div className="flex items-center gap-2 text-apple-blue mb-1">
            <Sparkles className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-wider text-apple-gray-400">
              AI Habit Analysis
            </span>
          </div>
          <p className="text-xs text-apple-gray-200 leading-relaxed">
            "Your 14-day Deep Work block is driving an estimated 2.8x higher output in your Workspace projects."
          </p>
        </GlassCard>
      </div>

      {/* Habits List & 7-Day Matrix */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold text-apple-gray-400 uppercase tracking-wider px-1">
          Active Habit Matrix ({habits.length})
        </h3>

        <div className="space-y-3">
          {habits.map((h) => (
            <GlassCard key={h.id} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
              {/* Left Info */}
              <div className="flex items-center gap-3.5 min-w-0">
                <button
                  onClick={() => toggleHabitCheckIn(h.id)}
                  className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm transition-all shrink-0 select-none shadow-sm ${
                    h.completedToday
                      ? 'bg-apple-green text-black scale-105 shadow-apple-glow'
                      : 'bg-white/10 text-white hover:bg-white/20 border border-white/10'
                  }`}
                >
                  {h.completedToday ? <Check className="w-5 h-5 stroke-[3]" /> : h.currentStreak}
                </button>

                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-white truncate">{h.name}</h4>
                    <Badge variant="orange" size="sm" icon={<Flame className="w-3 h-3" />}>
                      {h.currentStreak}d streak
                    </Badge>
                  </div>
                  <p className="text-xs text-apple-gray-400 mt-0.5">
                    Target: {h.targetCountPerDay} {h.unit} • Best: {h.longestStreak} days
                  </p>
                </div>
              </div>

              {/* 7-Day Matrix Pills */}
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 p-1.5 rounded-xl bg-white/5 border border-white/5">
                  {daysOfWeek.map((day, idx) => {
                    const isToday = idx === 6;
                    const isDone = isToday ? h.completedToday : idx !== 1;
                    return (
                      <div key={day} className="flex flex-col items-center gap-1">
                        <span className="text-[9px] text-apple-gray-500 font-mono">{day}</span>
                        <div
                          className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-bold ${
                            isDone
                              ? 'bg-apple-green/20 text-apple-green border border-apple-green/40'
                              : 'bg-white/5 text-apple-gray-600 border border-white/5'
                          }`}
                        >
                          {isDone ? '✓' : '·'}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <button
                  onClick={() => deleteHabit(h.id)}
                  className="p-2 rounded-xl text-apple-gray-500 hover:text-apple-red hover:bg-apple-red/10 transition-colors ml-2"
                  title="Delete habit"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>

      {/* Create Habit Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Create New Habit">
        <form onSubmit={handleCreate} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Habit Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Read 30 Pages Non-Fiction"
              className="w-full glass-input rounded-xl px-4 py-2 text-sm text-white focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-apple-gray-300 mb-1">Daily Target</label>
              <input
                type="number"
                min="1"
                value={targetCount}
                onChange={(e) => setTargetCount(Number(e.target.value))}
                className="w-full glass-input rounded-xl px-4 py-2 text-sm text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-apple-gray-300 mb-1">Unit</label>
              <input
                type="text"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder="times / ml / pages"
                className="w-full glass-input rounded-xl px-4 py-2 text-sm text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-apple-gray-300 mb-1">Color Tone</label>
            <div className="flex gap-2">
              {['#30D158', '#0A84FF', '#BF5AF2', '#FF9F0A', '#FF375F', '#64D2FF'].map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={`w-7 h-7 rounded-full transition-transform ${
                    color === c ? 'scale-125 ring-2 ring-white' : 'opacity-80'
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" size="sm" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" size="sm">
              Save Habit
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
