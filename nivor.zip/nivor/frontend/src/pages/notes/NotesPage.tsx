import React, { useState } from 'react';
import { Plus, Pin, Trash2, Sparkles, Tag, FileText, CheckSquare, Edit3, Eye } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Note } from '../../types';

export const NotesPage: React.FC = () => {
  const { notes, addNote, updateNote, deleteNote } = useAppStore();
  const [selectedNoteId, setSelectedNoteId] = useState<number>(notes[0]?.id || 1);
  const [previewMode, setPreviewMode] = useState<'edit' | 'preview'>('edit');
  const [searchQuery, setSearchQuery] = useState('');

  const activeNote = notes.find((n) => n.id === selectedNoteId) || notes[0];

  const handleCreateNote = () => {
    const newNoteId = Date.now();
    addNote({
      id: newNoteId,
      title: 'New Thought',
      content: '# New Note\n\nStart typing with Markdown support...',
      summary: 'Draft note',
      tags: 'General',
      isPinned: false,
    });
    setSelectedNoteId(newNoteId);
  };

  const handleContentChange = (content: string) => {
    if (!activeNote) return;
    updateNote(activeNote.id, { content });
  };

  const handleTitleChange = (title: string) => {
    if (!activeNote) return;
    updateNote(activeNote.id, { title });
  };

  const handleTogglePin = () => {
    if (!activeNote) return;
    updateNote(activeNote.id, { isPinned: !activeNote.isPinned });
  };

  const handleAiSummarize = () => {
    if (!activeNote) return;
    const clean = activeNote.content.replace(/[#*`_]/g, ' ').slice(0, 120);
    updateNote(activeNote.id, {
      summary: `AI Summary: ${clean}... Key focus is architectural integrity and zero latency.`,
    });
  };

  const filteredNotes = notes.filter((n) =>
    n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    n.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Notes</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Markdown rich editor with Apple Notes aesthetics & AI summary engine
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="sm"
            onClick={handleCreateNote}
            icon={<Plus className="w-4 h-4" />}
          >
            New Note
          </Button>
        </div>
      </div>

      {/* Split Pane Architecture */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 h-[calc(100vh-230px)] min-h-[500px]">
        {/* Left Column: Note List */}
        <div className="md:col-span-4 flex flex-col space-y-3 h-full">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search notes..."
            className="w-full glass-input rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none placeholder:text-apple-gray-500"
          />

          <div className="flex-1 overflow-y-auto space-y-2 pr-1">
            {filteredNotes.map((n) => {
              const isSelected = n.id === activeNote?.id;
              return (
                <div
                  key={n.id}
                  onClick={() => setSelectedNoteId(n.id)}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer select-none ${
                    isSelected
                      ? 'bg-apple-blue/20 border-apple-blue/50 shadow-apple-glow'
                      : 'bg-white/5 border-white/5 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-white truncate max-w-[190px]">
                      {n.title || 'Untitled Note'}
                    </h4>
                    {n.isPinned && <Pin className="w-3 h-3 text-apple-orange fill-apple-orange" />}
                  </div>

                  <p className="text-[11px] text-apple-gray-400 line-clamp-2 mt-1">
                    {n.summary || n.content.replace(/[#*`]/g, '')}
                  </p>

                  <div className="flex items-center justify-between text-[10px] text-apple-gray-500 mt-2">
                    <span>{new Date(n.updatedAt).toLocaleDateString()}</span>
                    {n.tags && <span className="text-apple-blue font-medium">#{n.tags}</span>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Active Note Editor */}
        <div className="md:col-span-8 flex flex-col h-full">
          {activeNote ? (
            <GlassCard className="flex-1 flex flex-col p-5 overflow-hidden">
              {/* Note Header & Actions */}
              <div className="flex items-center justify-between pb-3 border-b border-white/10 gap-2">
                <input
                  type="text"
                  value={activeNote.title}
                  onChange={(e) => handleTitleChange(e.target.value)}
                  className="bg-transparent text-lg font-bold text-white focus:outline-none flex-1 truncate"
                  placeholder="Note Title..."
                />

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleTogglePin}
                    className={`p-1.5 rounded-lg border transition-colors ${
                      activeNote.isPinned
                        ? 'bg-apple-orange/20 text-apple-orange border-apple-orange/40'
                        : 'text-apple-gray-400 hover:text-white bg-white/5 border-white/10'
                    }`}
                    title="Pin note"
                  >
                    <Pin className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={handleAiSummarize}
                    className="p-1.5 rounded-lg bg-apple-blue/20 text-apple-blue hover:bg-apple-blue/30 border border-apple-blue/30 transition-colors flex items-center gap-1 text-xs font-semibold"
                    title="Generate AI Summary"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Summarize</span>
                  </button>

                  <button
                    onClick={() => setPreviewMode(previewMode === 'edit' ? 'preview' : 'edit')}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-apple-gray-300 border border-white/10 transition-colors"
                    title="Toggle Preview"
                  >
                    {previewMode === 'edit' ? <Eye className="w-3.5 h-3.5" /> : <Edit3 className="w-3.5 h-3.5" />}
                  </button>

                  <button
                    onClick={() => deleteNote(activeNote.id)}
                    className="p-1.5 rounded-lg text-apple-gray-400 hover:text-apple-red hover:bg-apple-red/10 border border-white/10 transition-colors"
                    title="Delete Note"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* AI Summary Banner */}
              {activeNote.summary && (
                <div className="mt-3 p-2.5 rounded-xl bg-apple-blue/10 border border-apple-blue/20 text-xs text-apple-gray-200 flex items-start gap-2">
                  <Sparkles className="w-4 h-4 text-apple-blue shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{activeNote.summary}</span>
                </div>
              )}

              {/* Markdown Editor or Preview */}
              <div className="flex-1 overflow-y-auto mt-4">
                {previewMode === 'edit' ? (
                  <textarea
                    value={activeNote.content}
                    onChange={(e) => handleContentChange(e.target.value)}
                    placeholder="Write in Markdown (# Heading, - [ ] Checklist, **bold**)..."
                    className="w-full h-full bg-transparent text-sm text-apple-gray-100 font-mono resize-none focus:outline-none leading-relaxed"
                  />
                ) : (
                  <div className="prose prose-invert max-w-none text-xs sm:text-sm text-apple-gray-200 whitespace-pre-wrap leading-relaxed">
                    {activeNote.content}
                  </div>
                )}
              </div>
            </GlassCard>
          ) : (
            <GlassCard className="flex-1 flex items-center justify-center text-apple-gray-400 text-xs">
              Select or create a note to start writing.
            </GlassCard>
          )}
        </div>
      </div>
    </div>
  );
};
