import React, { useState } from 'react';
import { Sparkles, Send, Mic, MicOff, BookOpen, Calendar, Activity, Bot, Cpu, Zap, ArrowRight } from 'lucide-react';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { VoiceOrb } from '../../components/ai/VoiceOrb';
import { AiMessage } from '../../types';

export const AiAssistantPage: React.FC = () => {
  const [messages, setMessages] = useState<AiMessage[]>([
    {
      id: 1,
      sender: 'AI',
      content: `### Welcome to NIVOR Executive Intelligence 🧠
I am connected directly to your Tasks, Calendar, Health metrics, and Financial budgets.

Select a specialized executive mode below or ask me any question:`,
      createdAt: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [selectedMode, setSelectedMode] = useState<'GENERAL' | 'STUDY' | 'WORKOUT' | 'SCHEDULE'>('GENERAL');
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [isTyping, setIsTyping] = useState(false);

  const handleSend = (textToSend?: string) => {
    const prompt = textToSend || input;
    if (!prompt.trim()) return;

    const userMsg: AiMessage = {
      id: Date.now(),
      sender: 'USER',
      content: prompt,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      let reply = 'Execution confirmed. I have updated your priority queue and mapped optimal timeblocks across your week.';
      const p = prompt.toLowerCase();

      if (p.includes('study') || selectedMode === 'STUDY') {
        reply = `### 📘 14-Day Accelerated Systems Mastery
• **Module 1**: Raft consensus algorithms & state machine replication.
• **Module 2**: High-throughput LSM storage engine internals.
• **Module 3**: Chaos engineering & zero-downtime canary rollouts.

*Action taken*: Added 3 milestones to your Goals tracker with daily 45m review alerts.`;
      } else if (p.includes('workout') || selectedMode === 'WORKOUT') {
        reply = `### 🏃 Elite Aerobic & Strength Protocol
1. **Monday**: 8km Zone 2 Aerobic Base (Target HR 135-142 bpm)
2. **Tuesday**: Upper Body Push/Pull + 10m Core Matrix
3. **Thursday**: Threshold Tempo Run (4x 1km @ 3:55/km pace)
4. **Saturday**: 22km Long Endurance Run + Electrolyte replenishment.

*Action taken*: Mirrored workouts into NIVOR Health.`;
      } else if (p.includes('schedule') || selectedMode === 'SCHEDULE') {
        reply = `### ⏱️ Optimal Circadian Schedule Matrix
• **08:30 - 10:30**: ⚡ **Deep Flow**: High-Leverage Software Architecture
• **11:00 - 11:45**: 📅 **Executive Sync**: Product & Design HIG Audit
• **14:00 - 15:30**: 🎯 **Autonomous Focus**: API Endpoints Refactoring
• **17:00 - 18:00**: 💧 **Physical Recovery**: Zone 2 Run & Hydration`;
      }

      const aiMsg: AiMessage = {
        id: Date.now() + 1,
        sender: 'AI',
        content: reply,
        createdAt: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, aiMsg]);
      setIsTyping(false);
    }, 900);
  };

  const modes = [
    { id: 'GENERAL', label: 'Executive Intelligence', icon: Sparkles, color: 'text-apple-blue' },
    { id: 'SCHEDULE', label: 'Schedule Optimizer', icon: Calendar, color: 'text-apple-purple' },
    { id: 'STUDY', label: 'Study & Mastery Planner', icon: BookOpen, color: 'text-apple-orange' },
    { id: 'WORKOUT', label: 'Workout & Health Coach', icon: Activity, color: 'text-apple-green' },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">AI Assistant</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Multimodal executive intelligence powered by NIVOR Neural Core
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="blue" size="md" icon={<Cpu className="w-3.5 h-3.5" />}>
            Neural Core v3.0 Active
          </Badge>
        </div>
      </div>

      {/* Mode Selector Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {modes.map((m) => {
          const isSelected = selectedMode === m.id;
          return (
            <button
              key={m.id}
              onClick={() => setSelectedMode(m.id as any)}
              className={`p-3.5 rounded-2xl border text-left transition-all ${
                isSelected
                  ? 'glass-card border-apple-blue/50 bg-apple-blue/15 shadow-apple-glow'
                  : 'glass-card border-white/5 bg-white/5 hover:bg-white/10 opacity-70 hover:opacity-100'
              }`}
            >
              <m.icon className={`w-5 h-5 mb-2 ${m.color}`} />
              <div className="text-xs font-bold text-white leading-tight">{m.label}</div>
            </button>
          );
        })}
      </div>

      {/* Voice Orb Interaction Banner */}
      {isVoiceActive && (
        <GlassCard className="py-8 flex flex-col items-center justify-center border-apple-blue/30 bg-apple-blue/10">
          <VoiceOrb isListening={true} size={140} />
          <p className="text-sm font-semibold text-white mt-4 animate-pulse">
            Listening for voice command...
          </p>
          <p className="text-xs text-apple-gray-400 mt-1">
            "Reschedule my afternoon meetings for a 90-minute focus block."
          </p>
        </GlassCard>
      )}

      {/* Chat History Box */}
      <GlassCard className="h-[480px] flex flex-col p-5 overflow-hidden">
        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex gap-3 ${m.sender === 'USER' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'AI' && (
                <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-apple-blue to-apple-purple flex items-center justify-center shrink-0 shadow-apple-glow">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}

              <div
                className={`max-w-[85%] sm:max-w-[75%] p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                  m.sender === 'USER'
                    ? 'bg-apple-blue text-white rounded-br-sm shadow-md'
                    : 'glass-card text-apple-gray-100 rounded-bl-sm border border-white/10 whitespace-pre-line'
                }`}
              >
                {m.content}
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center gap-2 text-apple-gray-400 text-xs pl-11">
              <span className="w-2 h-2 rounded-full bg-apple-blue animate-ping" />
              <span>Synthesizing response...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="pt-3 border-t border-white/10 flex items-center gap-2 mt-2">
          <button
            onClick={() => setIsVoiceActive(!isVoiceActive)}
            className={`p-2.5 rounded-xl border transition-colors ${
              isVoiceActive
                ? 'bg-apple-red/20 text-apple-red border-apple-red/40 animate-pulse'
                : 'text-apple-gray-400 hover:text-white bg-white/5 border-white/10'
            }`}
            title="Voice Chat"
          >
            {isVoiceActive ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={`Ask NIVOR AI in ${selectedMode.toLowerCase()} mode...`}
            className="flex-1 glass-input rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder:text-apple-gray-500 focus:outline-none"
          />

          <Button
            size="md"
            variant="primary"
            onClick={() => handleSend()}
            icon={<Send className="w-4 h-4" />}
          >
            Send
          </Button>
        </div>
      </GlassCard>
    </div>
  );
};
