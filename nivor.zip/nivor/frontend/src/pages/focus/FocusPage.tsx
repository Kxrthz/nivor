import React from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, Square, Volume2, Sparkles, Zap, Timer, CheckCircle2 } from 'lucide-react';
import { useFocusStore } from '../../store/useFocusStore';
import { useAudioStore, AmbientTrack } from '../../store/useAudioStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { SegmentedControl } from '../../components/ui/SegmentedControl';

export const FocusPage: React.FC = () => {
  const {
    isActive,
    isPaused,
    secondsRemaining,
    mode,
    durationMinutes,
    startFocus,
    pauseFocus,
    resumeFocus,
    stopFocus,
  } = useFocusStore();

  const { currentTrack, isPlaying, playTrack, togglePlay, setVolume, volume } = useAudioStore();

  const mins = Math.floor(secondsRemaining / 60);
  const secs = secondsRemaining % 60;
  const timeFormatted = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

  const modeOptions = [
    { id: 'POMODORO', label: 'Pomodoro (25m)' },
    { id: 'DEEP_WORK', label: 'Deep Flow (90m)' },
    { id: 'SHORT_BREAK', label: 'Break (5m)' },
  ];

  const ambientTracks: AmbientTrack[] = [
    'None',
    'Rainy Forest',
    'Rainy Cafe',
    'White Noise',
    'Deep Ocean',
  ];

  return (
    <div className="space-y-8 max-w-4xl mx-auto text-center py-4">
      {/* Mode Switcher */}
      <div className="flex justify-center">
        <SegmentedControl
          options={modeOptions}
          value={mode}
          onChange={(val) => startFocus(val as any)}
        />
      </div>

      {/* Main Focus Hero Circle */}
      <div className="flex flex-col items-center justify-center my-8">
        <motion.div
          animate={isActive && !isPaused ? { scale: [1, 1.02, 1] } : { scale: 1 }}
          transition={{ repeat: Infinity, duration: 4, ease: 'easeInOut' }}
          className="relative w-72 h-72 sm:w-84 sm:h-84 rounded-full glass-card border border-white/20 flex flex-col items-center justify-center p-6 shadow-2xl backdrop-blur-3xl"
        >
          {/* Subtle Ambient Pulse Background */}
          {isActive && !isPaused && (
            <div className="absolute inset-0 rounded-full bg-apple-blue/10 blur-xl animate-pulse-subtle pointer-events-none" />
          )}

          <span className="text-5xl sm:text-6xl font-extrabold text-white tracking-tighter font-mono select-none">
            {timeFormatted}
          </span>

          <span className="text-xs uppercase font-bold text-apple-gray-400 mt-2 tracking-widest">
            {mode === 'DEEP_WORK' ? 'Deep Work State' : mode === 'POMODORO' ? 'Pomodoro Block' : 'Recovery Break'}
          </span>

          {/* Controls Inside Circle */}
          <div className="flex items-center gap-3 mt-6">
            {!isActive ? (
              <Button
                variant="primary"
                size="lg"
                onClick={() => startFocus(mode)}
                icon={<Play className="w-5 h-5 fill-white" />}
                className="px-6 rounded-full"
              >
                Begin Focus
              </Button>
            ) : (
              <>
                <Button
                  variant={isPaused ? 'primary' : 'secondary'}
                  size="md"
                  onClick={isPaused ? resumeFocus : pauseFocus}
                  icon={isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
                  className="rounded-full"
                >
                  {isPaused ? 'Resume' : 'Pause'}
                </Button>
                <Button
                  variant="danger"
                  size="md"
                  onClick={stopFocus}
                  icon={<Square className="w-4 h-4" />}
                  className="rounded-full"
                >
                  Stop
                </Button>
              </>
            )}
          </div>
        </motion.div>
      </div>

      {/* Ambient Soundscape Synthesizer */}
      <GlassCard className="p-6 text-left space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-apple-blue/20 text-apple-blue">
              <Volume2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Binaural Ambient Soundscapes
              </h3>
              <p className="text-[11px] text-apple-gray-400">
                Web Audio API synthesizer designed to anchor cognitive flow.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs text-apple-gray-400">Volume</span>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="w-24 accent-apple-blue cursor-pointer"
            />
          </div>
        </div>

        {/* Track Pills */}
        <div className="flex flex-wrap gap-2 pt-1">
          {ambientTracks.map((t) => {
            const isSelected = currentTrack === t;
            return (
              <button
                key={t}
                onClick={() => playTrack(t)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all border ${
                  isSelected
                    ? 'bg-apple-blue text-white border-apple-blue shadow-apple-glow'
                    : 'bg-white/5 border-white/5 text-apple-gray-400 hover:text-white hover:bg-white/10'
                }`}
              >
                {t}
              </button>
            );
          })}
        </div>
      </GlassCard>
    </div>
  );
};
