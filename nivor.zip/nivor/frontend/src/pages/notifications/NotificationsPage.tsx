import React, { useState } from 'react';
import { Bell, Check, Zap, Flame, Wallet, Sparkles, CheckCheck } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';

export const NotificationsPage: React.FC = () => {
  const { notifications, markNotificationRead, markAllNotificationsRead } = useAppStore();
  const [filterUnread, setFilterUnread] = useState(false);

  const filtered = notifications.filter((n) => (filterUnread ? !n.isRead : true));

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'FOCUS_NUDGE':
        return <Zap className="w-4 h-4 text-apple-purple" />;
      case 'HABIT_STREAK':
        return <Flame className="w-4 h-4 text-apple-orange" />;
      case 'BILL_ALERT':
        return <Wallet className="w-4 h-4 text-apple-red" />;
      default:
        return <Sparkles className="w-4 h-4 text-apple-blue" />;
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Notifications</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Smart reminders, habit alerts, and AI proactive nudges
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={markAllNotificationsRead}
            icon={<CheckCheck className="w-4 h-4" />}
          >
            Mark All Read
          </Button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setFilterUnread(false)}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all select-none ${
            !filterUnread ? 'bg-apple-blue text-white' : 'bg-white/5 text-apple-gray-400 hover:text-white'
          }`}
        >
          All ({notifications.length})
        </button>
        <button
          onClick={() => setFilterUnread(true)}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all select-none ${
            filterUnread ? 'bg-apple-blue text-white' : 'bg-white/5 text-apple-gray-400 hover:text-white'
          }`}
        >
          Unread ({notifications.filter((n) => !n.isRead).length})
        </button>
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {filtered.map((n) => (
          <GlassCard
            key={n.id}
            className={`p-4 flex items-start justify-between gap-4 transition-all ${
              !n.isRead ? 'border-apple-blue/40 bg-apple-blue/5' : 'opacity-70'
            }`}
          >
            <div className="flex items-start gap-3.5">
              <div className="p-2.5 rounded-xl bg-white/10 shrink-0 mt-0.5">
                {getNotificationIcon(n.type)}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-white">{n.title}</h4>
                  {!n.isRead && (
                    <span className="w-2 h-2 rounded-full bg-apple-blue shrink-0" />
                  )}
                </div>
                <p className="text-xs text-apple-gray-300 mt-1">{n.body}</p>
                <span className="text-[10px] text-apple-gray-500 mt-1.5 block">
                  {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>

            {!n.isRead && (
              <button
                onClick={() => markNotificationRead(n.id)}
                className="p-1.5 rounded-lg text-apple-gray-400 hover:text-white hover:bg-white/10 transition-colors shrink-0"
                title="Mark as read"
              >
                <Check className="w-4 h-4" />
              </button>
            )}
          </GlassCard>
        ))}

        {filtered.length === 0 && (
          <div className="py-12 text-center text-apple-gray-400 text-xs">
            No notifications in this view.
          </div>
        )}
      </div>
    </div>
  );
};
