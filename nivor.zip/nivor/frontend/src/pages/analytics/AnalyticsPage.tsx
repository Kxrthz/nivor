import React from 'react';
import { BarChart3, TrendingUp, Sparkles, Award, CheckCircle2, Flame, Timer, Activity } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { ProgressRing } from '../../components/ui/ProgressRing';
import { Badge } from '../../components/ui/Badge';

export const AnalyticsPage: React.FC = () => {
  const { productivityScore } = useAppStore();

  const domainScores = [
    { title: 'Task Execution', score: productivityScore.taskScore, icon: CheckCircle2, color: '#0A84FF' },
    { title: 'Habit Consistency', score: productivityScore.habitScore, icon: Flame, color: '#30D158' },
    { title: 'Deep Work Flow', score: productivityScore.focusScore, icon: Timer, color: '#BF5AF2' },
    { title: 'Vitality & Health', score: productivityScore.healthScore, icon: Activity, color: '#64D2FF' },
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Analytics</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Holistic productivity metrics & AI executive digest
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant="blue" size="md" icon={<Award className="w-3.5 h-3.5" />}>
            Grade {productivityScore.grade} (Top 1% Output)
          </Badge>
        </div>
      </div>

      {/* Main Score Hero Card */}
      <GlassCard className="p-6 md:p-8 bg-gradient-to-br from-apple-blue/15 via-black/40 to-apple-purple/15 border-apple-blue/30">
        <div className="flex flex-col md:flex-row items-center gap-8 justify-between">
          <div className="flex items-center gap-6">
            <ProgressRing progress={productivityScore.overallScore} size={130} strokeWidth={11} color="#30D158">
              <div className="text-center">
                <span className="text-3xl font-extrabold text-white">{productivityScore.overallScore}</span>
                <span className="text-[10px] text-apple-gray-400 block font-bold">SCORE</span>
              </div>
            </ProgressRing>

            <div>
              <span className="text-xs font-bold text-apple-blue uppercase tracking-wider">Overall Score</span>
              <h2 className="text-2xl font-extrabold text-white mt-1">S-Tier Productivity</h2>
              <p className="text-xs text-apple-gray-300 mt-1 max-w-md leading-relaxed">
                {productivityScore.aiInsight}
              </p>
            </div>
          </div>

          {/* Quick Domain Pill Breakdown */}
          <div className="grid grid-cols-2 gap-3 w-full md:w-auto">
            {domainScores.map((d) => (
              <div key={d.title} className="p-3 rounded-2xl bg-white/5 border border-white/10 flex items-center gap-3">
                <d.icon className="w-4 h-4" style={{ color: d.color }} />
                <div>
                  <span className="text-[10px] text-apple-gray-400 uppercase font-bold">{d.title}</span>
                  <div className="text-sm font-extrabold text-white">{d.score}%</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* 7-Day Performance Trends Bar Chart */}
      <GlassCard className="p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            7-Day Output Consistency
          </h3>
          <span className="text-xs text-apple-green font-semibold flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" /> +18% vs Last Week
          </span>
        </div>

        {/* Bar Visualizer */}
        <div className="grid grid-cols-7 gap-3 pt-6 items-end h-48">
          {productivityScore.pastWeekScores.map((day) => (
            <div key={day.date} className="flex flex-col items-center gap-2 h-full justify-end">
              <span className="text-[11px] font-bold text-white">{day.score}</span>
              <div className="w-full max-w-[40px] bg-white/10 rounded-t-xl overflow-hidden h-36 flex items-end">
                <div
                  className="w-full bg-apple-blue rounded-t-xl transition-all duration-500 hover:brightness-125"
                  style={{ height: `${(day.score / 100) * 100}%` }}
                />
              </div>
              <span className="text-[10px] text-apple-gray-400 font-mono font-medium">{day.dayName}</span>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Executive Weekly Report Summary */}
      <GlassCard className="p-6 space-y-3">
        <div className="flex items-center gap-2 text-apple-blue">
          <Sparkles className="w-4 h-4" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            AI Executive Digest & Insights
          </h3>
        </div>

        <p className="text-xs sm:text-sm text-apple-gray-200 leading-relaxed">
          • <strong>Weekly Highlight</strong>: Completed high-priority Spring Boot 3 JWT Security Layer and 18 REST controllers with zero regression bugs.<br />
          • <strong>Cognitive Rhythm</strong>: Peak concentration peaked between 08:30 and 11:30 AM with an average uninterrupted flow duration of 78 minutes.<br />
          • <strong>Recommended Optimization</strong>: Increase hydration pace during afternoon deep work blocks to prevent evening fatigue.
        </p>
      </GlassCard>
    </div>
  );
};
