import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CheckCircle2,
  Circle,
  Plus,
  Calendar,
  Sparkles,
  Clock,
  Filter,
  Trash2,
  Layers,
  ArrowUpDown,
} from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { SegmentedControl } from '../../components/ui/SegmentedControl';

export const PlannerPage: React.FC = () => {
  const { tasks, addTask, toggleTask, deleteTask, projects, setAiDrawerOpen } = useAppStore();
  const [viewMode, setViewMode] = useState('today');
  const [filterPriority, setFilterPriority] = useState('ALL');
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [selectedProject, setSelectedProject] = useState<number | undefined>(undefined);
  const [selectedPriority, setSelectedPriority] = useState<'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT'>('MEDIUM');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    addTask({
      title: newTaskTitle,
      priority: selectedPriority,
      projectId: selectedProject,
      status: 'TODO',
    });
    setNewTaskTitle('');
  };

  const filteredTasks = tasks.filter((t) => {
    if (filterPriority !== 'ALL' && t.priority !== filterPriority) return false;
    if (viewMode === 'completed') return t.status === 'COMPLETED';
    if (viewMode === 'pending') return t.status !== 'COMPLETED';
    return true;
  });

  const viewOptions = [
    { id: 'all', label: 'All Tasks' },
    { id: 'pending', label: 'To Do' },
    { id: 'completed', label: 'Completed' },
  ];

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Planner</h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Dynamic priority queue & AI schedule coordinator
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="glass"
            size="sm"
            onClick={() => setAiDrawerOpen(true)}
            icon={<Sparkles className="w-4 h-4 text-apple-blue" />}
          >
            AI Schedule Optimizer
          </Button>
          <SegmentedControl
            options={viewOptions}
            value={viewMode}
            onChange={setViewMode}
          />
        </div>
      </div>

      {/* Inline Task Creator Bar */}
      <GlassCard className="p-3">
        <form onSubmit={handleCreate} className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <input
              type="text"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder="Add a new task (e.g., 'Deploy Spring Boot JWT security layer')..."
              className="w-full glass-input rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white focus:outline-none placeholder:text-apple-gray-500"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value as any)}
              className="glass-input rounded-xl px-3 py-2 text-xs text-white bg-apple-gray-900 border border-white/10"
            >
              <option value="LOW">Low</option>
              <option value="MEDIUM">Medium</option>
              <option value="HIGH">High</option>
              <option value="URGENT">Urgent</option>
            </select>

            <select
              value={selectedProject || ''}
              onChange={(e) => setSelectedProject(e.target.value ? Number(e.target.value) : undefined)}
              className="glass-input rounded-xl px-3 py-2 text-xs text-white bg-apple-gray-900 border border-white/10"
            >
              <option value="">No Project</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>

            <Button type="submit" size="sm" variant="primary" icon={<Plus className="w-4 h-4" />}>
              Add
            </Button>
          </div>
        </form>
      </GlassCard>

      {/* Task Priority Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {['ALL', 'URGENT', 'HIGH', 'MEDIUM', 'LOW'].map((p) => (
          <button
            key={p}
            onClick={() => setFilterPriority(p)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all select-none ${
              filterPriority === p
                ? 'bg-apple-blue text-white shadow-sm'
                : 'bg-white/5 text-apple-gray-400 hover:text-white hover:bg-white/10 border border-white/5'
            }`}
          >
            {p === 'ALL' ? 'All Priorities' : p}
          </button>
        ))}
      </div>

      {/* Tasks List Queue */}
      <div className="space-y-2.5">
        <AnimatePresence>
          {filteredTasks.map((t) => {
            const isCompleted = t.status === 'COMPLETED';
            return (
              <motion.div
                key={t.id}
                layout
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.2 }}
              >
                <GlassCard className="p-4 flex items-center justify-between gap-4 group">
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <button
                      onClick={() => toggleTask(t.id)}
                      className="text-apple-gray-400 hover:text-apple-blue transition-colors shrink-0"
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-apple-green" />
                      ) : (
                        <Circle className="w-5 h-5" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-sm font-semibold truncate ${
                            isCompleted ? 'line-through text-apple-gray-400' : 'text-white'
                          }`}
                        >
                          {t.title}
                        </span>
                        {t.tags && (
                          <span className="hidden sm:inline-block text-[10px] px-2 py-0.5 rounded-md bg-white/5 text-apple-gray-400 border border-white/5">
                            {t.tags}
                          </span>
                        )}
                      </div>

                      {t.description && (
                        <p className="text-xs text-apple-gray-400 mt-0.5 truncate">
                          {t.description}
                        </p>
                      )}

                      <div className="flex items-center gap-3 text-[11px] text-apple-gray-400 mt-1.5">
                        {t.projectName && (
                          <span className="flex items-center gap-1 text-apple-blue font-medium">
                            <Layers className="w-3 h-3" />
                            {t.projectName}
                          </span>
                        )}
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {t.estimatedMinutes}m est.
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 shrink-0">
                    <Badge
                      variant={
                        t.priority === 'URGENT'
                          ? 'red'
                          : t.priority === 'HIGH'
                          ? 'orange'
                          : t.priority === 'LOW'
                          ? 'gray'
                          : 'blue'
                      }
                      size="sm"
                    >
                      {t.priority}
                    </Badge>

                    <button
                      onClick={() => deleteTask(t.id)}
                      className="p-1.5 rounded-lg text-apple-gray-500 hover:text-apple-red hover:bg-apple-red/10 transition-colors opacity-0 group-hover:opacity-100"
                      title="Delete task"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </GlassCard>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {filteredTasks.length === 0 && (
          <div className="py-12 text-center text-apple-gray-400 text-xs">
            No tasks found in this view.
          </div>
        )}
      </div>
    </div>
  );
};
