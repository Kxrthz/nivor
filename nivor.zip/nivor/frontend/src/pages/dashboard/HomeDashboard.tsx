import React from 'react';
import { motion } from 'framer-motion';
import {
  Sparkles,
  Sun,
  Flame,
  CheckCircle2,
  Calendar,
  Wallet,
  Timer,
  BookOpen,
  ArrowUpRight,
  TrendingUp,
  Droplets,
  Plus,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '../../store/useAppStore';
import { useAuthStore } from '../../store/useAuthStore';
import { useFocusStore } from '../../store/useFocusStore';
import { GlassCard } from '../../components/ui/GlassCard';
import { Button } from '../../components/ui/Button';
import { ProgressRing } from '../../components/ui/ProgressRing';
import { Badge } from '../../components/ui/Badge';

export const HomeDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { tasks, toggleTask, habits, toggleHabitCheckIn, events, health, productivityScore, setQuickActionOpen, setAiDrawerOpen } = useAppStore();
  const { startFocus } = useFocusStore();

  const todayTasks = tasks.slice(0, 4);
  const completedCount = tasks.filter((t) => t.status === 'COMPLETED').length;
  const taskProgress = tasks.length > 0 ? Math.round((completedCount / tasks.length) * 100) : 0;

  const currentHour = new Date().getHours();
  const greeting =
    currentHour < 12 ? 'Good morning' : currentHour < 18 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="space-y-6">
      {/* 1. Executive Greeting & Weather Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-apple-blue font-semibold text-xs uppercase tracking-wider">
              NIVOR Executive Dashboard
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
            {greeting}, {user?.fullName?.split(' ')[0] || 'Alexander'}
          </h1>
          <p className="text-xs text-apple-gray-400 mt-1">
            Your cognitive readiness is at <span className="text-apple-green font-semibold">96% (Optimal Flow)</span>.
          </p>
        </div>

        {/* Weather & Date Pill */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2.5 px-4 py-2 rounded-2xl glass-card border border-white/10">
            <Sun className="w-5 h-5 text-apple-orange animate-pulse" />
            <div>
              <div className="text-xs font-bold text-white leading-tight">72°F Cupertino</div>
              <div className="text-[10px] text-apple-gray-400">Clear Sky • AQI 24</div>
            </div>
          </div>
          <Button
            variant="primary"
            size="sm"
            onClick={() => setQuickActionOpen(true)}
            icon={<Plus className="w-4 h-4" />}
          >
            New Item
          </Button>
        </div>
      </div>

      {/* 2. Top Metric Banners (AI Briefing + Productivity Ring) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Apple Intelligence Daily Briefing */}
        <GlassCard className="lg:col-span-2 relative overflow-hidden bg-gradient-to-br from-apple-blue/15 via-black/40 to-apple-purple/15 border-apple-blue/20">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-lg bg-apple-blue/20 text-apple-blue">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-white tracking-wide uppercase">
                Apple Intelligence Daily Briefing
              </span>
            </div>
            <Badge variant="blue" size="sm">Active Sync</Badge>
          </div>

          <p className="text-xs sm:text-sm text-apple-gray-200 mt-3 leading-relaxed">
            "You have 3 high-priority tasks and 1 architecture sync today. By starting with your 90-minute Deep Work focus block before 11:00 AM, you will reach your 14-day streak milestone."
          </p>

          <div className="mt-4 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-4 text-xs text-apple-gray-400">
              <span>🎯 Focus Target: <strong>90 mins</strong></span>
              <span>💧 Water: <strong>{health.waterMl} / 3500 ml</strong></span>
            </div>
            <button
              onClick={() => setAiDrawerOpen(true)}
              className="text-xs font-semibold text-apple-blue hover:text-white flex items-center gap-1 transition-colors"
            >
              Ask AI to schedule day <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </GlassCard>

        {/* Circular Productivity Score */}
        <GlassCard className="flex flex-col items-center justify-center text-center p-6">
          <div className="flex items-center justify-between w-full mb-3">
            <span className="text-xs font-bold text-apple-gray-400 uppercase tracking-wider">
              Productivity Score
            </span>
            <Badge variant="green" size="sm">Grade {productivityScore.grade}</Badge>
          </div>

          <ProgressRing progress={productivityScore.overallScore} size={110} strokeWidth={9} color="#30D158">
            <div className="text-center">
              <span className="text-2xl font-extrabold text-white tracking-tight">
                {productivityScore.overallScore}
              </span>
              <span className="text-[10px] text-apple-gray-400 block font-semibold uppercase">
                / 100
              </span>
            </div>
          </ProgressRing>

          <p className="text-[11px] text-apple-gray-400 mt-3">
            Tasks: <strong>{taskProgress}%</strong> • Focus: <strong>{productivityScore.focusScore}%</strong>
          </p>
        </GlassCard>
      </div>

      {/* 3. Core Operational Widgets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {/* Today's Tasks Card */}
        <GlassCard className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-apple-blue" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">Today's Tasks</h3>
            </div>
            <button
              onClick={() => navigate('/planner')}
              className="text-[11px] text-apple-blue hover:underline font-medium"
            >
              View All ({tasks.length})
            </button>
          </div>

          <div className="space-y-2 pt-1">
            {todayTasks.map((t) => {
              const isCompleted = t.status === 'COMPLETED';
              return (
                <div
                  key={t.id}
                  onClick={() => toggleTask(t.id)}
                  className={`flex items-start gap-2.5 p-2.5 rounded-xl border transition-all cursor-pointer ${
                    isCompleted
                      ? 'bg-white/[0.02] border-white/5 opacity-60'
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={isCompleted}
                    onChange={() => {}}
                    className="mt-0.5 h-4 w-4 rounded-md border-white/30 text-apple-blue focus:ring-0 cursor-pointer"
                  />
                  <div className="flex-1 min-w-0">
                    <p className={`text-xs font-medium truncate ${isCompleted ? 'line-through text-apple-gray-400' : 'text-white'}`}>
                      {t.title}
                    </p>
                    <span className="text-[10px] text-apple-gray-400">{t.projectName || 'General'}</span>
                  </div>
                  <Badge
                    variant={t.priority === 'URGENT' ? 'red' : t.priority === 'HIGH' ? 'orange' : 'blue'}
                    size="sm"
                  >
                    {t.priority}
                  </Badge>
                </div>
              );
            })}
          </div>
        </GlassCard>

        {/* Habit Streaks Card */}
        <GlassCard className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 text-apple-orange" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">Active Habits</h3>
            </div>
            <button
              onClick={() => navigate('/habits')}
              className="text-[11px] text-apple-orange hover:underline font-medium"
            >
              Matrix
            </button>
          </div>

          <div className="space-y-2 pt-1">
            {habits.map((h) => (
              <div
                key={h.id}
                onClick={() => toggleHabitCheckIn(h.id)}
                className="flex items-center justify-between p-2.5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 cursor-pointer transition-all"
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold transition-all ${
                      h.completedToday ? 'bg-apple-green text-black' : 'bg-white/10 text-white'
                    }`}
                  >
                    {h.completedToday ? '✓' : h.currentStreak}
                  </div>
                  <div>
                    <p className="text-xs font-medium text-white">{h.name}</p>
                    <p className="text-[10px] text-apple-gray-400">🔥 {h.currentStreak} day streak</p>
                  </div>
                </div>

                <span className="text-[11px] font-semibold text-apple-gray-300">
                  {h.completedToday ? 'Done' : 'Tap to log'}
                </span>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* Focus & Deep Work Card */}
        <GlassCard className="space-y-3 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Timer className="w-4 h-4 text-apple-purple" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">Focus Mode</h3>
              </div>
              <Badge variant="purple" size="sm">Pomodoro</Badge>
            </div>

            <p className="text-xs text-apple-gray-300 mt-3">
              Trigger a distraction-free Deep Work session with generative binaural audio and synchronized DND.
            </p>
          </div>

          <div className="space-y-2 pt-4">
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="primary"
                size="sm"
                onClick={() => {
                  startFocus('DEEP_WORK', 90);
                  navigate('/focus');
                }}
              >
                ⚡ 90m Flow
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  startFocus('POMODORO', 25);
                  navigate('/focus');
                }}
              >
                ⏱️ 25m Pomodoro
              </Button>
            </div>
          </div>
        </GlassCard>
      </div>

      {/* 4. Bottom Secondary Matrix (Calendar Agenda, Finance Snapshot, Journal Prompt) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Next Calendar Event */}
        <GlassCard className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-apple-blue/20 text-apple-blue flex items-center justify-center font-bold">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-apple-gray-400">Up Next</span>
              <h4 className="text-xs font-bold text-white truncate max-w-[170px]">
                {events[0]?.title || 'No upcoming events'}
              </h4>
              <p className="text-[11px] text-apple-gray-400">{events[0]?.location || 'In 1 hour'}</p>
            </div>
          </div>
          <button onClick={() => navigate('/calendar')} className="text-apple-gray-400 hover:text-white">
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </GlassCard>

        {/* Finance Snapshot */}
        <GlassCard className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-apple-green/20 text-apple-green flex items-center justify-center font-bold">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-apple-gray-400">Monthly Net Savings</span>
              <h4 className="text-sm font-extrabold text-white">+$9,050.00</h4>
              <p className="text-[10px] text-apple-green font-semibold">↑ 72.4% Savings Rate</p>
            </div>
          </div>
          <button onClick={() => navigate('/finance')} className="text-apple-gray-400 hover:text-white">
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </GlassCard>

        {/* Daily Journal Reflection Prompt */}
        <GlassCard className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-apple-orange/20 text-apple-orange flex items-center justify-center font-bold">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-apple-gray-400">Evening Reflection</span>
              <h4 className="text-xs font-bold text-white">Record 3 breakthroughs</h4>
              <p className="text-[10px] text-apple-gray-400">35-day streak active</p>
            </div>
          </div>
          <button onClick={() => navigate('/journal')} className="text-apple-gray-400 hover:text-white">
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </GlassCard>
      </div>
    </div>
  );
};
