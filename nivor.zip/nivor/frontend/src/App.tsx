import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { AppShell } from './components/layout/AppShell';
import { HomeDashboard } from './pages/dashboard/HomeDashboard';
import { PlannerPage } from './pages/planner/PlannerPage';
import { CalendarPage } from './pages/calendar/CalendarPage';
import { NotesPage } from './pages/notes/NotesPage';
import { AiAssistantPage } from './pages/ai/AiAssistantPage';
import { HabitsPage } from './pages/habits/HabitsPage';
import { GoalsPage } from './pages/goals/GoalsPage';
import { JournalPage } from './pages/journal/JournalPage';
import { WorkspacePage } from './pages/workspace/WorkspacePage';
import { FileManagerPage } from './pages/files/FileManagerPage';
import { FinancePage } from './pages/finance/FinancePage';
import { HealthPage } from './pages/health/HealthPage';
import { FocusPage } from './pages/focus/FocusPage';
import { AnalyticsPage } from './pages/analytics/AnalyticsPage';
import { NotificationsPage } from './pages/notifications/NotificationsPage';
import { SettingsPage } from './pages/settings/SettingsPage';
import { ProfilePage } from './pages/profile/ProfilePage';
import { LoginPage } from './pages/auth/LoginPage';
import { RegisterPage } from './pages/auth/RegisterPage';

export const App: React.FC = () => {
  return (
    <Routes>
      {/* Auth Routes */}
      <Route path="/auth/login" element={<LoginPage />} />
      <Route path="/auth/register" element={<RegisterPage />} />

      {/* Protected App Shell Layout */}
      <Route path="/" element={<AppShell />}>
        <Route index element={<HomeDashboard />} />
        <Route path="planner" element={<PlannerPage />} />
        <Route path="calendar" element={<CalendarPage />} />
        <Route path="notes" element={<NotesPage />} />
        <Route path="ai" element={<AiAssistantPage />} />
        <Route path="habits" element={<HabitsPage />} />
        <Route path="goals" element={<GoalsPage />} />
        <Route path="journal" element={<JournalPage />} />
        <Route path="workspace" element={<WorkspacePage />} />
        <Route path="files" element={<FileManagerPage />} />
        <Route path="finance" element={<FinancePage />} />
        <Route path="health" element={<HealthPage />} />
        <Route path="focus" element={<FocusPage />} />
        <Route path="analytics" element={<AnalyticsPage />} />
        <Route path="notifications" element={<NotificationsPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="profile" element={<ProfilePage />} />
      </Route>

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default App;
