package com.nivor.app;

import com.nivor.app.dto.AuthDTO;
import com.nivor.app.service.AuthService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest
class NivorApplicationTests {

    @Autowired(required = false)
    private AuthService authService;

    @Test
    void contextLoads() {
        // Assert context startup
    }
}
