package com.nivor.app.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public class FinanceDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TransactionRequest {
        @NotBlank(message = "Title is required")
        private String title;
        @NotNull(message = "Amount is required")
        private BigDecimal amount;
        @NotBlank(message = "Type (INCOME/EXPENSE) is required")
        private String type;
        @NotBlank(message = "Category is required")
        private String category;
        private String currency;
        private Boolean isRecurring;
        private String recurrencePeriod;
        @NotNull(message = "Date is required")
        private LocalDate transactionDate;
        private String notes;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TransactionResponse {
        private Long id;
        private String title;
        private BigDecimal amount;
        private String type;
        private String category;
        private String currency;
        private Boolean isRecurring;
        private String recurrencePeriod;
        private LocalDate transactionDate;
        private String notes;
        private LocalDateTime createdAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BudgetRequest {
        @NotBlank(message = "Category is required")
        private String category;
        @NotNull(message = "Monthly limit is required")
        private BigDecimal monthlyLimit;
        @NotBlank(message = "Month year is required (YYYY-MM)")
        private String monthYear;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class BudgetResponse {
        private Long id;
        private String category;
        private BigDecimal monthlyLimit;
        private BigDecimal spentAmount;
        private BigDecimal remainingAmount;
        private Double percentageUsed;
        private String monthYear;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class FinanceSummaryResponse {
        private BigDecimal totalIncome;
        private BigDecimal totalExpense;
        private BigDecimal netSavings;
        private BigDecimal savingsRate;
        private List<BudgetResponse> budgets;
        private List<TransactionResponse> recentTransactions;
        private Map<String, BigDecimal> categoryBreakdown;
        private List<TransactionResponse> activeSubscriptions;
    }
}
