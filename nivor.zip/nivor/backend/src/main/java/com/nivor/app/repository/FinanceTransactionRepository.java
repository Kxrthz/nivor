package com.nivor.app.repository;

import com.nivor.app.model.FinanceTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface FinanceTransactionRepository extends JpaRepository<FinanceTransaction, Long> {
    List<FinanceTransaction> findByUserIdOrderByTransactionDateDesc(Long userId);
    Optional<FinanceTransaction> findByIdAndUserId(Long id, Long userId);

    @Query("SELECT ft FROM FinanceTransaction ft WHERE ft.user.id = :userId AND ft.transactionDate BETWEEN :startDate AND :endDate ORDER BY ft.transactionDate DESC")
    List<FinanceTransaction> findTransactionsInRange(@Param("userId") Long userId, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
}
