package com.nivor.app.service;

import com.nivor.app.dto.FileDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.StoredFile;
import com.nivor.app.model.User;
import com.nivor.app.repository.StoredFileRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FileManagerService {

    private final StoredFileRepository fileRepository;
    private final UserRepository userRepository;

    public List<FileDTO.FileResponse> getUserFiles(Long userId, String folder, String search) {
        List<StoredFile> list;
        if (search != null && !search.trim().isEmpty()) {
            list = fileRepository.searchFiles(userId, search.trim());
        } else if (folder != null && !folder.trim().isEmpty() && !"ALL".equalsIgnoreCase(folder)) {
            list = fileRepository.findByUserIdAndFolder(userId, folder.trim());
        } else {
            list = fileRepository.findByUserIdOrderByCreatedAtDesc(userId);
        }
        return list.stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Transactional
    public FileDTO.FileResponse saveFileMetadata(Long userId, FileDTO.FileUploadRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        StoredFile file = StoredFile.builder()
                .user(user)
                .name(request.getName())
                .fileType(request.getFileType() != null ? request.getFileType() : "application/octet-stream")
                .fileSizeBytes(request.getFileSizeBytes() != null ? request.getFileSizeBytes() : 1024L)
                .storagePath(request.getStoragePath() != null ? request.getStoragePath() : "/uploads/" + request.getName())
                .folder(request.getFolder() != null ? request.getFolder() : "General")
                .tags(request.getTags())
                .ocrExtractedText("Extracted text preview for " + request.getName())
                .build();

        return mapToResponse(fileRepository.save(file));
    }

    @Transactional
    public void deleteFile(Long userId, Long fileId) {
        StoredFile file = fileRepository.findByIdAndUserId(fileId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("File", "id", fileId));
        fileRepository.delete(file);
    }

    public FileDTO.FileResponse mapToResponse(StoredFile f) {
        return FileDTO.FileResponse.builder()
                .id(f.getId())
                .name(f.getName())
                .fileType(f.getFileType())
                .fileSizeBytes(f.getFileSizeBytes())
                .storagePath(f.getStoragePath())
                .folder(f.getFolder())
                .tags(f.getTags())
                .ocrExtractedText(f.getOcrExtractedText())
                .createdAt(f.getCreatedAt())
                .build();
    }
}
