package com.nivor.app.service;

import com.nivor.app.dto.FocusDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.FocusSession;
import com.nivor.app.model.User;
import com.nivor.app.repository.FocusSessionRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FocusService {

    private final FocusSessionRepository sessionRepository;
    private final UserRepository userRepository;

    public FocusDTO.FocusSummaryResponse getFocusSummary(Long userId) {
        LocalDateTime startOfToday = LocalDate.now().atStartOfDay();
        LocalDateTime startOfWeek = LocalDate.now().minusDays(7).atStartOfDay();

        List<FocusSession> todaySessions = sessionRepository.findSessionsSince(userId, startOfToday);
        List<FocusSession> weekSessions = sessionRepository.findSessionsSince(userId, startOfWeek);
        List<FocusSession> allRecent = sessionRepository.findByUserIdOrderByCompletedAtDesc(userId);

        long todayMinutes = todaySessions.stream().mapToLong(FocusSession::getDurationMinutes).sum();
        long weekMinutes = weekSessions.stream().mapToLong(FocusSession::getDurationMinutes).sum();

        double avgRating = todaySessions.isEmpty() ? 5.0 :
                todaySessions.stream().mapToInt(FocusSession::getProductivityRating).average().orElse(5.0);

        Map<String, Integer> tagMap = new HashMap<>();
        for (FocusSession s : weekSessions) {
            String tag = s.getTag() != null ? s.getTag() : "General";
            tagMap.put(tag, tagMap.getOrDefault(tag, 0) + s.getDurationMinutes());
        }

        List<FocusDTO.SessionResponse> recentResponses = allRecent.stream()
                .limit(10).map(this::mapToResponse).collect(Collectors.toList());

        return FocusDTO.FocusSummaryResponse.builder()
                .todayMinutes(todayMinutes)
                .weekMinutes(weekMinutes)
                .todayCompletedSessions(todaySessions.size())
                .averageRating(Math.round(avgRating * 10.0) / 10.0)
                .recentSessions(recentResponses)
                .tagDistribution(tagMap)
                .build();
    }

    @Transactional
    public FocusDTO.SessionResponse logSession(Long userId, FocusDTO.SessionLogRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        FocusSession session = FocusSession.builder()
                .user(user)
                .sessionType(request.getSessionType() != null ? request.getSessionType() : "POMODORO")
                .durationMinutes(request.getDurationMinutes())
                .productivityRating(request.getProductivityRating() != null ? request.getProductivityRating() : 5)
                .tag(request.getTag() != null ? request.getTag() : "Deep Work")
                .soundtrack(request.getSoundtrack() != null ? request.getSoundtrack() : "Rainy Cafe")
                .build();

        return mapToResponse(sessionRepository.save(session));
    }

    public FocusDTO.SessionResponse mapToResponse(FocusSession session) {
        return FocusDTO.SessionResponse.builder()
                .id(session.getId())
                .sessionType(session.getSessionType())
                .durationMinutes(session.getDurationMinutes())
                .productivityRating(session.getProductivityRating())
                .tag(session.getTag())
                .soundtrack(session.getSoundtrack())
                .completedAt(session.getCompletedAt())
                .build();
    }
}
