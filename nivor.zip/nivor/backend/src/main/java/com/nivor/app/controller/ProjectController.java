package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.ProjectDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.ProjectService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/projects")
@RequiredArgsConstructor
@Tag(name = "Projects & Workspace", description = "Workspaces, Kanban boards, and project management")
public class ProjectController {

    private final ProjectService projectService;

    @GetMapping
    @Operation(summary = "Get all user projects")
    public ResponseEntity<ApiResponse<List<ProjectDTO.ProjectResponse>>> getProjects(
            @AuthenticationPrincipal UserPrincipal currentUser) {
        List<ProjectDTO.ProjectResponse> projects = projectService.getUserProjects(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success(projects));
    }

    @PostMapping
    @Operation(summary = "Create a new project")
    public ResponseEntity<ApiResponse<ProjectDTO.ProjectResponse>> createProject(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody ProjectDTO.ProjectRequest request) {
        ProjectDTO.ProjectResponse project = projectService.createProject(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Project created successfully", project));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a project")
    public ResponseEntity<ApiResponse<ProjectDTO.ProjectResponse>> updateProject(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id,
            @RequestBody ProjectDTO.ProjectRequest request) {
        ProjectDTO.ProjectResponse project = projectService.updateProject(currentUser.getId(), id, request);
        return ResponseEntity.ok(ApiResponse.success("Project updated successfully", project));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a project")
    public ResponseEntity<ApiResponse<Void>> deleteProject(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        projectService.deleteProject(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success("Project deleted successfully", null));
    }
}
