package com.nivor.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "user_settings")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserSettings {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    @JsonIgnore
    private User user;

    @Builder.Default
    @Column(length = 20)
    private String theme = "dark"; // dark, light, system

    @Builder.Default
    @Column(length = 30)
    private String accentColor = "system_blue"; // system_blue, purple, orange, emerald, rose, midnight

    @Builder.Default
    private Boolean soundEffectsEnabled = true;

    @Builder.Default
    private Boolean hapticFeedback = true;

    @Builder.Default
    private Boolean aiMemoryEnabled = true;

    @Builder.Default
    @Column(length = 50)
    private String aiPersonality = "Apple Intelligence Executive";

    @Builder.Default
    private Boolean emailNotifications = true;

    @Builder.Default
    private Boolean pushNotifications = true;

    @Builder.Default
    private Boolean weeklySummaryEmail = true;

    @Builder.Default
    @Column(length = 50)
    private String timeZone = "UTC";

    @Builder.Default
    @Column(length = 20)
    private String dateFormat = "MM/DD/YYYY";

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
