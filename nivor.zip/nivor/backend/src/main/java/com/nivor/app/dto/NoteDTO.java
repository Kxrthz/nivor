package com.nivor.app.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

public class NoteDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class NoteRequest {
        @NotBlank(message = "Note title is required")
        private String title;
        private String content;
        private String summary;
        private Boolean isPinned;
        private String color;
        private String tags;
        private Long folderId;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class NoteResponse {
        private Long id;
        private String title;
        private String content;
        private String summary;
        private Boolean isPinned;
        private String color;
        private String tags;
        private Long folderId;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }
}
