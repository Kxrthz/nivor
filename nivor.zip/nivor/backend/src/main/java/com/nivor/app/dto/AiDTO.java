package com.nivor.app.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

public class AiDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ChatRequest {
        private Long conversationId;
        @NotBlank(message = "Message prompt is required")
        private String prompt;
        private String contextMode; // GENERAL, STUDY_PLANNER, WORKOUT_PLANNER, SCHEDULE_OPTIMIZER
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class MessageResponse {
        private Long id;
        private String sender;
        private String content;
        private Integer tokensUsed;
        private String structuredActionJson;
        private LocalDateTime createdAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ConversationResponse {
        private Long id;
        private String title;
        private String contextMode;
        private List<MessageResponse> messages;
        private LocalDateTime updatedAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PromptSuggestion {
        private String title;
        private String prompt;
        private String icon;
        private String category;
    }
}
