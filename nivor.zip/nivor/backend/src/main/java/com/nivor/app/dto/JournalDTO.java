package com.nivor.app.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class JournalDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class JournalRequest {
        @NotBlank(message = "Journal title is required")
        private String title;
        @NotBlank(message = "Journal content is required")
        private String content;
        private Integer mood;
        private String moodLabel;
        private String gratitudeList;
        private String weather;
        private String location;
        private String voiceMemoUrl;
        @NotNull(message = "Entry date is required")
        private LocalDate entryDate;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class JournalResponse {
        private Long id;
        private String title;
        private String content;
        private Integer mood;
        private String moodLabel;
        private String gratitudeList;
        private String weather;
        private String location;
        private String voiceMemoUrl;
        private LocalDate entryDate;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }
}
