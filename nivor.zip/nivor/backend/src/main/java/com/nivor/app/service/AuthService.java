package com.nivor.app.service;

import com.nivor.app.dto.AuthDTO;
import com.nivor.app.dto.SettingsDTO;
import com.nivor.app.exception.BadRequestException;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.User;
import com.nivor.app.model.UserSettings;
import com.nivor.app.repository.UserRepository;
import com.nivor.app.repository.UserSettingsRepository;
import com.nivor.app.security.JwtTokenProvider;
import com.nivor.app.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final UserRepository userRepository;
    private final UserSettingsRepository userSettingsRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider tokenProvider;

    @Transactional
    public AuthDTO.AuthResponse login(AuthDTO.LoginRequest loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);

        String jwt = tokenProvider.generateToken(authentication);
        String refreshToken = tokenProvider.generateRefreshToken(loginRequest.getEmail());

        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        User user = userRepository.findById(userPrincipal.getId())
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userPrincipal.getId()));

        return AuthDTO.AuthResponse.builder()
                .accessToken(jwt)
                .refreshToken(refreshToken)
                .tokenType("Bearer")
                .user(mapToUserResponse(user))
                .build();
    }

    @Transactional
    public AuthDTO.AuthResponse register(AuthDTO.RegisterRequest registerRequest) {
        if (userRepository.existsByEmail(registerRequest.getEmail())) {
            throw new BadRequestException("Error: Email is already registered!");
        }

        User user = User.builder()
                .fullName(registerRequest.getFullName())
                .email(registerRequest.getEmail())
                .passwordHash(passwordEncoder.encode(registerRequest.getPassword()))
                .role("ROLE_USER")
                .provider("LOCAL")
                .isActive(true)
                .build();

        User savedUser = userRepository.save(user);

        // Create default settings
        UserSettings settings = UserSettings.builder()
                .user(savedUser)
                .theme("dark")
                .accentColor("system_blue")
                .soundEffectsEnabled(true)
                .hapticFeedback(true)
                .aiMemoryEnabled(true)
                .aiPersonality("Apple Intelligence Executive")
                .emailNotifications(true)
                .pushNotifications(true)
                .weeklySummaryEmail(true)
                .timeZone("UTC")
                .dateFormat("MM/DD/YYYY")
                .build();

        userSettingsRepository.save(settings);
        savedUser.setSettings(settings);

        String jwt = tokenProvider.generateTokenFromEmail(savedUser.getEmail(), savedUser.getId(), savedUser.getRole());
        String refreshToken = tokenProvider.generateRefreshToken(savedUser.getEmail());

        return AuthDTO.AuthResponse.builder()
                .accessToken(jwt)
                .refreshToken(refreshToken)
                .tokenType("Bearer")
                .user(mapToUserResponse(savedUser))
                .build();
    }

    public AuthDTO.AuthResponse refreshToken(String refreshToken) {
        if (!tokenProvider.validateToken(refreshToken)) {
            throw new BadRequestException("Invalid or expired refresh token");
        }

        String email = tokenProvider.getEmailFromJwt(refreshToken);
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));

        String newAccessToken = tokenProvider.generateTokenFromEmail(user.getEmail(), user.getId(), user.getRole());

        return AuthDTO.AuthResponse.builder()
                .accessToken(newAccessToken)
                .refreshToken(refreshToken)
                .tokenType("Bearer")
                .user(mapToUserResponse(user))
                .build();
    }

    public AuthDTO.UserResponse getCurrentUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));
        return mapToUserResponse(user);
    }

    public AuthDTO.UserResponse mapToUserResponse(User user) {
        UserSettings s = user.getSettings();
        SettingsDTO.SettingsResponse settingsResp = null;
        if (s != null) {
            settingsResp = SettingsDTO.SettingsResponse.builder()
                    .id(s.getId())
                    .theme(s.getTheme())
                    .accentColor(s.getAccentColor())
                    .soundEffectsEnabled(s.getSoundEffectsEnabled())
                    .hapticFeedback(s.getHapticFeedback())
                    .aiMemoryEnabled(s.getAiMemoryEnabled())
                    .aiPersonality(s.getAiPersonality())
                    .emailNotifications(s.getEmailNotifications())
                    .pushNotifications(s.getPushNotifications())
                    .weeklySummaryEmail(s.getWeeklySummaryEmail())
                    .timeZone(s.getTimeZone())
                    .dateFormat(s.getDateFormat())
                    .build();
        }

        return AuthDTO.UserResponse.builder()
                .id(user.getId())
                .email(user.getEmail())
                .fullName(user.getFullName())
                .avatarUrl(user.getAvatarUrl())
                .role(user.getRole())
                .settings(settingsResp)
                .createdAt(user.getCreatedAt())
                .build();
    }
}
