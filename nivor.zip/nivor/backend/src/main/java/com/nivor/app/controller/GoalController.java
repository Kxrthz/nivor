package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.GoalDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.GoalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/goals")
@RequiredArgsConstructor
@Tag(name = "Goals", description = "Long-term goals, milestone tracking, and AI roadmaps")
public class GoalController {

    private final GoalService goalService;

    @GetMapping
    @Operation(summary = "Get all goals for current user")
    public ResponseEntity<ApiResponse<List<GoalDTO.GoalResponse>>> getGoals(
            @AuthenticationPrincipal UserPrincipal currentUser) {
        List<GoalDTO.GoalResponse> goals = goalService.getUserGoals(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success(goals));
    }

    @PostMapping
    @Operation(summary = "Create a new goal")
    public ResponseEntity<ApiResponse<GoalDTO.GoalResponse>> createGoal(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody GoalDTO.GoalRequest request) {
        GoalDTO.GoalResponse goal = goalService.createGoal(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Goal created successfully", goal));
    }

    @PostMapping("/{goalId}/milestones")
    @Operation(summary = "Add milestone to goal")
    public ResponseEntity<ApiResponse<GoalDTO.MilestoneResponse>> addMilestone(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long goalId,
            @Valid @RequestBody GoalDTO.MilestoneRequest request) {
        GoalDTO.MilestoneResponse ms = goalService.addMilestone(currentUser.getId(), goalId, request);
        return ResponseEntity.ok(ApiResponse.success("Milestone added", ms));
    }

    @PatchMapping("/milestones/{milestoneId}/toggle")
    @Operation(summary = "Toggle milestone completed status")
    public ResponseEntity<ApiResponse<GoalDTO.MilestoneResponse>> toggleMilestone(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long milestoneId) {
        GoalDTO.MilestoneResponse ms = goalService.toggleMilestone(currentUser.getId(), milestoneId);
        return ResponseEntity.ok(ApiResponse.success("Milestone updated", ms));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a goal")
    public ResponseEntity<ApiResponse<Void>> deleteGoal(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        goalService.deleteGoal(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success("Goal deleted successfully", null));
    }
}
