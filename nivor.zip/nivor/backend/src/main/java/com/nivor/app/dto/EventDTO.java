package com.nivor.app.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

public class EventDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class EventRequest {
        @NotBlank(message = "Event title is required")
        private String title;
        private String description;
        private String location;
        @NotNull(message = "Start time is required")
        private LocalDateTime startTime;
        @NotNull(message = "End time is required")
        private LocalDateTime endTime;
        private Boolean isAllDay;
        private String color;
        private String category;
        private String syncSource;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class EventResponse {
        private Long id;
        private String title;
        private String description;
        private String location;
        private LocalDateTime startTime;
        private LocalDateTime endTime;
        private Boolean isAllDay;
        private String color;
        private String category;
        private String syncSource;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }
}
