package com.nivor.app.repository;

import com.nivor.app.model.HealthMetric;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface HealthMetricRepository extends JpaRepository<HealthMetric, Long> {
    List<HealthMetric> findByUserIdAndLoggedAt(Long userId, LocalDate loggedAt);

    @Query("SELECT h FROM HealthMetric h WHERE h.user.id = :userId AND h.loggedAt BETWEEN :start AND :end ORDER BY h.loggedAt ASC")
    List<HealthMetric> findMetricsInRange(@Param("userId") Long userId, @Param("start") LocalDate start, @Param("end") LocalDate end);

    @Query("SELECT h FROM HealthMetric h WHERE h.user.id = :userId AND h.type = :type ORDER BY h.loggedAt DESC")
    List<HealthMetric> findRecentByType(@Param("userId") Long userId, @Param("type") String type);
}
