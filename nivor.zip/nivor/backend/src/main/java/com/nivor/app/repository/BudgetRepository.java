package com.nivor.app.repository;

import com.nivor.app.model.Budget;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BudgetRepository extends JpaRepository<Budget, Long> {
    List<Budget> findByUserIdAndMonthYear(Long userId, String monthYear);
    Optional<Budget> findByUserIdAndCategoryAndMonthYear(Long userId, String category, String monthYear);
    Optional<Budget> findByIdAndUserId(Long id, Long userId);
}
