package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.TaskDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.TaskService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/tasks")
@RequiredArgsConstructor
@Tag(name = "Tasks", description = "Task management, priority reordering, and status transitions")
public class TaskController {

    private final TaskService taskService;

    @GetMapping
    @Operation(summary = "Get all tasks for current user")
    public ResponseEntity<ApiResponse<List<TaskDTO.TaskResponse>>> getTasks(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) String status) {
        List<TaskDTO.TaskResponse> tasks = taskService.getUserTasks(currentUser.getId(), status);
        return ResponseEntity.ok(ApiResponse.success(tasks));
    }

    @PostMapping
    @Operation(summary = "Create a new task")
    public ResponseEntity<ApiResponse<TaskDTO.TaskResponse>> createTask(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody TaskDTO.TaskRequest request) {
        TaskDTO.TaskResponse task = taskService.createTask(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Task created successfully", task));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an existing task")
    public ResponseEntity<ApiResponse<TaskDTO.TaskResponse>> updateTask(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id,
            @RequestBody TaskDTO.TaskRequest request) {
        TaskDTO.TaskResponse task = taskService.updateTask(currentUser.getId(), id, request);
        return ResponseEntity.ok(ApiResponse.success("Task updated successfully", task));
    }

    @PatchMapping("/{id}/toggle")
    @Operation(summary = "Toggle task completion status")
    public ResponseEntity<ApiResponse<TaskDTO.TaskResponse>> toggleTask(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        TaskDTO.TaskResponse task = taskService.toggleTaskStatus(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success("Task status updated", task));
    }

    @PostMapping("/batch-reorder")
    @Operation(summary = "Batch reorder tasks")
    public ResponseEntity<ApiResponse<Void>> batchReorder(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestBody TaskDTO.BatchReorderRequest request) {
        taskService.batchReorder(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Tasks reordered successfully", null));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a task")
    public ResponseEntity<ApiResponse<Void>> deleteTask(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        taskService.deleteTask(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success("Task deleted successfully", null));
    }
}
