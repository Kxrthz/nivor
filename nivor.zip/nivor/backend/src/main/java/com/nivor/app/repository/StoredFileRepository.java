package com.nivor.app.repository;

import com.nivor.app.model.StoredFile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StoredFileRepository extends JpaRepository<StoredFile, Long> {
    List<StoredFile> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<StoredFile> findByUserIdAndFolder(Long userId, String folder);
    Optional<StoredFile> findByIdAndUserId(Long id, Long userId);

    @Query("SELECT f FROM StoredFile f WHERE f.user.id = :userId AND (LOWER(f.name) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(f.tags) LIKE LOWER(CONCAT('%', :query, '%')))")
    List<StoredFile> searchFiles(@Param("userId") Long userId, @Param("query") String query);
}
