package com.nivor.app.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public class HabitDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class HabitRequest {
        @NotBlank(message = "Habit name is required")
        private String name;
        private String description;
        private String frequency;
        private Integer targetCountPerDay;
        private String unit;
        private String color;
        private String icon;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class HabitResponse {
        private Long id;
        private String name;
        private String description;
        private String frequency;
        private Integer targetCountPerDay;
        private String unit;
        private String color;
        private String icon;
        private Integer currentStreak;
        private Integer longestStreak;
        private Boolean completedToday;
        private Integer todayCount;
        private Map<String, Boolean> pastWeekStatus; // Date string -> isCompleted
        private LocalDateTime createdAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CheckInRequest {
        private LocalDate date;
        private Integer count;
        private Boolean completed;
    }
}
