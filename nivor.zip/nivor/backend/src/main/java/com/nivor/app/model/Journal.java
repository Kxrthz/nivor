package com.nivor.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "journals", indexes = {
        @Index(name = "idx_journal_user_date", columnList = "user_id, entry_date")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Journal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore
    private User user;

    @NotBlank
    @Column(nullable = false, length = 200)
    private String title;

    @NotBlank
    @Column(nullable = false, columnDefinition = "LONGTEXT")
    private String content;

    @Builder.Default
    private Integer mood = 5; // 1-5 scale

    @Builder.Default
    @Column(length = 30)
    private String moodLabel = "Happy";

    @Column(columnDefinition = "TEXT")
    private String gratitudeList; // JSON string or comma separated

    @Builder.Default
    @Column(length = 50)
    private String weather = "Sunny 72°F";

    @Column(length = 100)
    private String location;

    @Column(length = 500)
    private String voiceMemoUrl;

    @NotNull
    @Column(name = "entry_date", nullable = false)
    private LocalDate entryDate;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;
}
