package com.nivor.app.service;

import com.nivor.app.dto.FinanceDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.Budget;
import com.nivor.app.model.FinanceTransaction;
import com.nivor.app.model.User;
import com.nivor.app.repository.BudgetRepository;
import com.nivor.app.repository.FinanceTransactionRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FinanceService {

    private final FinanceTransactionRepository transactionRepository;
    private final BudgetRepository budgetRepository;
    private final UserRepository userRepository;

    public List<FinanceDTO.TransactionResponse> getUserTransactions(Long userId) {
        return transactionRepository.findByUserIdOrderByTransactionDateDesc(userId)
                .stream().map(this::mapToTransactionResponse).collect(Collectors.toList());
    }

    public List<FinanceDTO.BudgetResponse> getUserBudgets(Long userId, String monthYear) {
        String my = monthYear != null ? monthYear : LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM"));
        return budgetRepository.findByUserIdAndMonthYear(userId, my)
                .stream().map(this::mapToBudgetResponse).collect(Collectors.toList());
    }

    public FinanceDTO.FinanceSummaryResponse getFinanceSummary(Long userId) {
        LocalDate now = LocalDate.now();
        LocalDate startOfMonth = now.withDayOfMonth(1);
        LocalDate endOfMonth = now.withDayOfMonth(now.lengthOfMonth());
        String currentMonthYear = now.format(DateTimeFormatter.ofPattern("yyyy-MM"));

        List<FinanceTransaction> monthTransactions = transactionRepository.findTransactionsInRange(userId, startOfMonth, endOfMonth);

        BigDecimal totalIncome = BigDecimal.ZERO;
        BigDecimal totalExpense = BigDecimal.ZERO;
        Map<String, BigDecimal> categoryBreakdown = new HashMap<>();

        for (FinanceTransaction tx : monthTransactions) {
            if ("INCOME".equalsIgnoreCase(tx.getType())) {
                totalIncome = totalIncome.add(tx.getAmount());
            } else {
                totalExpense = totalExpense.add(tx.getAmount());
                categoryBreakdown.put(tx.getCategory(),
                        categoryBreakdown.getOrDefault(tx.getCategory(), BigDecimal.ZERO).add(tx.getAmount()));
            }
        }

        BigDecimal netSavings = totalIncome.subtract(totalExpense);
        BigDecimal savingsRate = BigDecimal.ZERO;
        if (totalIncome.compareTo(BigDecimal.ZERO) > 0) {
            savingsRate = netSavings.divide(totalIncome, 4, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100));
        }

        List<FinanceDTO.BudgetResponse> budgets = getUserBudgets(userId, currentMonthYear);
        List<FinanceDTO.TransactionResponse> recentTransactions = transactionRepository.findByUserIdOrderByTransactionDateDesc(userId)
                .stream().limit(10).map(this::mapToTransactionResponse).collect(Collectors.toList());

        List<FinanceDTO.TransactionResponse> subscriptions = transactionRepository.findByUserIdOrderByTransactionDateDesc(userId)
                .stream().filter(t -> Boolean.TRUE.equals(t.getIsRecurring()))
                .map(this::mapToTransactionResponse).collect(Collectors.toList());

        return FinanceDTO.FinanceSummaryResponse.builder()
                .totalIncome(totalIncome)
                .totalExpense(totalExpense)
                .netSavings(netSavings)
                .savingsRate(savingsRate)
                .budgets(budgets)
                .recentTransactions(recentTransactions)
                .categoryBreakdown(categoryBreakdown)
                .activeSubscriptions(subscriptions)
                .build();
    }

    @Transactional
    public FinanceDTO.TransactionResponse createTransaction(Long userId, FinanceDTO.TransactionRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        FinanceTransaction tx = FinanceTransaction.builder()
                .user(user)
                .title(request.getTitle())
                .amount(request.getAmount())
                .type(request.getType().toUpperCase())
                .category(request.getCategory())
                .currency(request.getCurrency() != null ? request.getCurrency() : "USD")
                .isRecurring(request.getIsRecurring() != null ? request.getIsRecurring() : false)
                .recurrencePeriod(request.getRecurrencePeriod())
                .transactionDate(request.getTransactionDate())
                .notes(request.getNotes())
                .build();

        FinanceTransaction saved = transactionRepository.save(tx);

        // Update corresponding budget spent amount if expense
        if ("EXPENSE".equalsIgnoreCase(saved.getType())) {
            String monthYear = saved.getTransactionDate().format(DateTimeFormatter.ofPattern("yyyy-MM"));
            budgetRepository.findByUserIdAndCategoryAndMonthYear(userId, saved.getCategory(), monthYear)
                    .ifPresent(budget -> {
                        budget.setSpentAmount(budget.getSpentAmount().add(saved.getAmount()));
                        budgetRepository.save(budget);
                    });
        }

        return mapToTransactionResponse(saved);
    }

    @Transactional
    public FinanceDTO.BudgetResponse createOrUpdateBudget(Long userId, FinanceDTO.BudgetRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        Budget budget = budgetRepository.findByUserIdAndCategoryAndMonthYear(userId, request.getCategory(), request.getMonthYear())
                .orElse(Budget.builder()
                        .user(user)
                        .category(request.getCategory())
                        .monthlyLimit(request.getMonthlyLimit())
                        .spentAmount(BigDecimal.ZERO)
                        .monthYear(request.getMonthYear())
                        .build());

        budget.setMonthlyLimit(request.getMonthlyLimit());
        return mapToBudgetResponse(budgetRepository.save(budget));
    }

    @Transactional
    public void deleteTransaction(Long userId, Long transactionId) {
        FinanceTransaction tx = transactionRepository.findByIdAndUserId(transactionId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction", "id", transactionId));
        transactionRepository.delete(tx);
    }

    public FinanceDTO.TransactionResponse mapToTransactionResponse(FinanceTransaction tx) {
        return FinanceDTO.TransactionResponse.builder()
                .id(tx.getId())
                .title(tx.getTitle())
                .amount(tx.getAmount())
                .type(tx.getType())
                .category(tx.getCategory())
                .currency(tx.getCurrency())
                .isRecurring(tx.getIsRecurring())
                .recurrencePeriod(tx.getRecurrencePeriod())
                .transactionDate(tx.getTransactionDate())
                .notes(tx.getNotes())
                .createdAt(tx.getCreatedAt())
                .build();
    }

    public FinanceDTO.BudgetResponse mapToBudgetResponse(Budget budget) {
        BigDecimal spent = budget.getSpentAmount() != null ? budget.getSpentAmount() : BigDecimal.ZERO;
        BigDecimal remaining = budget.getMonthlyLimit().subtract(spent);
        double pct = 0;
        if (budget.getMonthlyLimit().compareTo(BigDecimal.ZERO) > 0) {
            pct = spent.divide(budget.getMonthlyLimit(), 4, RoundingMode.HALF_UP).doubleValue() * 100;
        }

        return FinanceDTO.BudgetResponse.builder()
                .id(budget.getId())
                .category(budget.getCategory())
                .monthlyLimit(budget.getMonthlyLimit())
                .spentAmount(spent)
                .remainingAmount(remaining)
                .percentageUsed(Math.round(pct * 10.0) / 10.0)
                .monthYear(budget.getMonthYear())
                .build();
    }
}
