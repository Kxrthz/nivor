package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.FileDTO;
import com.nivor.app.dto.NoteDTO;
import com.nivor.app.dto.TaskDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.FileManagerService;
import com.nivor.app.service.NoteService;
import com.nivor.app.service.TaskService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/search")
@RequiredArgsConstructor
@Tag(name = "Global Search", description = "Instant Spotlight / Cmd+K search across tasks, notes, files, and projects")
public class SearchController {

    private final TaskService taskService;
    private final NoteService noteService;
    private final FileManagerService fileManagerService;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class GlobalSearchResult {
        private List<TaskDTO.TaskResponse> tasks;
        private List<NoteDTO.NoteResponse> notes;
        private List<FileDTO.FileResponse> files;
    }

    @GetMapping
    @Operation(summary = "Search across tasks, notes, and files simultaneously")
    public ResponseEntity<ApiResponse<GlobalSearchResult>> globalSearch(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam String q) {

        String query = q.trim().toLowerCase();
        List<TaskDTO.TaskResponse> tasks = taskService.getUserTasks(currentUser.getId(), null).stream()
                .filter(t -> t.getTitle().toLowerCase().contains(query) || (t.getDescription() != null && t.getDescription().toLowerCase().contains(query)))
                .limit(10).collect(Collectors.toList());

        List<NoteDTO.NoteResponse> notes = noteService.getUserNotes(currentUser.getId(), query).stream()
                .limit(10).collect(Collectors.toList());

        List<FileDTO.FileResponse> files = fileManagerService.getUserFiles(currentUser.getId(), null, query).stream()
                .limit(10).collect(Collectors.toList());

        GlobalSearchResult result = GlobalSearchResult.builder()
                .tasks(tasks)
                .notes(notes)
                .files(files)
                .build();

        return ResponseEntity.ok(ApiResponse.success(result));
    }
}
