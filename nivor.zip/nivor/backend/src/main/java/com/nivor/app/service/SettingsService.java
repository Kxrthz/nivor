package com.nivor.app.service;

import com.nivor.app.dto.SettingsDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.User;
import com.nivor.app.model.UserSettings;
import com.nivor.app.repository.UserRepository;
import com.nivor.app.repository.UserSettingsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class SettingsService {

    private final UserSettingsRepository settingsRepository;
    private final UserRepository userRepository;

    public SettingsDTO.SettingsResponse getUserSettings(Long userId) {
        UserSettings s = settingsRepository.findByUserId(userId)
                .orElseGet(() -> createDefaultSettings(userId));
        return mapToResponse(s);
    }

    @Transactional
    public SettingsDTO.SettingsResponse updateSettings(Long userId, SettingsDTO.SettingsUpdateRequest request) {
        UserSettings s = settingsRepository.findByUserId(userId)
                .orElseGet(() -> createDefaultSettings(userId));

        if (request.getTheme() != null) s.setTheme(request.getTheme());
        if (request.getAccentColor() != null) s.setAccentColor(request.getAccentColor());
        if (request.getSoundEffectsEnabled() != null) s.setSoundEffectsEnabled(request.getSoundEffectsEnabled());
        if (request.getHapticFeedback() != null) s.setHapticFeedback(request.getHapticFeedback());
        if (request.getAiMemoryEnabled() != null) s.setAiMemoryEnabled(request.getAiMemoryEnabled());
        if (request.getAiPersonality() != null) s.setAiPersonality(request.getAiPersonality());
        if (request.getEmailNotifications() != null) s.setEmailNotifications(request.getEmailNotifications());
        if (request.getPushNotifications() != null) s.setPushNotifications(request.getPushNotifications());
        if (request.getWeeklySummaryEmail() != null) s.setWeeklySummaryEmail(request.getWeeklySummaryEmail());
        if (request.getTimeZone() != null) s.setTimeZone(request.getTimeZone());
        if (request.getDateFormat() != null) s.setDateFormat(request.getDateFormat());

        return mapToResponse(settingsRepository.save(s));
    }

    private UserSettings createDefaultSettings(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        UserSettings settings = UserSettings.builder()
                .user(user)
                .theme("dark")
                .accentColor("system_blue")
                .soundEffectsEnabled(true)
                .hapticFeedback(true)
                .aiMemoryEnabled(true)
                .aiPersonality("Apple Intelligence Executive")
                .emailNotifications(true)
                .pushNotifications(true)
                .weeklySummaryEmail(true)
                .timeZone("UTC")
                .dateFormat("MM/DD/YYYY")
                .build();

        return settingsRepository.save(settings);
    }

    public SettingsDTO.SettingsResponse mapToResponse(UserSettings s) {
        return SettingsDTO.SettingsResponse.builder()
                .id(s.getId())
                .theme(s.getTheme())
                .accentColor(s.getAccentColor())
                .soundEffectsEnabled(s.getSoundEffectsEnabled())
                .hapticFeedback(s.getHapticFeedback())
                .aiMemoryEnabled(s.getAiMemoryEnabled())
                .aiPersonality(s.getAiPersonality())
                .emailNotifications(s.getEmailNotifications())
                .pushNotifications(s.getPushNotifications())
                .weeklySummaryEmail(s.getWeeklySummaryEmail())
                .timeZone(s.getTimeZone())
                .dateFormat(s.getDateFormat())
                .build();
    }
}
