package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.HabitDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.HabitService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/habits")
@RequiredArgsConstructor
@Tag(name = "Habits", description = "Habit tracking, check-ins, streaks, and weekly matrix")
public class HabitController {

    private final HabitService habitService;

    @GetMapping
    @Operation(summary = "Get all habits with past week completion matrix")
    public ResponseEntity<ApiResponse<List<HabitDTO.HabitResponse>>> getHabits(
            @AuthenticationPrincipal UserPrincipal currentUser) {
        List<HabitDTO.HabitResponse> habits = habitService.getUserHabits(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success(habits));
    }

    @PostMapping
    @Operation(summary = "Create a new habit")
    public ResponseEntity<ApiResponse<HabitDTO.HabitResponse>> createHabit(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody HabitDTO.HabitRequest request) {
        HabitDTO.HabitResponse habit = habitService.createHabit(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Habit created successfully", habit));
    }

    @PostMapping("/{id}/check-in")
    @Operation(summary = "Check-in or log count for a habit")
    public ResponseEntity<ApiResponse<HabitDTO.HabitResponse>> checkIn(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id,
            @RequestBody HabitDTO.CheckInRequest request) {
        HabitDTO.HabitResponse habit = habitService.checkInHabit(currentUser.getId(), id, request);
        return ResponseEntity.ok(ApiResponse.success("Habit logged successfully", habit));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a habit")
    public ResponseEntity<ApiResponse<Void>> deleteHabit(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        habitService.deleteHabit(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success("Habit deleted successfully", null));
    }
}
