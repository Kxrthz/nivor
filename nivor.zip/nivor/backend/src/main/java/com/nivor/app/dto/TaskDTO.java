package com.nivor.app.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

public class TaskDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TaskRequest {
        @NotBlank(message = "Task title is required")
        private String title;
        private String description;
        private Long projectId;
        private String status;
        private String priority;
        private LocalDateTime dueDate;
        private LocalDateTime reminderAt;
        private String recurrenceRule;
        private String tags;
        private Integer estimatedMinutes;
        private Integer orderIndex;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TaskResponse {
        private Long id;
        private String title;
        private String description;
        private Long projectId;
        private String projectName;
        private String status;
        private String priority;
        private LocalDateTime dueDate;
        private LocalDateTime reminderAt;
        private String recurrenceRule;
        private String tags;
        private Integer estimatedMinutes;
        private Integer orderIndex;
        private LocalDateTime completedAt;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BatchReorderRequest {
        private List<TaskOrderItem> items;

        @Data
        @NoArgsConstructor
        @AllArgsConstructor
        public static class TaskOrderItem {
            private Long id;
            private Integer orderIndex;
            private String status;
        }
    }
}
