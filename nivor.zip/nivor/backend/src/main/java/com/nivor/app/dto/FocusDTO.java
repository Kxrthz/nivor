package com.nivor.app.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public class FocusDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SessionLogRequest {
        private String sessionType; // POMODORO, DEEP_WORK, SHORT_BREAK, LONG_BREAK
        @NotNull(message = "Duration in minutes is required")
        private Integer durationMinutes;
        private Integer productivityRating;
        private String tag;
        private String soundtrack;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SessionResponse {
        private Long id;
        private String sessionType;
        private Integer durationMinutes;
        private Integer productivityRating;
        private String tag;
        private String soundtrack;
        private LocalDateTime completedAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class FocusSummaryResponse {
        private long todayMinutes;
        private long weekMinutes;
        private int todayCompletedSessions;
        private double averageRating;
        private List<SessionResponse> recentSessions;
        private Map<String, Integer> tagDistribution;
    }
}
