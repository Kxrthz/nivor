package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.SettingsDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.SettingsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/settings")
@RequiredArgsConstructor
@Tag(name = "Settings & Customization", description = "Themes, dynamic accent colors, AI personality, and preferences")
public class SettingsController {

    private final SettingsService settingsService;

    @GetMapping
    @Operation(summary = "Get settings for current user")
    public ResponseEntity<ApiResponse<SettingsDTO.SettingsResponse>> getSettings(
            @AuthenticationPrincipal UserPrincipal currentUser) {
        SettingsDTO.SettingsResponse settings = settingsService.getUserSettings(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success(settings));
    }

    @PutMapping
    @Operation(summary = "Update user settings and theme/accent colors")
    public ResponseEntity<ApiResponse<SettingsDTO.SettingsResponse>> updateSettings(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestBody SettingsDTO.SettingsUpdateRequest request) {
        SettingsDTO.SettingsResponse settings = settingsService.updateSettings(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Settings updated successfully", settings));
    }
}
