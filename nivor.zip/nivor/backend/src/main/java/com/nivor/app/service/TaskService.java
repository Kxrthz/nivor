package com.nivor.app.service;

import com.nivor.app.dto.TaskDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.Project;
import com.nivor.app.model.Task;
import com.nivor.app.model.User;
import com.nivor.app.repository.ProjectRepository;
import com.nivor.app.repository.TaskRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TaskService {

    private final TaskRepository taskRepository;
    private final UserRepository userRepository;
    private final ProjectRepository projectRepository;

    public List<TaskDTO.TaskResponse> getUserTasks(Long userId, String status) {
        List<Task> tasks;
        if (status != null && !status.isEmpty()) {
            tasks = taskRepository.findByUserIdAndStatus(userId, status);
        } else {
            tasks = taskRepository.findByUserIdOrderByOrderIndexAscCreatedAtDesc(userId);
        }
        return tasks.stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Transactional
    public TaskDTO.TaskResponse createTask(Long userId, TaskDTO.TaskRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        Project project = null;
        if (request.getProjectId() != null) {
            project = projectRepository.findByIdAndUserId(request.getProjectId(), userId).orElse(null);
        }

        Task task = Task.builder()
                .user(user)
                .project(project)
                .title(request.getTitle())
                .description(request.getDescription())
                .status(request.getStatus() != null ? request.getStatus() : "TODO")
                .priority(request.getPriority() != null ? request.getPriority() : "MEDIUM")
                .dueDate(request.getDueDate())
                .reminderAt(request.getReminderAt())
                .recurrenceRule(request.getRecurrenceRule())
                .tags(request.getTags())
                .estimatedMinutes(request.getEstimatedMinutes() != null ? request.getEstimatedMinutes() : 30)
                .orderIndex(request.getOrderIndex() != null ? request.getOrderIndex() : 0)
                .build();

        return mapToResponse(taskRepository.save(task));
    }

    @Transactional
    public TaskDTO.TaskResponse updateTask(Long userId, Long taskId, TaskDTO.TaskRequest request) {
        Task task = taskRepository.findByIdAndUserId(taskId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Task", "id", taskId));

        if (request.getTitle() != null) task.setTitle(request.getTitle());
        if (request.getDescription() != null) task.setDescription(request.getDescription());
        if (request.getStatus() != null) {
            task.setStatus(request.getStatus());
            if ("COMPLETED".equalsIgnoreCase(request.getStatus())) {
                task.setCompletedAt(LocalDateTime.now());
            } else {
                task.setCompletedAt(null);
            }
        }
        if (request.getPriority() != null) task.setPriority(request.getPriority());
        if (request.getDueDate() != null) task.setDueDate(request.getDueDate());
        if (request.getReminderAt() != null) task.setReminderAt(request.getReminderAt());
        if (request.getRecurrenceRule() != null) task.setRecurrenceRule(request.getRecurrenceRule());
        if (request.getTags() != null) task.setTags(request.getTags());
        if (request.getEstimatedMinutes() != null) task.setEstimatedMinutes(request.getEstimatedMinutes());
        if (request.getOrderIndex() != null) task.setOrderIndex(request.getOrderIndex());

        if (request.getProjectId() != null) {
            Project project = projectRepository.findByIdAndUserId(request.getProjectId(), userId).orElse(null);
            task.setProject(project);
        }

        return mapToResponse(taskRepository.save(task));
    }

    @Transactional
    public TaskDTO.TaskResponse toggleTaskStatus(Long userId, Long taskId) {
        Task task = taskRepository.findByIdAndUserId(taskId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Task", "id", taskId));

        if ("COMPLETED".equalsIgnoreCase(task.getStatus())) {
            task.setStatus("TODO");
            task.setCompletedAt(null);
        } else {
            task.setStatus("COMPLETED");
            task.setCompletedAt(LocalDateTime.now());
        }

        return mapToResponse(taskRepository.save(task));
    }

    @Transactional
    public void batchReorder(Long userId, TaskDTO.BatchReorderRequest request) {
        for (TaskDTO.BatchReorderRequest.TaskOrderItem item : request.getItems()) {
            taskRepository.findByIdAndUserId(item.getId(), userId).ifPresent(task -> {
                if (item.getOrderIndex() != null) task.setOrderIndex(item.getOrderIndex());
                if (item.getStatus() != null) task.setStatus(item.getStatus());
                taskRepository.save(task);
            });
        }
    }

    @Transactional
    public void deleteTask(Long userId, Long taskId) {
        Task task = taskRepository.findByIdAndUserId(taskId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Task", "id", taskId));
        taskRepository.delete(task);
    }

    public TaskDTO.TaskResponse mapToResponse(Task task) {
        return TaskDTO.TaskResponse.builder()
                .id(task.getId())
                .title(task.getTitle())
                .description(task.getDescription())
                .projectId(task.getProject() != null ? task.getProject().getId() : null)
                .projectName(task.getProject() != null ? task.getProject().getName() : null)
                .status(task.getStatus())
                .priority(task.getPriority())
                .dueDate(task.getDueDate())
                .reminderAt(task.getReminderAt())
                .recurrenceRule(task.getRecurrenceRule())
                .tags(task.getTags())
                .estimatedMinutes(task.getEstimatedMinutes())
                .orderIndex(task.getOrderIndex())
                .completedAt(task.getCompletedAt())
                .createdAt(task.getCreatedAt())
                .updatedAt(task.getUpdatedAt())
                .build();
    }
}
