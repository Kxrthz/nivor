package com.nivor.app.service;

import com.nivor.app.dto.EventDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.Event;
import com.nivor.app.model.User;
import com.nivor.app.repository.EventRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EventService {

    private final EventRepository eventRepository;
    private final UserRepository userRepository;

    public List<EventDTO.EventResponse> getUserEvents(Long userId) {
        return eventRepository.findByUserIdOrderByStartTimeAsc(userId)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    public List<EventDTO.EventResponse> getEventsInRange(Long userId, LocalDateTime start, LocalDateTime end) {
        return eventRepository.findEventsInRange(userId, start, end)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Transactional
    public EventDTO.EventResponse createEvent(Long userId, EventDTO.EventRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        Event event = Event.builder()
                .user(user)
                .title(request.getTitle())
                .description(request.getDescription())
                .location(request.getLocation())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .isAllDay(request.getIsAllDay() != null ? request.getIsAllDay() : false)
                .color(request.getColor() != null ? request.getColor() : "#5E5CE6")
                .category(request.getCategory() != null ? request.getCategory() : "Work")
                .syncSource(request.getSyncSource() != null ? request.getSyncSource() : "NIVOR")
                .build();

        return mapToResponse(eventRepository.save(event));
    }

    @Transactional
    public EventDTO.EventResponse updateEvent(Long userId, Long eventId, EventDTO.EventRequest request) {
        Event event = eventRepository.findByIdAndUserId(eventId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", eventId));

        if (request.getTitle() != null) event.setTitle(request.getTitle());
        if (request.getDescription() != null) event.setDescription(request.getDescription());
        if (request.getLocation() != null) event.setLocation(request.getLocation());
        if (request.getStartTime() != null) event.setStartTime(request.getStartTime());
        if (request.getEndTime() != null) event.setEndTime(request.getEndTime());
        if (request.getIsAllDay() != null) event.setIsAllDay(request.getIsAllDay());
        if (request.getColor() != null) event.setColor(request.getColor());
        if (request.getCategory() != null) event.setCategory(request.getCategory());

        return mapToResponse(eventRepository.save(event));
    }

    @Transactional
    public void deleteEvent(Long userId, Long eventId) {
        Event event = eventRepository.findByIdAndUserId(eventId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Event", "id", eventId));
        eventRepository.delete(event);
    }

    public EventDTO.EventResponse mapToResponse(Event event) {
        return EventDTO.EventResponse.builder()
                .id(event.getId())
                .title(event.getTitle())
                .description(event.getDescription())
                .location(event.getLocation())
                .startTime(event.getStartTime())
                .endTime(event.getEndTime())
                .isAllDay(event.getIsAllDay())
                .color(event.getColor())
                .category(event.getCategory())
                .syncSource(event.getSyncSource())
                .createdAt(event.getCreatedAt())
                .updatedAt(event.getUpdatedAt())
                .build();
    }
}
