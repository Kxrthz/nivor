package com.nivor.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "focus_sessions", indexes = {
        @Index(name = "idx_focus_user", columnList = "user_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FocusSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore
    private User user;

    @Builder.Default
    @Column(length = 30)
    private String sessionType = "POMODORO"; // POMODORO, DEEP_WORK, SHORT_BREAK, LONG_BREAK

    @NotNull
    @Column(nullable = false)
    private Integer durationMinutes;

    @Builder.Default
    private Integer productivityRating = 5;

    @Builder.Default
    @Column(length = 50)
    private String tag = "General";

    @Builder.Default
    @Column(length = 50)
    private String soundtrack = "Rainy Cafe";

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime completedAt;
}
