package com.nivor.app.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class GoalDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class GoalRequest {
        @NotBlank(message = "Goal title is required")
        private String title;
        private String description;
        private String category;
        private LocalDate targetDate;
        private Integer progressPercentage;
        private String status;
        private String color;
        private String aiRoadmap;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class GoalResponse {
        private Long id;
        private String title;
        private String description;
        private String category;
        private LocalDate targetDate;
        private Integer progressPercentage;
        private String status;
        private String color;
        private String aiRoadmap;
        private List<MilestoneResponse> milestones;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class MilestoneRequest {
        @NotBlank(message = "Milestone title is required")
        private String title;
        private LocalDate dueDate;
        private Boolean isCompleted;
        private Integer orderIndex;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class MilestoneResponse {
        private Long id;
        private Long goalId;
        private String title;
        private LocalDate dueDate;
        private Boolean isCompleted;
        private Integer orderIndex;
    }
}
