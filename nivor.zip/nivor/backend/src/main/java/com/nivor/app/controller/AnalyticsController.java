package com.nivor.app.controller;

import com.nivor.app.dto.AnalyticsDTO;
import com.nivor.app.dto.ApiResponse;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.AnalyticsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/analytics")
@RequiredArgsConstructor
@Tag(name = "Analytics & Productivity Score", description = "Unified Productivity Score, historical trends, and weekly digests")
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    @GetMapping("/score")
    @Operation(summary = "Get overall multi-dimensional Productivity Score")
    public ResponseEntity<ApiResponse<AnalyticsDTO.OverallProductivityScore>> getOverallScore(
            @AuthenticationPrincipal UserPrincipal currentUser) {
        AnalyticsDTO.OverallProductivityScore score = analyticsService.getOverallScore(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success(score));
    }

    @GetMapping("/weekly-report")
    @Operation(summary = "Get weekly executive performance report")
    public ResponseEntity<ApiResponse<AnalyticsDTO.WeeklyReport>> getWeeklyReport(
            @AuthenticationPrincipal UserPrincipal currentUser) {
        AnalyticsDTO.WeeklyReport report = analyticsService.getWeeklyReport(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success(report));
    }
}
