package com.nivor.app.repository;

import com.nivor.app.model.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {
    List<Event> findByUserIdOrderByStartTimeAsc(Long userId);
    Optional<Event> findByIdAndUserId(Long id, Long userId);

    @Query("SELECT e FROM Event e WHERE e.user.id = :userId AND e.startTime >= :start AND e.endTime <= :end ORDER BY e.startTime ASC")
    List<Event> findEventsInRange(@Param("userId") Long userId, @Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
}
