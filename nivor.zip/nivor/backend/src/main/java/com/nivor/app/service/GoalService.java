package com.nivor.app.service;

import com.nivor.app.dto.GoalDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.Goal;
import com.nivor.app.model.Milestone;
import com.nivor.app.model.User;
import com.nivor.app.repository.GoalRepository;
import com.nivor.app.repository.MilestoneRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class GoalService {

    private final GoalRepository goalRepository;
    private final MilestoneRepository milestoneRepository;
    private final UserRepository userRepository;

    public List<GoalDTO.GoalResponse> getUserGoals(Long userId) {
        return goalRepository.findByUserIdOrderByCreatedAtDesc(userId)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Transactional
    public GoalDTO.GoalResponse createGoal(Long userId, GoalDTO.GoalRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        Goal goal = Goal.builder()
                .user(user)
                .title(request.getTitle())
                .description(request.getDescription())
                .category(request.getCategory() != null ? request.getCategory() : "Career")
                .targetDate(request.getTargetDate())
                .progressPercentage(request.getProgressPercentage() != null ? request.getProgressPercentage() : 0)
                .status(request.getStatus() != null ? request.getStatus() : "IN_PROGRESS")
                .color(request.getColor() != null ? request.getColor() : "#BF5AF2")
                .aiRoadmap(request.getAiRoadmap())
                .build();

        return mapToResponse(goalRepository.save(goal));
    }

    @Transactional
    public GoalDTO.MilestoneResponse addMilestone(Long userId, Long goalId, GoalDTO.MilestoneRequest request) {
        Goal goal = goalRepository.findByIdAndUserId(goalId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Goal", "id", goalId));

        Milestone milestone = Milestone.builder()
                .goal(goal)
                .title(request.getTitle())
                .dueDate(request.getDueDate())
                .isCompleted(request.getIsCompleted() != null ? request.getIsCompleted() : false)
                .orderIndex(request.getOrderIndex() != null ? request.getOrderIndex() : 0)
                .build();

        Milestone saved = milestoneRepository.save(milestone);
        recalculateGoalProgress(goal);
        return mapToMilestoneResponse(saved);
    }

    @Transactional
    public GoalDTO.MilestoneResponse toggleMilestone(Long userId, Long milestoneId) {
        Milestone milestone = milestoneRepository.findById(milestoneId)
                .orElseThrow(() -> new ResourceNotFoundException("Milestone", "id", milestoneId));

        if (!milestone.getGoal().getUser().getId().equals(userId)) {
            throw new ResourceNotFoundException("Milestone", "id", milestoneId);
        }

        milestone.setIsCompleted(!Boolean.TRUE.equals(milestone.getIsCompleted()));
        Milestone saved = milestoneRepository.save(milestone);
        recalculateGoalProgress(milestone.getGoal());
        return mapToMilestoneResponse(saved);
    }

    @Transactional
    public void deleteGoal(Long userId, Long goalId) {
        Goal goal = goalRepository.findByIdAndUserId(goalId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Goal", "id", goalId));
        goalRepository.delete(goal);
    }

    private void recalculateGoalProgress(Goal goal) {
        List<Milestone> ms = milestoneRepository.findByGoalIdOrderByOrderIndexAsc(goal.getId());
        if (ms.isEmpty()) return;
        long completed = ms.stream().filter(m -> Boolean.TRUE.equals(m.getIsCompleted())).count();
        int progress = (int) Math.round(((double) completed / ms.size()) * 100);
        goal.setProgressPercentage(progress);
        if (progress == 100) {
            goal.setStatus("ACHIEVED");
        }
        goalRepository.save(goal);
    }

    public GoalDTO.GoalResponse mapToResponse(Goal goal) {
        List<Milestone> milestones = milestoneRepository.findByGoalIdOrderByOrderIndexAsc(goal.getId());
        List<GoalDTO.MilestoneResponse> milestoneResponses = milestones.stream()
                .map(this::mapToMilestoneResponse).collect(Collectors.toList());

        return GoalDTO.GoalResponse.builder()
                .id(goal.getId())
                .title(goal.getTitle())
                .description(goal.getDescription())
                .category(goal.getCategory())
                .targetDate(goal.getTargetDate())
                .progressPercentage(goal.getProgressPercentage())
                .status(goal.getStatus())
                .color(goal.getColor())
                .aiRoadmap(goal.getAiRoadmap())
                .milestones(milestoneResponses)
                .createdAt(goal.getCreatedAt())
                .updatedAt(goal.getUpdatedAt())
                .build();
    }

    public GoalDTO.MilestoneResponse mapToMilestoneResponse(Milestone m) {
        return GoalDTO.MilestoneResponse.builder()
                .id(m.getId())
                .goalId(m.getGoal().getId())
                .title(m.getTitle())
                .dueDate(m.getDueDate())
                .isCompleted(m.getIsCompleted())
                .orderIndex(m.getOrderIndex())
                .build();
    }
}
