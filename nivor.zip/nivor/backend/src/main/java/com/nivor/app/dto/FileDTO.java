package com.nivor.app.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

public class FileDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class FileResponse {
        private Long id;
        private String name;
        private String fileType;
        private Long fileSizeBytes;
        private String storagePath;
        private String folder;
        private String tags;
        private String ocrExtractedText;
        private LocalDateTime createdAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class FileUploadRequest {
        private String name;
        private String fileType;
        private Long fileSizeBytes;
        private String storagePath;
        private String folder;
        private String tags;
    }
}
