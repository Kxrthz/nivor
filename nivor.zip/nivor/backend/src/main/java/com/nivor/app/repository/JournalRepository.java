package com.nivor.app.repository;

import com.nivor.app.model.Journal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface JournalRepository extends JpaRepository<Journal, Long> {
    List<Journal> findByUserIdOrderByEntryDateDesc(Long userId);
    Optional<Journal> findByUserIdAndEntryDate(Long userId, LocalDate entryDate);
    Optional<Journal> findByIdAndUserId(Long id, Long userId);
}
