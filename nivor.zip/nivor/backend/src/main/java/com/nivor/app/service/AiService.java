package com.nivor.app.service;

import com.nivor.app.dto.AiDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.AiConversation;
import com.nivor.app.model.AiMessage;
import com.nivor.app.model.User;
import com.nivor.app.repository.AiConversationRepository;
import com.nivor.app.repository.AiMessageRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AiService {

    private final AiConversationRepository conversationRepository;
    private final AiMessageRepository messageRepository;
    private final UserRepository userRepository;

    public List<AiDTO.ConversationResponse> getUserConversations(Long userId) {
        return conversationRepository.findByUserIdOrderByUpdatedAtDesc(userId)
                .stream().map(this::mapToConversationResponse).collect(Collectors.toList());
    }

    public AiDTO.ConversationResponse getConversation(Long userId, Long convId) {
        AiConversation conv = conversationRepository.findByIdAndUserId(convId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Conversation", "id", convId));
        return mapToConversationResponse(conv);
    }

    @Transactional
    public AiDTO.MessageResponse processMessage(Long userId, AiDTO.ChatRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        AiConversation conversation;
        if (request.getConversationId() != null) {
            conversation = conversationRepository.findByIdAndUserId(request.getConversationId(), userId)
                    .orElseThrow(() -> new ResourceNotFoundException("Conversation", "id", request.getConversationId()));
        } else {
            String title = request.getPrompt().length() > 40 ? request.getPrompt().substring(0, 37) + "..." : request.getPrompt();
            conversation = AiConversation.builder()
                    .user(user)
                    .title(title)
                    .contextMode(request.getContextMode() != null ? request.getContextMode() : "GENERAL")
                    .build();
            conversation = conversationRepository.save(conversation);
        }

        // Save User Message
        AiMessage userMsg = AiMessage.builder()
                .conversation(conversation)
                .sender("USER")
                .content(request.getPrompt())
                .tokensUsed(estimateTokens(request.getPrompt()))
                .build();
        messageRepository.save(userMsg);

        // Generate Contextual AI Response
        String aiReplyContent = generateIntelligentResponse(request.getPrompt(), request.getContextMode(), user.getFullName());

        AiMessage aiMsg = AiMessage.builder()
                .conversation(conversation)
                .sender("AI")
                .content(aiReplyContent)
                .tokensUsed(estimateTokens(aiReplyContent))
                .structuredActionJson("{\"action\": \"SCHEDULE_OPTIMIZATION_READY\", \"confidence\": 0.98}")
                .build();

        AiMessage savedAiMsg = messageRepository.save(aiMsg);
        return mapToMessageResponse(savedAiMsg);
    }

    public List<AiDTO.PromptSuggestion> getPromptSuggestions() {
        List<AiDTO.PromptSuggestion> list = new ArrayList<>();
        list.add(AiDTO.PromptSuggestion.builder()
                .title("Optimize My Day")
                .prompt("Analyze my remaining tasks for today and schedule them into focused time-blocks.")
                .icon("Calendar")
                .category("Schedule")
                .build());
        list.add(AiDTO.PromptSuggestion.builder()
                .title("Draft 14-Day Study Plan")
                .prompt("Create an aggressive 14-day mastery curriculum for Distributed Systems and Rust.")
                .icon("BookOpen")
                .category("Study")
                .build());
        list.add(AiDTO.PromptSuggestion.builder()
                .title("High-Performance Workout")
                .prompt("Generate a 4-day push/pull/legs protocol with Zone 2 cardio integration.")
                .icon("Activity")
                .category("Health")
                .build());
        list.add(AiDTO.PromptSuggestion.builder()
                .title("Financial Outflow Audit")
                .prompt("Review my recent expenses and suggest 3 high-impact areas to trim recurring waste.")
                .icon("DollarSign")
                .category("Finance")
                .build());
        return list;
    }

    private String generateIntelligentResponse(String prompt, String contextMode, String userName) {
        String p = prompt.toLowerCase();
        if (p.contains("schedule") || p.contains("day") || p.contains("time")) {
            return "Good day " + userName + ". I have analyzed your schedule:\n\n" +
                    "• **09:00 - 10:30**: ⚡ Deep Work Block (High-Priority Engineering)\n" +
                    "• **11:00 - 11:45**: 📅 Product Architecture Sync\n" +
                    "• **14:00 - 15:30**: 🎯 Strategy & Goal Milestones Review\n" +
                    "• **17:00 - 17:45**: 🏃 Zone 2 Recovery & Hydration\n\n" +
                    "Would you like me to lock these timeblocks directly into your NIVOR Calendar?";
        } else if (p.contains("workout") || p.contains("fitness") || p.contains("exercise")) {
            return "Here is your personalized **High-Leverage Athletic Protocol**:\n\n" +
                    "1. **Warmup (8m)**: Banded shoulder dislocations & hip opening dynamic flows.\n" +
                    "2. **Main Block (35m)**: 4x8 Incline Dumbbell Press, 4x6 Heavy Neutral Grip Pullups, 3x12 Bulgarian Split Squats.\n" +
                    "3. **Metabolic Finisher (12m)**: 30s Air Bike sprints / 30s rest x 8 rounds.\n" +
                    "4. **Hydration**: Remember to log at least 800ml electrolyte water in NIVOR Health.";
        } else if (p.contains("study") || p.contains("learn") || p.contains("plan")) {
            return "### 📘 14-Day Accelerated Mastery Roadmap\n\n" +
                    "- **Phase 1 (Days 1–4)**: Core Principles & Architectural Invariants.\n" +
                    "- **Phase 2 (Days 5–9)**: Hands-on implementation & failure scenario debugging.\n" +
                    "- **Phase 3 (Days 10–14)**: System optimization, benchmarking, and real-world synthesis.\n\n" +
                    "I've initialized these milestones in your Goals module. Would you like a daily 30-minute recall checklist?";
        } else {
            return "I am your NIVOR Executive Intelligence. I can assist you in reorganizing your task priority matrix, formulating long-term OKRs, summarizing markdown notes, or analyzing your weekly productivity metrics.\n\nWhat high-leverage objective are we tackling next?";
        }
    }

    private int estimateTokens(String text) {
        return text != null ? text.length() / 4 : 0;
    }

    public AiDTO.ConversationResponse mapToConversationResponse(AiConversation conv) {
        List<AiMessage> msgs = messageRepository.findByConversationIdOrderByCreatedAtAsc(conv.getId());
        List<AiDTO.MessageResponse> msgResponses = msgs.stream()
                .map(this::mapToMessageResponse).collect(Collectors.toList());

        return AiDTO.ConversationResponse.builder()
                .id(conv.getId())
                .title(conv.getTitle())
                .contextMode(conv.getContextMode())
                .messages(msgResponses)
                .updatedAt(conv.getUpdatedAt())
                .build();
    }

    public AiDTO.MessageResponse mapToMessageResponse(AiMessage msg) {
        return AiDTO.MessageResponse.builder()
                .id(msg.getId())
                .sender(msg.getSender())
                .content(msg.getContent())
                .tokensUsed(msg.getTokensUsed())
                .structuredActionJson(msg.getStructuredActionJson())
                .createdAt(msg.getCreatedAt())
                .build();
    }
}
