package com.nivor.app.service;

import com.nivor.app.dto.ProjectDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.Project;
import com.nivor.app.model.Task;
import com.nivor.app.model.User;
import com.nivor.app.repository.ProjectRepository;
import com.nivor.app.repository.TaskRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProjectService {

    private final ProjectRepository projectRepository;
    private final TaskRepository taskRepository;
    private final UserRepository userRepository;

    public List<ProjectDTO.ProjectResponse> getUserProjects(Long userId) {
        return projectRepository.findByUserIdOrderByCreatedAtDesc(userId)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Transactional
    public ProjectDTO.ProjectResponse createProject(Long userId, ProjectDTO.ProjectRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        Project project = Project.builder()
                .user(user)
                .name(request.getName())
                .description(request.getDescription())
                .color(request.getColor() != null ? request.getColor() : "#0A84FF")
                .icon(request.getIcon() != null ? request.getIcon() : "Folder")
                .status(request.getStatus() != null ? request.getStatus() : "ACTIVE")
                .viewMode(request.getViewMode() != null ? request.getViewMode() : "KANBAN")
                .build();

        return mapToResponse(projectRepository.save(project));
    }

    @Transactional
    public ProjectDTO.ProjectResponse updateProject(Long userId, Long projectId, ProjectDTO.ProjectRequest request) {
        Project project = projectRepository.findByIdAndUserId(projectId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Project", "id", projectId));

        if (request.getName() != null) project.setName(request.getName());
        if (request.getDescription() != null) project.setDescription(request.getDescription());
        if (request.getColor() != null) project.setColor(request.getColor());
        if (request.getIcon() != null) project.setIcon(request.getIcon());
        if (request.getStatus() != null) project.setStatus(request.getStatus());
        if (request.getViewMode() != null) project.setViewMode(request.getViewMode());

        return mapToResponse(projectRepository.save(project));
    }

    @Transactional
    public void deleteProject(Long userId, Long projectId) {
        Project project = projectRepository.findByIdAndUserId(projectId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Project", "id", projectId));
        projectRepository.delete(project);
    }

    public ProjectDTO.ProjectResponse mapToResponse(Project project) {
        List<Task> tasks = taskRepository.findByProjectId(project.getId());
        int taskCount = tasks.size();
        int completedCount = (int) tasks.stream().filter(t -> "COMPLETED".equalsIgnoreCase(t.getStatus())).count();

        return ProjectDTO.ProjectResponse.builder()
                .id(project.getId())
                .name(project.getName())
                .description(project.getDescription())
                .color(project.getColor())
                .icon(project.getIcon())
                .status(project.getStatus())
                .viewMode(project.getViewMode())
                .taskCount(taskCount)
                .completedTaskCount(completedCount)
                .createdAt(project.getCreatedAt())
                .updatedAt(project.getUpdatedAt())
                .build();
    }
}
