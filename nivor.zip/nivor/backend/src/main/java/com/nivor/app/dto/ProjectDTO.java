package com.nivor.app.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

public class ProjectDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ProjectRequest {
        @NotBlank(message = "Project name is required")
        private String name;
        private String description;
        private String color;
        private String icon;
        private String status;
        private String viewMode;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ProjectResponse {
        private Long id;
        private String name;
        private String description;
        private String color;
        private String icon;
        private String status;
        private String viewMode;
        private Integer taskCount;
        private Integer completedTaskCount;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }
}
