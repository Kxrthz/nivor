package com.nivor.app.util;

import com.nivor.app.model.*;
import com.nivor.app.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final UserSettingsRepository userSettingsRepository;
    private final ProjectRepository projectRepository;
    private final TaskRepository taskRepository;
    private final EventRepository eventRepository;
    private final NoteRepository noteRepository;
    private final JournalRepository journalRepository;
    private final HabitRepository habitRepository;
    private final HabitLogRepository habitLogRepository;
    private final GoalRepository goalRepository;
    private final MilestoneRepository milestoneRepository;
    private final FinanceTransactionRepository transactionRepository;
    private final BudgetRepository budgetRepository;
    private final HealthMetricRepository healthMetricRepository;
    private final FocusSessionRepository focusSessionRepository;
    private final StoredFileRepository fileRepository;
    private final NotificationRepository notificationRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.findByEmail("demo@nivor.app").isPresent()) {
            log.info("NIVOR demo dataset already initialized.");
            return;
        }

        log.info("Bootstrapping NIVOR demo dataset with Apple-grade default metrics...");

        // 1. Create Demo User
        User demoUser = User.builder()
                .email("demo@nivor.app")
                .fullName("Alexander Wright")
                .passwordHash(passwordEncoder.encode("Password123!"))
                .avatarUrl("https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80")
                .role("ROLE_USER")
                .provider("LOCAL")
                .isActive(true)
                .build();

        demoUser = userRepository.save(demoUser);

        // 2. Settings
        UserSettings settings = UserSettings.builder()
                .user(demoUser)
                .theme("dark")
                .accentColor("system_blue")
                .soundEffectsEnabled(true)
                .hapticFeedback(true)
                .aiMemoryEnabled(true)
                .aiPersonality("Apple Intelligence Executive")
                .emailNotifications(true)
                .pushNotifications(true)
                .weeklySummaryEmail(true)
                .timeZone("America/New_York")
                .dateFormat("MM/DD/YYYY")
                .build();
        userSettingsRepository.save(settings);

        // 3. Projects
        Project p1 = projectRepository.save(Project.builder()
                .user(demoUser)
                .name("Quantum OS 3.0 Launch")
                .description("Next generation spatial interface and desktop companion suite")
                .color("#0A84FF")
                .icon("Layers")
                .status("ACTIVE")
                .viewMode("KANBAN")
                .build());

        Project p2 = projectRepository.save(Project.builder()
                .user(demoUser)
                .name("Personal Health & Fitness")
                .description("Daily nutrition, marathon conditioning, and sleep architecture")
                .color("#30D158")
                .icon("Heart")
                .status("ACTIVE")
                .viewMode("LIST")
                .build());

        // 4. Tasks
        taskRepository.save(Task.builder()
                .user(demoUser)
                .project(p1)
                .title("Review Apple Human Interface guidelines for VisionOS widgets")
                .description("Audit frosted glass material curves and optical physics")
                .status("COMPLETED")
                .priority("HIGH")
                .dueDate(LocalDateTime.now())
                .completedAt(LocalDateTime.now())
                .estimatedMinutes(45)
                .orderIndex(1)
                .build());

        taskRepository.save(Task.builder()
                .user(demoUser)
                .project(p1)
                .title("Finalize Spring Boot 3 & JWT token rotation security layer")
                .description("Add rate limiting, CSRF tokens, and secure cookie storage headers")
                .status("IN_PROGRESS")
                .priority("URGENT")
                .dueDate(LocalDateTime.now().plusHours(2))
                .estimatedMinutes(90)
                .orderIndex(2)
                .build());

        taskRepository.save(Task.builder()
                .user(demoUser)
                .project(p2)
                .title("Morning 7km Zone 2 aerobic recovery run")
                .description("Target HR: 135-142 bpm along coastal trail")
                .status("COMPLETED")
                .priority("MEDIUM")
                .dueDate(LocalDateTime.now())
                .completedAt(LocalDateTime.now())
                .estimatedMinutes(40)
                .orderIndex(3)
                .build());

        // 5. Events
        eventRepository.save(Event.builder()
                .user(demoUser)
                .title("Product Architecture Sync with Executive Team")
                .description("Review NIVOR Spring Boot + React 19 production readiness")
                .location("Infinite Loop Room 4B / Zoom")
                .startTime(LocalDateTime.now().plusHours(1))
                .endTime(LocalDateTime.now().plusHours(2))
                .color("#0A84FF")
                .category("Work")
                .syncSource("NIVOR")
                .build());

        // 6. Habits & Logs
        Habit h1 = habitRepository.save(Habit.builder()
                .user(demoUser)
                .name("Deep Work Focus Block (90m)")
                .description("Zero notifications, high cognitive output")
                .frequency("DAILY")
                .targetCountPerDay(2)
                .unit("sessions")
                .color("#0A84FF")
                .icon("Zap")
                .currentStreak(14)
                .longestStreak(28)
                .build());

        Habit h2 = habitRepository.save(Habit.builder()
                .user(demoUser)
                .name("Hydrate 3.5 Liters")
                .description("Structured electrolyte spring water intake")
                .frequency("DAILY")
                .targetCountPerDay(3500)
                .unit("ml")
                .color("#64D2FF")
                .icon("Droplets")
                .currentStreak(21)
                .longestStreak(45)
                .build());

        habitLogRepository.save(HabitLog.builder()
                .habit(h1)
                .user(demoUser)
                .logDate(LocalDate.now())
                .count(2)
                .isCompleted(true)
                .build());

        habitLogRepository.save(HabitLog.builder()
                .habit(h2)
                .user(demoUser)
                .logDate(LocalDate.now())
                .count(3200)
                .isCompleted(true)
                .build());

        // 7. Goals & Milestones
        Goal g1 = goalRepository.save(Goal.builder()
                .user(demoUser)
                .title("Scale NIVOR to 100,000 Active Daily Power Users")
                .description("Achieve zero-downtime micro-latency performance and 4.9 App Store rating")
                .category("Career")
                .targetDate(LocalDate.now().plusDays(90))
                .progressPercentage(68)
                .status("IN_PROGRESS")
                .color("#0A84FF")
                .aiRoadmap("Phase 1: Zero-latency backend; Phase 2: Offline sync; Phase 3: Global CDN distribution.")
                .build());

        milestoneRepository.save(Milestone.builder()
                .goal(g1)
                .title("Deploy Spring Boot 3 clustered container to Render")
                .dueDate(LocalDate.now().plusDays(10))
                .isCompleted(true)
                .orderIndex(1)
                .build());

        milestoneRepository.save(Milestone.builder()
                .goal(g1)
                .title("Complete Apple Design HIG audit for dark/light themes")
                .dueDate(LocalDate.now().plusDays(20))
                .isCompleted(true)
                .orderIndex(2)
                .build());

        // 8. Notes
        noteRepository.save(Note.builder()
                .user(demoUser)
                .title("NIVOR High-Performance Architecture Blueprint")
                .content("# NIVOR System Architecture\n\n- **Client**: React 19, TypeScript, Tailwind CSS, Framer Motion\n- **State**: Zustand + TanStack Query\n- **Backend**: Spring Boot 3.3, Java 21, Spring Security 6\n- **Database**: MySQL 8.0 with InnoDB connection pooling\n- **Theme**: Apple Liquid Retina Glassmorphism")
                .summary("Key architectural decisions and runtime benchmarks for NIVOR OS")
                .isPinned(true)
                .color("#0A84FF")
                .tags("Engineering,Architecture")
                .build());

        // 9. Journals
        journalRepository.save(Journal.builder()
                .user(demoUser)
                .title("Clarity, Focus, and Architectural Symmetry")
                .content("Today felt like a turning point. We successfully merged the high-performance Spring Boot backend with our bespoke React 19 UI. The fluid animations at 120fps feel indistinguishable from a native macOS app.")
                .mood(5)
                .moodLabel("Ecstatic")
                .gratitudeList("[\"Seamless compilation\", \"Sunny morning run by harbor\", \"Crisp espresso\"]")
                .weather("Clear 71°F")
                .entryDate(LocalDate.now())
                .build());

        // 10. Finance
        transactionRepository.save(FinanceTransaction.builder()
                .user(demoUser)
                .title("Enterprise AI SaaS Retainer")
                .amount(BigDecimal.valueOf(12500.00))
                .type("INCOME")
                .category("Consulting")
                .currency("USD")
                .isRecurring(true)
                .transactionDate(LocalDate.now())
                .build());

        transactionRepository.save(FinanceTransaction.builder()
                .user(demoUser)
                .title("AWS High-Performance Cloud Cluster")
                .amount(BigDecimal.valueOf(420.50))
                .type("EXPENSE")
                .category("Tech")
                .currency("USD")
                .isRecurring(true)
                .transactionDate(LocalDate.now())
                .build());

        budgetRepository.save(Budget.builder()
                .user(demoUser)
                .category("Tech")
                .monthlyLimit(BigDecimal.valueOf(2000.00))
                .spentAmount(BigDecimal.valueOf(720.50))
                .monthYear(LocalDate.now().getYear() + "-" + String.format("%02d", LocalDate.now().getMonthValue()))
                .build());

        // 11. Health
        healthMetricRepository.save(HealthMetric.builder()
                .user(demoUser)
                .type("WATER_ML")
                .metricValue(BigDecimal.valueOf(3200))
                .unit("ml")
                .loggedAt(LocalDate.now())
                .build());

        healthMetricRepository.save(HealthMetric.builder()
                .user(demoUser)
                .type("STEPS")
                .metricValue(BigDecimal.valueOf(12450))
                .unit("steps")
                .loggedAt(LocalDate.now())
                .build());

        // 12. Focus Sessions
        focusSessionRepository.save(FocusSession.builder()
                .user(demoUser)
                .sessionType("DEEP_WORK")
                .durationMinutes(90)
                .productivityRating(5)
                .tag("Backend Engineering")
                .soundtrack("Rainy Forest")
                .build());

        // 13. Notifications
        notificationRepository.save(Notification.builder()
                .user(demoUser)
                .title("Deep Work Goal Reached")
                .body("You have completed 90 minutes of uninterrupted focus today.")
                .type("FOCUS_NUDGE")
                .isRead(false)
                .build());

        log.info("NIVOR demo dataset successfully initialized!");
    }
}
