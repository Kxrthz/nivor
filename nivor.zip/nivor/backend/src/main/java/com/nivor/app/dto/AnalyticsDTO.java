package com.nivor.app.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

public class AnalyticsDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class OverallProductivityScore {
        private int overallScore; // 0 - 100
        private int taskScore;
        private int habitScore;
        private int focusScore;
        private int healthScore;
        private String grade; // S, A+, A, B, C
        private String aiInsight;
        private List<DayScore> pastWeekScores;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class DayScore {
        private String dayName;
        private String date;
        private int score;
        private int tasksCompleted;
        private int focusMinutes;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CategoryTimeDistribution {
        private Map<String, Integer> distributionMinutes;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class WeeklyReport {
        private String weekLabel;
        private int totalTasksCompleted;
        private int totalFocusHours;
        private int averageProductivityScore;
        private double habitAdherenceRate;
        private String highlightOfWeek;
        private String areaForImprovement;
        private String aiExecutiveSummary;
    }
}
