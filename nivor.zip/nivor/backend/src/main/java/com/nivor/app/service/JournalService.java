package com.nivor.app.service;

import com.nivor.app.dto.JournalDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.Journal;
import com.nivor.app.model.User;
import com.nivor.app.repository.JournalRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class JournalService {

    private final JournalRepository journalRepository;
    private final UserRepository userRepository;

    public List<JournalDTO.JournalResponse> getUserJournals(Long userId) {
        return journalRepository.findByUserIdOrderByEntryDateDesc(userId)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    public JournalDTO.JournalResponse getJournalForDate(Long userId, LocalDate date) {
        Journal journal = journalRepository.findByUserIdAndEntryDate(userId, date)
                .orElse(null);
        return journal != null ? mapToResponse(journal) : null;
    }

    @Transactional
    public JournalDTO.JournalResponse saveOrUpdateJournal(Long userId, JournalDTO.JournalRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        Optional<Journal> existing = journalRepository.findByUserIdAndEntryDate(userId, request.getEntryDate());
        Journal journal;

        if (existing.isPresent()) {
            journal = existing.get();
            journal.setTitle(request.getTitle());
            journal.setContent(request.getContent());
            if (request.getMood() != null) journal.setMood(request.getMood());
            if (request.getMoodLabel() != null) journal.setMoodLabel(request.getMoodLabel());
            if (request.getGratitudeList() != null) journal.setGratitudeList(request.getGratitudeList());
            if (request.getWeather() != null) journal.setWeather(request.getWeather());
            if (request.getLocation() != null) journal.setLocation(request.getLocation());
            if (request.getVoiceMemoUrl() != null) journal.setVoiceMemoUrl(request.getVoiceMemoUrl());
        } else {
            journal = Journal.builder()
                    .user(user)
                    .title(request.getTitle())
                    .content(request.getContent())
                    .mood(request.getMood() != null ? request.getMood() : 5)
                    .moodLabel(request.getMoodLabel() != null ? request.getMoodLabel() : "Happy")
                    .gratitudeList(request.getGratitudeList())
                    .weather(request.getWeather() != null ? request.getWeather() : "Sunny 72°F")
                    .location(request.getLocation())
                    .voiceMemoUrl(request.getVoiceMemoUrl())
                    .entryDate(request.getEntryDate())
                    .build();
        }

        return mapToResponse(journalRepository.save(journal));
    }

    @Transactional
    public void deleteJournal(Long userId, Long journalId) {
        Journal journal = journalRepository.findByIdAndUserId(journalId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Journal", "id", journalId));
        journalRepository.delete(journal);
    }

    public JournalDTO.JournalResponse mapToResponse(Journal journal) {
        return JournalDTO.JournalResponse.builder()
                .id(journal.getId())
                .title(journal.getTitle())
                .content(journal.getContent())
                .mood(journal.getMood())
                .moodLabel(journal.getMoodLabel())
                .gratitudeList(journal.getGratitudeList())
                .weather(journal.getWeather())
                .location(journal.getLocation())
                .voiceMemoUrl(journal.getVoiceMemoUrl())
                .entryDate(journal.getEntryDate())
                .createdAt(journal.getCreatedAt())
                .updatedAt(journal.getUpdatedAt())
                .build();
    }
}
