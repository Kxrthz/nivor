package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.JournalDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.JournalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1/journals")
@RequiredArgsConstructor
@Tag(name = "Journal", description = "Daily reflections, mood tracking, and gratitude logs")
public class JournalController {

    private final JournalService journalService;

    @GetMapping
    @Operation(summary = "Get all journal entries")
    public ResponseEntity<ApiResponse<List<JournalDTO.JournalResponse>>> getJournals(
            @AuthenticationPrincipal UserPrincipal currentUser) {
        List<JournalDTO.JournalResponse> list = journalService.getUserJournals(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success(list));
    }

    @GetMapping("/date/{date}")
    @Operation(summary = "Get journal entry for specific date")
    public ResponseEntity<ApiResponse<JournalDTO.JournalResponse>> getJournalByDate(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        JournalDTO.JournalResponse journal = journalService.getJournalForDate(currentUser.getId(), date);
        return ResponseEntity.ok(ApiResponse.success(journal));
    }

    @PostMapping
    @Operation(summary = "Save or update a journal entry")
    public ResponseEntity<ApiResponse<JournalDTO.JournalResponse>> saveJournal(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody JournalDTO.JournalRequest request) {
        JournalDTO.JournalResponse journal = journalService.saveOrUpdateJournal(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Journal saved successfully", journal));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a journal entry")
    public ResponseEntity<ApiResponse<Void>> deleteJournal(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        journalService.deleteJournal(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success("Journal deleted successfully", null));
    }
}
