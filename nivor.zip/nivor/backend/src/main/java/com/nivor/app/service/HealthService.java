package com.nivor.app.service;

import com.nivor.app.dto.HealthDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.HealthMetric;
import com.nivor.app.model.User;
import com.nivor.app.repository.HealthMetricRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HealthService {

    private final HealthMetricRepository metricRepository;
    private final UserRepository userRepository;

    public HealthDTO.DailyHealthSummary getDailySummary(Long userId, LocalDate date) {
        LocalDate targetDate = date != null ? date : LocalDate.now();
        List<HealthMetric> metrics = metricRepository.findByUserIdAndLoggedAt(userId, targetDate);

        BigDecimal water = BigDecimal.ZERO;
        BigDecimal sleep = BigDecimal.ZERO;
        BigDecimal steps = BigDecimal.ZERO;
        BigDecimal weight = BigDecimal.ZERO;
        BigDecimal workout = BigDecimal.ZERO;

        for (HealthMetric m : metrics) {
            switch (m.getType().toUpperCase()) {
                case "WATER_ML" -> water = water.add(m.getMetricValue());
                case "SLEEP_HOURS" -> sleep = m.getMetricValue();
                case "STEPS" -> steps = steps.add(m.getMetricValue());
                case "WEIGHT_KG" -> weight = m.getMetricValue();
                case "WORKOUT_MIN" -> workout = workout.add(m.getMetricValue());
            }
        }

        // If weight wasn't logged today, fetch recent
        if (weight.compareTo(BigDecimal.ZERO) == 0) {
            List<HealthMetric> recentWeight = metricRepository.findRecentByType(userId, "WEIGHT_KG");
            if (!recentWeight.isEmpty()) {
                weight = recentWeight.get(0).getMetricValue();
            }
        }

        List<HealthDTO.MetricResponse> rawResponses = metrics.stream()
                .map(this::mapToResponse).collect(Collectors.toList());

        return HealthDTO.DailyHealthSummary.builder()
                .date(targetDate)
                .waterMl(water)
                .waterTargetMl(BigDecimal.valueOf(3500))
                .sleepHours(sleep)
                .sleepTargetHours(BigDecimal.valueOf(8.0))
                .steps(steps)
                .stepsTarget(BigDecimal.valueOf(10000))
                .weightKg(weight)
                .workoutMinutes(workout)
                .rawMetrics(rawResponses)
                .build();
    }

    @Transactional
    public HealthDTO.MetricResponse logMetric(Long userId, HealthDTO.MetricLogRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        HealthMetric metric = HealthMetric.builder()
                .user(user)
                .type(request.getType().toUpperCase())
                .metricValue(request.getValue())
                .unit(request.getUnit())
                .notes(request.getNotes())
                .loggedAt(request.getLoggedAt())
                .build();

        return mapToResponse(metricRepository.save(metric));
    }

    public List<HealthDTO.MetricResponse> getMetricsHistory(Long userId, LocalDate start, LocalDate end) {
        LocalDate s = start != null ? start : LocalDate.now().minusDays(30);
        LocalDate e = end != null ? end : LocalDate.now();
        return metricRepository.findMetricsInRange(userId, s, e)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    public HealthDTO.MetricResponse mapToResponse(HealthMetric m) {
        return HealthDTO.MetricResponse.builder()
                .id(m.getId())
                .type(m.getType())
                .value(m.getMetricValue())
                .unit(m.getUnit())
                .notes(m.getNotes())
                .loggedAt(m.getLoggedAt())
                .build();
    }
}
