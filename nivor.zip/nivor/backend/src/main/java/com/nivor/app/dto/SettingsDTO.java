package com.nivor.app.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

public class SettingsDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SettingsUpdateRequest {
        private String theme;
        private String accentColor;
        private Boolean soundEffectsEnabled;
        private Boolean hapticFeedback;
        private Boolean aiMemoryEnabled;
        private String aiPersonality;
        private Boolean emailNotifications;
        private Boolean pushNotifications;
        private Boolean weeklySummaryEmail;
        private String timeZone;
        private String dateFormat;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SettingsResponse {
        private Long id;
        private String theme;
        private String accentColor;
        private Boolean soundEffectsEnabled;
        private Boolean hapticFeedback;
        private Boolean aiMemoryEnabled;
        private String aiPersonality;
        private Boolean emailNotifications;
        private Boolean pushNotifications;
        private Boolean weeklySummaryEmail;
        private String timeZone;
        private String dateFormat;
    }
}
