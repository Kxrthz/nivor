package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.FocusDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.FocusService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/focus")
@RequiredArgsConstructor
@Tag(name = "Focus & Deep Work", description = "Pomodoro sessions, deep work timers, and stats")
public class FocusController {

    private final FocusService focusService;

    @GetMapping("/summary")
    @Operation(summary = "Get focus stats, time totals, and session history")
    public ResponseEntity<ApiResponse<FocusDTO.FocusSummaryResponse>> getSummary(
            @AuthenticationPrincipal UserPrincipal currentUser) {
        FocusDTO.FocusSummaryResponse summary = focusService.getFocusSummary(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success(summary));
    }

    @PostMapping("/sessions")
    @Operation(summary = "Log a completed focus or Pomodoro session")
    public ResponseEntity<ApiResponse<FocusDTO.SessionResponse>> logSession(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody FocusDTO.SessionLogRequest request) {
        FocusDTO.SessionResponse session = focusService.logSession(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Session recorded", session));
    }
}
