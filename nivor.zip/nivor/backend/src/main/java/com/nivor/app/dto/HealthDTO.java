package com.nivor.app.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class HealthDTO {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class MetricLogRequest {
        @NotBlank(message = "Type is required")
        private String type; // WATER_ML, SLEEP_HOURS, STEPS, WEIGHT_KG, WORKOUT_MIN
        @NotNull(message = "Value is required")
        private BigDecimal value;
        @NotBlank(message = "Unit is required")
        private String unit;
        private String notes;
        @NotNull(message = "Date is required")
        private LocalDate loggedAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class MetricResponse {
        private Long id;
        private String type;
        private BigDecimal value;
        private String unit;
        private String notes;
        private LocalDate loggedAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class DailyHealthSummary {
        private LocalDate date;
        private BigDecimal waterMl;
        private BigDecimal waterTargetMl;
        private BigDecimal sleepHours;
        private BigDecimal sleepTargetHours;
        private BigDecimal steps;
        private BigDecimal stepsTarget;
        private BigDecimal weightKg;
        private BigDecimal workoutMinutes;
        private List<MetricResponse> rawMetrics;
    }
}
