package com.nivor.app.service;

import com.nivor.app.dto.NotificationDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.Notification;
import com.nivor.app.model.User;
import com.nivor.app.repository.NotificationRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;

    public List<NotificationDTO.NotificationResponse> getUserNotifications(Long userId, Boolean unreadOnly) {
        List<Notification> list;
        if (Boolean.TRUE.equals(unreadOnly)) {
            list = notificationRepository.findByUserIdAndIsReadFalseOrderByCreatedAtDesc(userId);
        } else {
            list = notificationRepository.findByUserIdOrderByCreatedAtDesc(userId);
        }
        return list.stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    public long getUnreadCount(Long userId) {
        return notificationRepository.countByUserIdAndIsReadFalse(userId);
    }

    @Transactional
    public NotificationDTO.NotificationResponse markAsRead(Long userId, Long notificationId) {
        Notification n = notificationRepository.findByIdAndUserId(notificationId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification", "id", notificationId));
        n.setIsRead(true);
        return mapToResponse(notificationRepository.save(n));
    }

    @Transactional
    public void markAllAsRead(Long userId) {
        List<Notification> unread = notificationRepository.findByUserIdAndIsReadFalseOrderByCreatedAtDesc(userId);
        unread.forEach(n -> n.setIsRead(true));
        notificationRepository.saveAll(unread);
    }

    @Transactional
    public NotificationDTO.NotificationResponse createNotification(Long userId, NotificationDTO.CreateNotificationRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        Notification n = Notification.builder()
                .user(user)
                .title(request.getTitle())
                .body(request.getBody())
                .type(request.getType() != null ? request.getType() : "SYSTEM")
                .actionUrl(request.getActionUrl())
                .isRead(false)
                .build();

        return mapToResponse(notificationRepository.save(n));
    }

    public NotificationDTO.NotificationResponse mapToResponse(Notification n) {
        return NotificationDTO.NotificationResponse.builder()
                .id(n.getId())
                .title(n.getTitle())
                .body(n.getBody())
                .type(n.getType())
                .isRead(n.getIsRead())
                .actionUrl(n.getActionUrl())
                .createdAt(n.getCreatedAt())
                .build();
    }
}
