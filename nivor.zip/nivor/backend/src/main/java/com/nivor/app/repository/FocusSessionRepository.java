package com.nivor.app.repository;

import com.nivor.app.model.FocusSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface FocusSessionRepository extends JpaRepository<FocusSession, Long> {
    List<FocusSession> findByUserIdOrderByCompletedAtDesc(Long userId);

    @Query("SELECT fs FROM FocusSession fs WHERE fs.user.id = :userId AND fs.completedAt >= :since ORDER BY fs.completedAt DESC")
    List<FocusSession> findSessionsSince(@Param("userId") Long userId, @Param("since") LocalDateTime since);

    @Query("SELECT COALESCE(SUM(fs.durationMinutes), 0) FROM FocusSession fs WHERE fs.user.id = :userId AND fs.completedAt >= :since")
    long getTotalFocusMinutesSince(@Param("userId") Long userId, @Param("since") LocalDateTime since);
}
