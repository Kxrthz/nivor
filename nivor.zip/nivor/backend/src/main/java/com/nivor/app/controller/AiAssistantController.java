package com.nivor.app.controller;

import com.nivor.app.dto.AiDTO;
import com.nivor.app.dto.ApiResponse;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.AiService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/ai")
@RequiredArgsConstructor
@Tag(name = "AI Assistant & Intelligence", description = "Contextual conversational AI, schedule optimizers, and study/workout planners")
public class AiAssistantController {

    private final AiService aiService;

    @GetMapping("/conversations")
    @Operation(summary = "Get user AI conversation threads")
    public ResponseEntity<ApiResponse<List<AiDTO.ConversationResponse>>> getConversations(
            @AuthenticationPrincipal UserPrincipal currentUser) {
        List<AiDTO.ConversationResponse> list = aiService.getUserConversations(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success(list));
    }

    @GetMapping("/conversations/{id}")
    @Operation(summary = "Get single AI conversation with full chat history")
    public ResponseEntity<ApiResponse<AiDTO.ConversationResponse>> getConversation(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        AiDTO.ConversationResponse conv = aiService.getConversation(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success(conv));
    }

    @PostMapping("/chat")
    @Operation(summary = "Send a prompt to NIVOR AI and get an executive response")
    public ResponseEntity<ApiResponse<AiDTO.MessageResponse>> chat(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody AiDTO.ChatRequest request) {
        AiDTO.MessageResponse reply = aiService.processMessage(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success(reply));
    }

    @GetMapping("/suggestions")
    @Operation(summary = "Get contextual prompt suggestions")
    public ResponseEntity<ApiResponse<List<AiDTO.PromptSuggestion>>> getSuggestions() {
        List<AiDTO.PromptSuggestion> list = aiService.getPromptSuggestions();
        return ResponseEntity.ok(ApiResponse.success(list));
    }
}
