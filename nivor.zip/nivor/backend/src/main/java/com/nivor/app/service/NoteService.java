package com.nivor.app.service;

import com.nivor.app.dto.NoteDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.Note;
import com.nivor.app.model.User;
import com.nivor.app.repository.NoteRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class NoteService {

    private final NoteRepository noteRepository;
    private final UserRepository userRepository;

    public List<NoteDTO.NoteResponse> getUserNotes(Long userId, String search) {
        List<Note> notes;
        if (search != null && !search.trim().isEmpty()) {
            notes = noteRepository.searchNotes(userId, search.trim());
        } else {
            notes = noteRepository.findByUserIdOrderByIsPinnedDescUpdatedAtDesc(userId);
        }
        return notes.stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    public NoteDTO.NoteResponse getNoteById(Long userId, Long noteId) {
        Note note = noteRepository.findByIdAndUserId(noteId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Note", "id", noteId));
        return mapToResponse(note);
    }

    @Transactional
    public NoteDTO.NoteResponse createNote(Long userId, NoteDTO.NoteRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        // Generate instant AI summary if none provided
        String summary = request.getSummary();
        if ((summary == null || summary.isEmpty()) && request.getContent() != null) {
            summary = generateSummary(request.getContent());
        }

        Note note = Note.builder()
                .user(user)
                .title(request.getTitle())
                .content(request.getContent())
                .summary(summary)
                .isPinned(request.getIsPinned() != null ? request.getIsPinned() : false)
                .color(request.getColor() != null ? request.getColor() : "#FF9F0A")
                .tags(request.getTags())
                .folderId(request.getFolderId())
                .build();

        return mapToResponse(noteRepository.save(note));
    }

    @Transactional
    public NoteDTO.NoteResponse updateNote(Long userId, Long noteId, NoteDTO.NoteRequest request) {
        Note note = noteRepository.findByIdAndUserId(noteId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Note", "id", noteId));

        if (request.getTitle() != null) note.setTitle(request.getTitle());
        if (request.getContent() != null) {
            note.setContent(request.getContent());
            if (request.getSummary() == null || request.getSummary().isEmpty()) {
                note.setSummary(generateSummary(request.getContent()));
            }
        }
        if (request.getSummary() != null) note.setSummary(request.getSummary());
        if (request.getIsPinned() != null) note.setIsPinned(request.getIsPinned());
        if (request.getColor() != null) note.setColor(request.getColor());
        if (request.getTags() != null) note.setTags(request.getTags());

        return mapToResponse(noteRepository.save(note));
    }

    @Transactional
    public void deleteNote(Long userId, Long noteId) {
        Note note = noteRepository.findByIdAndUserId(noteId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Note", "id", noteId));
        noteRepository.delete(note);
    }

    private String generateSummary(String content) {
        if (content == null || content.isEmpty()) return "";
        String clean = content.replaceAll("[#*`_\\n]", " ").trim();
        return clean.length() > 140 ? clean.substring(0, 137) + "..." : clean;
    }

    public NoteDTO.NoteResponse mapToResponse(Note note) {
        return NoteDTO.NoteResponse.builder()
                .id(note.getId())
                .title(note.getTitle())
                .content(note.getContent())
                .summary(note.getSummary())
                .isPinned(note.getIsPinned())
                .color(note.getColor())
                .tags(note.getTags())
                .folderId(note.getFolderId())
                .createdAt(note.getCreatedAt())
                .updatedAt(note.getUpdatedAt())
                .build();
    }
}
