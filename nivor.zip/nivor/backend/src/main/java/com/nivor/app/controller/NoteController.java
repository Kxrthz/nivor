package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.NoteDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.NoteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/notes")
@RequiredArgsConstructor
@Tag(name = "Notes", description = "Markdown rich notes, tagging, and AI summaries")
public class NoteController {

    private final NoteService noteService;

    @GetMapping
    @Operation(summary = "Get all notes for current user")
    public ResponseEntity<ApiResponse<List<NoteDTO.NoteResponse>>> getNotes(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) String search) {
        List<NoteDTO.NoteResponse> notes = noteService.getUserNotes(currentUser.getId(), search);
        return ResponseEntity.ok(ApiResponse.success(notes));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get single note by ID")
    public ResponseEntity<ApiResponse<NoteDTO.NoteResponse>> getNote(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        NoteDTO.NoteResponse note = noteService.getNoteById(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success(note));
    }

    @PostMapping
    @Operation(summary = "Create a new note")
    public ResponseEntity<ApiResponse<NoteDTO.NoteResponse>> createNote(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody NoteDTO.NoteRequest request) {
        NoteDTO.NoteResponse note = noteService.createNote(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Note created successfully", note));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update an existing note")
    public ResponseEntity<ApiResponse<NoteDTO.NoteResponse>> updateNote(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id,
            @RequestBody NoteDTO.NoteRequest request) {
        NoteDTO.NoteResponse note = noteService.updateNote(currentUser.getId(), id, request);
        return ResponseEntity.ok(ApiResponse.success("Note updated successfully", note));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a note")
    public ResponseEntity<ApiResponse<Void>> deleteNote(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        noteService.deleteNote(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success("Note deleted successfully", null));
    }
}
