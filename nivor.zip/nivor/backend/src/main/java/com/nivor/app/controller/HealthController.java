package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.HealthDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.HealthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1/health")
@RequiredArgsConstructor
@Tag(name = "Health & Wellness", description = "Hydration, sleep, steps, workout, and weight tracking")
public class HealthController {

    private final HealthService healthService;

    @GetMapping("/summary")
    @Operation(summary = "Get daily health dashboard metrics")
    public ResponseEntity<ApiResponse<HealthDTO.DailyHealthSummary>> getDailySummary(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        HealthDTO.DailyHealthSummary summary = healthService.getDailySummary(currentUser.getId(), date);
        return ResponseEntity.ok(ApiResponse.success(summary));
    }

    @PostMapping("/log")
    @Operation(summary = "Log a health metric (water, sleep, steps, weight, workout)")
    public ResponseEntity<ApiResponse<HealthDTO.MetricResponse>> logMetric(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody HealthDTO.MetricLogRequest request) {
        HealthDTO.MetricResponse metric = healthService.logMetric(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Metric logged successfully", metric));
    }

    @GetMapping("/history")
    @Operation(summary = "Get health metric history")
    public ResponseEntity<ApiResponse<List<HealthDTO.MetricResponse>>> getHistory(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate start,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate end) {
        List<HealthDTO.MetricResponse> history = healthService.getMetricsHistory(currentUser.getId(), start, end);
        return ResponseEntity.ok(ApiResponse.success(history));
    }
}
