package com.nivor.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "health_metrics", indexes = {
        @Index(name = "idx_health_user_date", columnList = "user_id, logged_at")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HealthMetric {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    @JsonIgnore
    private User user;

    @NotBlank
    @Column(nullable = false, length = 30)
    private String type; // WATER_ML, SLEEP_HOURS, STEPS, WEIGHT_KG, WORKOUT_MIN

    @NotNull
    @Column(name = "metric_value", nullable = false, precision = 8, scale = 2)
    private BigDecimal metricValue;

    @NotBlank
    @Column(nullable = false, length = 20)
    private String unit; // ml, hours, steps, kg, minutes

    @Column(length = 255)
    private String notes;

    @NotNull
    @Column(name = "logged_at", nullable = false)
    private LocalDate loggedAt;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime createdAt;
}
