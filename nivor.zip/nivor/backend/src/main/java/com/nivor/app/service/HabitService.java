package com.nivor.app.service;

import com.nivor.app.dto.HabitDTO;
import com.nivor.app.exception.ResourceNotFoundException;
import com.nivor.app.model.Habit;
import com.nivor.app.model.HabitLog;
import com.nivor.app.model.User;
import com.nivor.app.repository.HabitLogRepository;
import com.nivor.app.repository.HabitRepository;
import com.nivor.app.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HabitService {

    private final HabitRepository habitRepository;
    private final HabitLogRepository habitLogRepository;
    private final UserRepository userRepository;

    public List<HabitDTO.HabitResponse> getUserHabits(Long userId) {
        List<Habit> habits = habitRepository.findByUserIdOrderByCreatedAtAsc(userId);
        LocalDate today = LocalDate.now();
        LocalDate sevenDaysAgo = today.minusDays(6);

        List<HabitLog> recentLogs = habitLogRepository.findLogsInRange(userId, sevenDaysAgo, today);
        Map<Long, Map<LocalDate, HabitLog>> logMatrix = new HashMap<>();

        for (HabitLog log : recentLogs) {
            logMatrix.computeIfAbsent(log.getHabit().getId(), k -> new HashMap<>())
                    .put(log.getLogDate(), log);
        }

        return habits.stream().map(h -> {
            Map<LocalDate, HabitLog> hLogs = logMatrix.getOrDefault(h.getId(), Collections.emptyMap());
            HabitLog todayLog = hLogs.get(today);
            boolean completedToday = todayLog != null && Boolean.TRUE.equals(todayLog.getIsCompleted());
            int todayCount = todayLog != null ? todayLog.getCount() : 0;

            Map<String, Boolean> pastWeek = new LinkedHashMap<>();
            for (int i = 6; i >= 0; i--) {
                LocalDate date = today.minusDays(i);
                HabitLog logForDay = hLogs.get(date);
                pastWeek.put(date.toString(), logForDay != null && Boolean.TRUE.equals(logForDay.getIsCompleted()));
            }

            return HabitDTO.HabitResponse.builder()
                    .id(h.getId())
                    .name(h.getName())
                    .description(h.getDescription())
                    .frequency(h.getFrequency())
                    .targetCountPerDay(h.getTargetCountPerDay())
                    .unit(h.getUnit())
                    .color(h.getColor())
                    .icon(h.getIcon())
                    .currentStreak(h.getCurrentStreak())
                    .longestStreak(h.getLongestStreak())
                    .completedToday(completedToday)
                    .todayCount(todayCount)
                    .pastWeekStatus(pastWeek)
                    .createdAt(h.getCreatedAt())
                    .build();
        }).collect(Collectors.toList());
    }

    @Transactional
    public HabitDTO.HabitResponse createHabit(Long userId, HabitDTO.HabitRequest request) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

        Habit habit = Habit.builder()
                .user(user)
                .name(request.getName())
                .description(request.getDescription())
                .frequency(request.getFrequency() != null ? request.getFrequency() : "DAILY")
                .targetCountPerDay(request.getTargetCountPerDay() != null ? request.getTargetCountPerDay() : 1)
                .unit(request.getUnit() != null ? request.getUnit() : "times")
                .color(request.getColor() != null ? request.getColor() : "#30D158")
                .icon(request.getIcon() != null ? request.getIcon() : "Flame")
                .currentStreak(0)
                .longestStreak(0)
                .build();

        Habit saved = habitRepository.save(habit);
        return mapToSimpleResponse(saved);
    }

    @Transactional
    public HabitDTO.HabitResponse checkInHabit(Long userId, Long habitId, HabitDTO.CheckInRequest request) {
        Habit habit = habitRepository.findByIdAndUserId(habitId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Habit", "id", habitId));

        LocalDate targetDate = request.getDate() != null ? request.getDate() : LocalDate.now();
        Optional<HabitLog> existing = habitLogRepository.findByHabitIdAndLogDate(habitId, targetDate);

        HabitLog log;
        if (existing.isPresent()) {
            log = existing.get();
            boolean newCompleted = request.getCompleted() != null ? request.getCompleted() : !log.getIsCompleted();
            log.setIsCompleted(newCompleted);
            if (request.getCount() != null) log.setCount(request.getCount());
        } else {
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new ResourceNotFoundException("User", "id", userId));

            log = HabitLog.builder()
                    .habit(habit)
                    .user(user)
                    .logDate(targetDate)
                    .count(request.getCount() != null ? request.getCount() : 1)
                    .isCompleted(request.getCompleted() != null ? request.getCompleted() : true)
                    .build();
        }
        habitLogRepository.save(log);

        // Recalculate streaks
        if (Boolean.TRUE.equals(log.getIsCompleted())) {
            habit.setCurrentStreak(habit.getCurrentStreak() + 1);
            if (habit.getCurrentStreak() > habit.getLongestStreak()) {
                habit.setLongestStreak(habit.getCurrentStreak());
            }
        } else if (habit.getCurrentStreak() > 0) {
            habit.setCurrentStreak(Math.max(0, habit.getCurrentStreak() - 1));
        }
        habitRepository.save(habit);

        List<HabitDTO.HabitResponse> all = getUserHabits(userId);
        return all.stream().filter(h -> h.getId().equals(habitId)).findFirst()
                .orElse(mapToSimpleResponse(habit));
    }

    @Transactional
    public void deleteHabit(Long userId, Long habitId) {
        Habit habit = habitRepository.findByIdAndUserId(habitId, userId)
                .orElseThrow(() -> new ResourceNotFoundException("Habit", "id", habitId));
        habitRepository.delete(habit);
    }

    private HabitDTO.HabitResponse mapToSimpleResponse(Habit h) {
        return HabitDTO.HabitResponse.builder()
                .id(h.getId())
                .name(h.getName())
                .description(h.getDescription())
                .frequency(h.getFrequency())
                .targetCountPerDay(h.getTargetCountPerDay())
                .unit(h.getUnit())
                .color(h.getColor())
                .icon(h.getIcon())
                .currentStreak(h.getCurrentStreak())
                .longestStreak(h.getLongestStreak())
                .completedToday(false)
                .todayCount(0)
                .pastWeekStatus(new HashMap<>())
                .createdAt(h.getCreatedAt())
                .build();
    }
}
