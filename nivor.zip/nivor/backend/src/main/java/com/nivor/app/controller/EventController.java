package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.EventDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.EventService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/v1/events")
@RequiredArgsConstructor
@Tag(name = "Events & Calendar", description = "Calendar events, scheduling, and sync")
public class EventController {

    private final EventService eventService;

    @GetMapping
    @Operation(summary = "Get user calendar events")
    public ResponseEntity<ApiResponse<List<EventDTO.EventResponse>>> getEvents(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end) {
        List<EventDTO.EventResponse> events;
        if (start != null && end != null) {
            events = eventService.getEventsInRange(currentUser.getId(), start, end);
        } else {
            events = eventService.getUserEvents(currentUser.getId());
        }
        return ResponseEntity.ok(ApiResponse.success(events));
    }

    @PostMapping
    @Operation(summary = "Create a calendar event")
    public ResponseEntity<ApiResponse<EventDTO.EventResponse>> createEvent(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody EventDTO.EventRequest request) {
        EventDTO.EventResponse event = eventService.createEvent(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Event created successfully", event));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a calendar event")
    public ResponseEntity<ApiResponse<EventDTO.EventResponse>> updateEvent(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id,
            @RequestBody EventDTO.EventRequest request) {
        EventDTO.EventResponse event = eventService.updateEvent(currentUser.getId(), id, request);
        return ResponseEntity.ok(ApiResponse.success("Event updated successfully", event));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a calendar event")
    public ResponseEntity<ApiResponse<Void>> deleteEvent(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        eventService.deleteEvent(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success("Event deleted successfully", null));
    }
}
