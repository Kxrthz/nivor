package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.FinanceDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.FinanceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/finance")
@RequiredArgsConstructor
@Tag(name = "Finance", description = "Transactions, budgets, subscriptions, and financial metrics")
public class FinanceController {

    private final FinanceService financeService;

    @GetMapping("/summary")
    @Operation(summary = "Get overall finance summary, active budgets, and subscriptions")
    public ResponseEntity<ApiResponse<FinanceDTO.FinanceSummaryResponse>> getSummary(
            @AuthenticationPrincipal UserPrincipal currentUser) {
        FinanceDTO.FinanceSummaryResponse summary = financeService.getFinanceSummary(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success(summary));
    }

    @GetMapping("/transactions")
    @Operation(summary = "Get all financial transactions")
    public ResponseEntity<ApiResponse<List<FinanceDTO.TransactionResponse>>> getTransactions(
            @AuthenticationPrincipal UserPrincipal currentUser) {
        List<FinanceDTO.TransactionResponse> txs = financeService.getUserTransactions(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success(txs));
    }

    @PostMapping("/transactions")
    @Operation(summary = "Log an income or expense transaction")
    public ResponseEntity<ApiResponse<FinanceDTO.TransactionResponse>> createTransaction(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody FinanceDTO.TransactionRequest request) {
        FinanceDTO.TransactionResponse tx = financeService.createTransaction(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Transaction recorded", tx));
    }

    @GetMapping("/budgets")
    @Operation(summary = "Get monthly category budgets")
    public ResponseEntity<ApiResponse<List<FinanceDTO.BudgetResponse>>> getBudgets(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) String monthYear) {
        List<FinanceDTO.BudgetResponse> budgets = financeService.getUserBudgets(currentUser.getId(), monthYear);
        return ResponseEntity.ok(ApiResponse.success(budgets));
    }

    @PostMapping("/budgets")
    @Operation(summary = "Set or update a category budget")
    public ResponseEntity<ApiResponse<FinanceDTO.BudgetResponse>> saveBudget(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody FinanceDTO.BudgetRequest request) {
        FinanceDTO.BudgetResponse budget = financeService.createOrUpdateBudget(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Budget saved", budget));
    }

    @DeleteMapping("/transactions/{id}")
    @Operation(summary = "Delete a transaction")
    public ResponseEntity<ApiResponse<Void>> deleteTransaction(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        financeService.deleteTransaction(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success("Transaction deleted", null));
    }
}
