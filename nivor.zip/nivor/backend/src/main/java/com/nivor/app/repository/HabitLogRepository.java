package com.nivor.app.repository;

import com.nivor.app.model.HabitLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface HabitLogRepository extends JpaRepository<HabitLog, Long> {
    Optional<HabitLog> findByHabitIdAndLogDate(Long habitId, LocalDate logDate);
    List<HabitLog> findByUserIdAndLogDate(Long userId, LocalDate logDate);

    @Query("SELECT hl FROM HabitLog hl WHERE hl.user.id = :userId AND hl.logDate BETWEEN :startDate AND :endDate")
    List<HabitLog> findLogsInRange(@Param("userId") Long userId, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
}
