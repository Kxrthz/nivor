package com.nivor.app.controller;

import com.nivor.app.dto.ApiResponse;
import com.nivor.app.dto.FileDTO;
import com.nivor.app.security.UserPrincipal;
import com.nivor.app.service.FileManagerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/files")
@RequiredArgsConstructor
@Tag(name = "File Manager", description = "File storage, categorization, and OCR search")
public class FileManagerController {

    private final FileManagerService fileService;

    @GetMapping
    @Operation(summary = "Get user files with optional folder or search filter")
    public ResponseEntity<ApiResponse<List<FileDTO.FileResponse>>> getFiles(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) String folder,
            @RequestParam(required = false) String search) {
        List<FileDTO.FileResponse> files = fileService.getUserFiles(currentUser.getId(), folder, search);
        return ResponseEntity.ok(ApiResponse.success(files));
    }

    @PostMapping
    @Operation(summary = "Save uploaded file metadata")
    public ResponseEntity<ApiResponse<FileDTO.FileResponse>> saveFile(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestBody FileDTO.FileUploadRequest request) {
        FileDTO.FileResponse file = fileService.saveFileMetadata(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("File uploaded", file));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a file")
    public ResponseEntity<ApiResponse<Void>> deleteFile(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @PathVariable Long id) {
        fileService.deleteFile(currentUser.getId(), id);
        return ResponseEntity.ok(ApiResponse.success("File deleted", null));
    }
}
